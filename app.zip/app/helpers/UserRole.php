<?php 

use App\Models\RolePermission;
use App\Models\Menus;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

function getSideMenus() {

    $response = [];

    if (Auth::check()) {
        
        if(Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID']) {

            $response = Menus::orderBy('seq_no','ASC')->get();

        } else {

            $rolePermissions = RolePermission::where('role_id', Auth::user()->role_id)
                                        ->orderBy('seq_no','ASC')
                                        ->get();

            $menuArr = $rolePermissions->pluck('menu_id')->toArray();
            
            $menuSequence = implode(',', $menuArr);
    
            $response = Menus::select('id','name','slug','icon')
                                ->whereIn('id', $menuArr)
                                ->orderByRaw("FIELD('seq_no', 'ASC')")
                                ->get();
        }

    } else {
        $response = [];
    }
    

    return $response;
}

function checkPermission($path) {

    if (Auth::check()) {

        if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID']) {
            $action = 1;
        } else {
            $menulist = Menus::join('role_permissions','role_permissions.menu_id','=','menus.id')->where('menus.slug','=',$path)->where('role_permissions.role_id',Auth::user()->role_id)->select('role_permissions.is_writable')->first();
            $action = $menulist == false ? 0 : $menulist->is_writable; 
        }

        return $action;
    }

    return 0;
}

function getuserByRoleId($id) {

    return User::where(['role_id' => $id, 'deleted'=>'0'])->orderBy('name')->get();
}

function getuserListByIdArray($idarray) {

    $idarray = explode(",",$idarray);

    $userList = user::select('id','name')->whereIn('id',$idarray)->get();

    return ['user_id'=>$userList->implode("id",","),'user_name'=>$userList->implode("name",",")];
}

function getuserListByid($idarray) {

    $userList = user::select('id','name')->whereIn('id',$idarray)->get();

    return ['user_id'=>$userList->implode("id",","),'user_name'=>$userList->implode("name",", ")];
}

function convertDate($date) {
    $serviceDate = \DateTime::createFromFormat('Y-m-d', (string)$date);
    return $serviceDate->format('m-d-Y');
}

function convertDateIST($date) {

    try {
        $serviceDate = \DateTime::createFromFormat('m-d-Y', (string)$date);
        return $serviceDate->format('Y-m-d');
    } catch (\Exception $th) {
        return $date;
    }
    
}

function formatPhoneNumber($phone) {

    try {
       
        if (preg_match( '/^(\d{3})(\d{3})(\d{4})$/', $phone,  $matches ) ) {
            $result = $matches[1] . '-' .$matches[2] . '-' . $matches[3];
            return $result;
        } 
        return $phone;
    } catch (\Throwable $th) {
        return $phone;
    }
    
}


function convertTime($time) {

    try {
        return date("h:i A",strtotime($time));
    } catch (\Throwable $th) {
        return $time;
    }
    
}

?>