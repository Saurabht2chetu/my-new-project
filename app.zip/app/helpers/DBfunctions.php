<?php 

use App\Models\Appointment;
use App\Models\Note;
use App\Models\StickyNote;
use App\Models\user;
use App\Models\Examiner;
use App\Models\Assistant;
use App\Models\ScrapModel;
use Illuminate\Support\Facades\DB;
use App\Models\ClinicData;

function getAppoinmentList() {

    $appointmentData = Appointment::leftjoin('users','users.id','=','appointments.user_id')
    ->leftjoin('patients','patients.id','=','appointments.patient_id')
    ->leftjoin('locations','locations.id','=','appointments.location_id')
    ->join('states','states.id','=','locations.state_id')
    ->where('appointments.deleted','0')
    ->groupBy('appointments.service_date')
    ->groupBy('appointments.location_id')
    ->orderBy('appointments.service_date','DESC')
    ->select('appointments.*','users.name as user_name','locations.name as location_name')
    ->get();
    
    return $appointmentData;
}

function getAppointmentListByDate($from_date,$to_date) {

    try {
        
        $appointmentData = Appointment::join('patients','patients.id','=','appointments.patient_id')
        ->join('locations','locations.id','=','appointments.location_id')
        ->join('states','states.id','=','locations.state_id')
        ->where('appointments.deleted','0')
        ->where('appointments.service_date','>=',convertDateIST($from_date))
        ->where('appointments.service_date','<=',convertDateIST($to_date))
        ->groupBy('appointments.service_date')
        ->groupBy('appointments.location_id')
        ->orderBy('appointments.service_date','ASC')
        ->orderBy('states.name','ASC')
        ->orderBy('locations.name','ASC')
        ->select('appointments.*','locations.name as location_name','states.name as state_name')
        ->get();

        return $appointmentData;

    } catch (\Throwable $th) {
        //throw $th;
        return [];
    } 
}

function getAppointmentDate() {

    $appointmentData = Appointment::where('appointments.deleted','0')
    ->groupBy('appointments.service_date')
    ->orderBy('appointments.service_date','DESC')
    ->select('appointments.*')
    ->get();
    
    return $appointmentData;
}

function getClinicByServiceDate($serviceDate,$colorType) {

    $clinicsByServiceDate = Appointment::join('locations','locations.id','=','appointments.location_id')
    ->where('appointments.deleted','0')
    ->where('appointments.clinic_status',$colorType)
    ->where('appointments.service_date',convertDateIST($serviceDate))
    ->groupBy('appointments.location_id')
    ->select('appointments.location_id','locations.name')
    ->orderBy('locations.name','ASC')
    ->get();
    
    return $clinicsByServiceDate;
}

function getLastCallNotes($appointment_id) {

    return Note::where(['appointment_id' => $appointment_id])->orderBy('id','DESC')->first();
}

function getLastStickyNotes($appointment_id) {

    return StickyNote::where(['appointment_id' => $appointment_id,'deleted'=>'0'])->orderBy('id','DESC')->first();
}

function getuserNameById($id) {

    return user::where(['id' => $id])->first();
}

function getExaminersByDateAndLocation(string $date = '', int $locationId = 0) {
        
    if (!empty($date) && !empty($locationId)) {
        $examinersList = Examiner::where(['service_date'=>$date,'location_id'=>$locationId])->get();
        
        if (count($examinersList) > 0) {
            
            $examinerId = $examinersList->pluck('examiner_id');
            return ['examiner_list'=>getuserListByid($examinerId)];
        }
    }
    return [];
    
}

function getAllexaminerByDateOrLocation(string $date = '', int $locationId = 0) {
        
    if (!empty($date) && !empty($locationId)) {
        $examinerList = Appointment::join('users','users.id','=','appointments.user_id')
                        ->where(['appointments.service_date'=>$date,'appointments.location_id'=>$locationId])
                        ->groupBy('appointments.user_id')
                        ->select('appointments.*','users.name as user_name','users.id as user_id')
                        ->get();

        return ['user_name'=>$examinerList->implode('user_name',","),'user_id'=>$examinerList->implode('user_id',",")];
    }
    return [];
}

function getAssistantsByDateAndLocation(string $date = '', int $locationId = 0) {

    if (!empty($date) && !empty($locationId)) {
        $assistantsList = Assistant::where(['service_date'=>$date, 'location_id'=>$locationId])->get();

        if (count($assistantsList) > 0) {
            $assistantId = $assistantsList->pluck('assistant_id');
            return ['assistant_list'=>getuserListByid($assistantId)];
        }
    }
    return []; 
}

function getAppointmentListByDateOrLocation($date,$location) {

    $appointmentData = Appointment::join('patients','patients.id','=','appointments.patient_id')
    ->where('appointments.service_date',$date)
    ->where('appointments.location_id',$location)
    ->where('appointments.deleted','0')
    // ->groupBy('appointments.patient_id')
    // ->orderBy('appointments.service_date','DESC')
    ->orderBy(DB::raw('CAST(service_time AS time)'),'ASC')
    ->select('appointments.id as appointment_id','appointments.service_date','appointments.service_time','appointments.invoice_url','appointments.special_instruction','appointments.cepacket_url','appointments.case_id','appointments.status','appointments.status_text','patients.*')
    ->get();

    return $appointmentData;

}

function getClinicDataByDateorLocation($date,$location) {

    try {
        $clinicDataList = ClinicData::where(['service_date'=> $date,'location_id'=> $location])->first();

        return $clinicDataList;
    } catch (\Throwable $th) {
        //throw $th;
        return [];
    }
     
} 

function getClinicCalculation($date,$location) {
    
    try {

        $Scrapmodel = new ScrapModel();
        //get clinic calculation data
        $CalculationList = $Scrapmodel->select_query('clinic_calculations',['service_date'=>$date,'location_id'=>$location]);
        return $CalculationList;
    } catch (\Throwable $th) {
        //throw $th;
        return [];
    }
}

function getSechduleAppointmentCount(string $date,int $location) {

    try {
        return Appointment::where('status','!=',2)->where('patient_id','!=','0')->where(['service_date'=>$date,'location_id' => $location,'deleted'=>0])->count();
    } catch (\Throwable $th) {
        return 0;
    }

    
}

function getShowedAppointmentCount(string $date,int $location) {

    try {
        return Appointment::where('status',0)->where('patient_id','!=','0')->where(['service_date'=>$date,'location_id'=>$location,'deleted'=>0])->count();
    } catch (\Throwable $th) {
        return 0;
    }

    
}

function signatureURL(string $path) {
    $parseURL = parse_url($path);
    $fileBaseName = $parseURL['path'];
    if (preg_match("/^\//", $fileBaseName) == 1) {
        $fileBaseName = ltrim($fileBaseName, '/');
    }

    $adapter = Storage::disk('s3')->getDriver()->getAdapter();
        $command = $adapter->getClient()->getCommand('GetObject', [
          'Bucket' => $_ENV['AWS_BUCKET'],
          'Key'    => $fileBaseName
        ]);

    $signature = $adapter->getClient()->createPresignedRequest($command, $_ENV['FILE_VIEW_TIME']);
    return $signature->getUri();
}

function examinerSignatureURL(string $path) {
    $parseURL = parse_url($path);
    $fileBaseName = $parseURL['path'];
    if (preg_match("/^\//", $fileBaseName) == 1) {
        $fileBaseName = ltrim($fileBaseName, '/');
    }
    $adapter = Storage::disk('signatures3')->getDriver()->getAdapter();
        $command = $adapter->getClient()->getCommand('GetObject', [
          'Bucket' => $_ENV['AWS_BUCKET_SIGNATURE'],
          'Key'    => $fileBaseName
        ]);

    $signature = $adapter->getClient()->createPresignedRequest($command, $_ENV['FILE_VIEW_TIME']);
    return $signature->getUri();
}

?>