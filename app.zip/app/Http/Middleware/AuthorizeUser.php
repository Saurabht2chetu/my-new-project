<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use DB;

class AuthorizeUser {
    
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next) {
        // return $next($request);
        
        if (!isset(Auth::user()->role_id)) {
            return redirect('/');
        }

        if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID']) {
            
            return $next($request);
        }
        
        if (Auth::user()->role_id != $_ENV['SUPERADMIN_ROLE_ID'] && ($request->path() == 'role-permissions' || $request->path() == 'state-ere-management')) {
            // abort(403,'Unauthorized User');
            return redirect('no-access');
        }
        
        if ( (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID']) && ($request->path() == 'notification-template' || $request->path() == 'appointment-reminder' || $request->path() == 'dashboard') ) {
            return $next($request);
        }
        
        $checkPermission = DB::table('menus')
        ->join('role_permissions','role_permissions.menu_id','=','menus.id')
        ->where('menus.slug',$request->path())
        ->where('role_permissions.role_id',Auth::user()->role_id)
        ->first();

        if ($checkPermission) {
            return $next($request);
        }
        // abort(403,'Unauthorized User');
        return redirect('no-access');
    } 
}
