<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Appointment;
use App\Models\Assistant;
use App\Models\Examiner;

class ExamineeAuth {
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next) {

        if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID']) {
            return $next($request);
        }

        if (Auth::user()->role_id == $_ENV['EXAMINER_ROLE_ID']) {
            // echo $request->segment(2);
            // die;
            $examinerCheck = Examiner::where(['service_date' => $request->segment(2),'location_id' => $request->segment(3),'examiner_id'=>Auth::user()->id])->first();

            $appointmentData = Appointment::where(['service_date'=>$request->segment(2),'location_id'=>$request->segment(3),'user_id'=>Auth::user()->id])->first();

            if ($examinerCheck || $appointmentData) {
                return $next($request);
            }
            // abort(403,"your unauthorized user");
            return redirect('no-access');
        }

        if (Auth::user()->role_id == $_ENV['ASSISTANT_ROLE_ID']) {
            // echo $request->segment(2);
            // die;
            $assistantCheck = Assistant::where(['service_date' => $request->segment(2),'location_id' => $request->segment(3),'assistant_id'=>Auth::user()->id])->first();

            $appointmentData = Appointment::where(['service_date'=>$request->segment(2),'location_id'=>$request->segment(3),'user_id'=>Auth::user()->id])->first();

            if ($assistantCheck || $appointmentData) {
                return $next($request);
            }
            // abort(403,"your unauthorized user");
            return redirect('no-access');
        }
        

        
    }
}
