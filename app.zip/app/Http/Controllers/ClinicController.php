<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Carbon\Carbon;
use DataTables;
use App\Models\Appointment;
use App\Models\Assistant;
use App\Models\Examiner;
use App\Models\States;
use App\Models\Location;
use App\Models\ClinicHistory;
use App\Models\StickyNote;
use App\Models\User;
use App\Models\ScrapModel;
use App\Models\ClinicData;
use Validator;
use Auth;
use DB;
use Storage;
use LynX39\LaraPdfMerger\Facades\PdfMerger as PDFMerger;


/**
 * This class is used to interact with the Clinic List  Module
 *
 * PHP version 8.0.8
 *
 * @category  Supporting_Script
 * @package   ClinicList_Module
 * @author    Chetu
 * @copyright 2022 Chetu
 */

class ClinicController extends Controller {

    /**
     * This method will be used to list the Clinic Data 
     *
     * @param  Illuminate\Http\Request $request
     */
    public function index(Request $request) {
        
        $admin = false;

        if ($request->ajax()) { 

            if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID']) {
                
                $userList = User::where(['deleted'=>'0'])->get()->pluck('id');

                $appointment_ids = [];
                $admin = true;

            } else if(Auth::user()->role_id == $_ENV['EXAMINER_ROLE_ID']) {

                $examinerList = Examiner::where(['examiner_id' => Auth::user()->id,'deleted'=>'0'])->get();

                if (count($examinerList) > 0) {
                    
                    $appointment_ids = [];

                    foreach ($examinerList as $key => $list) {
                        
                        $appointmentData = Appointment::where(['service_date'=>$list->service_date ,'location_id'=>$list->location_id])->first();

                        if ($appointmentData) {

                            $appointment_ids[] = $appointmentData->id;
                        }
                    }

                    $userList[] = Auth::user()->id;

                } else {

                    $appointment_ids = [];
                    $userList[] = Auth::user()->id;
                }

            } else if(Auth::user()->role_id == $_ENV['ASSISTANT_ROLE_ID']) {

                $assistantList = Assistant::where(['assistant_id' => Auth::user()->id,'deleted'=>'0'])->get();

                if (count($assistantList) > 0) {

                    $appointment_ids = [];

                    foreach ($assistantList as $key => $list) {
                        
                        $appointmentData = Appointment::where(['service_date'=>$list->service_date ,'location_id'=>$list->location_id])->first();

                        if ($appointmentData) {

                            $appointment_ids[] = $appointmentData->id;
                        }
                    }

                    $userList[] = Auth::user()->id;

                } else {

                    $appointment_ids = [];
                    $userList[] = Auth::user()->id;
                }
            }
            // return [$serviceDate,$userList];
            if (isset($request->state) && $request->state != '') {

                $appointmentData = $this->fetchAppointmentList($request->state,$request->from_date,$request->to_date,$admin);

            } else {

                $appointmentData = $this->fetchAppointmentList([],$request->from_date,$request->to_date,$admin,$appointment_ids,$userList);
            }
            
            return  Datatables::of($appointmentData)
                        ->addIndexColumn()
                        ->addColumn('action', function($row) {
                            $btn = '<div class="db-action-box">';

                            if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID']) {
                                $btn.= '<div class="edit-icon"><p class="editbtn" data-toggle="tooltip" data-placement="top" title="Edit" data-id="'.$row->id.'" data-date="'.$row->service_date.'" data-location="'.$row->location_id.'"><i class="far fa-edit"></i></p></div>';

                                if ($row->deleted == 0) {
                                    $btn.= '<div class="delete-icon"><p class="deletebtn" title="Delete" data-date="'.$row->service_date.'" data-location="'.$row->location_id.'" data-action="0"><i class="fas fa-times"></i></p></div>';
                                }
                            } else {
                                $btn.= '<div class="edit-icon"><p class="access_denied" title="Edit"><i class="far fa-edit"></i></p></div><div class="delete-icon"><p class="access_denied" title="Delete" ><i class="fas fa-times"></i></p></div>';
                            }

                            return $btn;
                            
                        })->addColumn('invoice', function($row) {
                            // $btn = '<div class="td-img"><img style="cursor:pointer;" title="Download" class="buildinvoicepdfbtn" src='.asset("assets/images/png-1.png").' data-date="'.$row->service_date.'" data-location="'.$row->location_id.'" > </div>';
                            $btn = '<div class="td-img"><img style="cursor:pointer;" title="Download" class="downloadinvoicefromS3" src='.asset("assets/images/png-1.png").' data-date="'.$row->service_date.'" data-location="'.$row->location_id.'" > </div>';

                            return $btn;
                            
                        })->addColumn('service_date', function($row) {

                            return convertDate($row->service_date);
                            
                        })->addColumn('cepacket', function($row) {
                            // return '<div class="td-img"><img style="cursor:pointer;" title="Download" class="buildcepacketpdfbtn" src='.asset("assets/images/png-1.png").' data-date="'.$row->service_date.'" data-location="'.$row->location_id.'" > </div>';
                            return '<div class="td-img"><img style="cursor:pointer;" title="Download" class="downloadrecordfromS3" src='.asset("assets/images/png-1.png").' data-date="'.$row->service_date.'" data-location="'.$row->location_id.'" > </div>';

                        })->addColumn('assistant', function($row) {
                            
                            $assistantList = $this->getAssistantsByDateAndLocation($row->service_date,$row->location_id);
                            return count($assistantList) > 0 ? $assistantList['assistant_list']['user_name'] : '';

                        })->addColumn('examiner_list', function($row) {
                            
                            $assistantList = $this->getExaminersByDateAndLocation($row->service_date,$row->location_id);
                            
                            if (count($assistantList) > 0) {

                                return count($assistantList) > 0 ? $assistantList['examiner_list']['user_name'] : 'na';

                            } else {
                                $list = $this->getAllexaminer($row->service_date,$row->location_id);
                                return $list['user_name'];
                            }

                        })->addColumn('examinee', function($row) {
        
                            return '<a target="_blank" href="'.url('examinee-list').'/'.$row->service_date.'/'.$row->location_id.'">Examinee List</a>';

                        })->addColumn('sticky_count', function($row) {
        
                            return $this->stickyNoteCount($row->service_date,$row->location_id);

                        })->addColumn('clinic_document', function($row) {
                            $DocumentList = $this->findClinicDocuments($row->service_date, $row->location_id);
                            
                            if (count($DocumentList) > 0) {
                            return '<a href="javascript::void(0)" class="download_clinic_documents"  data-service_date = "'.$row->service_date.'" data-location = "'.$row->location_id.'" title="Download"><img style="cursor:pointer;width:23px;" src='.asset("assets/images/png-1.png").'></a>';
                            } else {
                                return '';//'<img style="width:40px;" src='.asset("assets/images/png-2.png").'>';
                            }
                        })->addColumn('x_rays', function($row) {
                            $clinicData = ClinicData::where(['service_date' => $row->service_date,'location_id' => $row->location_id])->first();
                            if ($clinicData) {
                                $checked = (($row->xray_checkbox =='0' && $clinicData->x_ray_vendor !="") || $row->xray_checkbox == '1' ? 'checked' : '' );
                            } else {
                                $checked = '';
                            }
                            return '<input data-row_id="'.$row->id.'" data-service_date="'.$row->service_date.'" data-location_id="'.$row->location_id.'"  class="xray_status"  type="checkbox" '.$checked.' >';
                        })->addColumn('pre_clinic_sent', function($row) {
                            $clinicData = ClinicData::where(['service_date' => $row->service_date,'location_id' => $row->location_id])->first();
                            if ($clinicData) {
                                $checked = (($clinicData->email =="1" && $clinicData->xray =="0" && $clinicData->invite =="1" && $clinicData->x_ray_vendor == "") || ($clinicData->x_ray_vendor !="" && $clinicData->email =="1" && $clinicData->invite =="1" && $clinicData->xray == "1") ? 'checked' : '');
                            } else {
                                $checked = '';
                            }
                            return '<div id="chkbox"><input type="checkbox"'.'  '.$checked.'></div>';
                        })->addColumn('designation', function($row) {

                            if ($row->clinic_status == 0) {
                                $btn = '<select class="form-control change_color_option" name="clinicReason" style="background-color: #96D35F;width: 37px;color: #fff;" data-date="'.$row->service_date.'" data-location="'.$row->location_id.'" data-color-status="'.$row->clinic_status.'"><option value="0" style="display:none;">green</option><option value="1" style="background-color: #FF2600;">Red</option><option value="2" style="background-color: #FFF76B;color:#000!important;">Yellow</option></select>';

                            } else if ($row->clinic_status == 1) {

                                $btn = '<select class="form-control change_color_option" name="clinicReason" style="background-color: #FF2600;width: 37px;color: #fff;" title="'.$row->clinic_reason.'" data-date="'.$row->service_date.'" data-location="'.$row->location_id.'" data-color-status="'.$row->clinic_status.'"><option value="" style="display:none;"></option><option value="0" style="background-color: #96D35F;">Green</option><option value="2" style="background-color: #FFF76B;color:#000!important;">Yellow</option></select>';

                            } else if ($row->clinic_status == 2) {

                                $btn = '<select class="form-control change_color_option" name="clinicReason" style="background-color: #FFF76B;width: 37px;color: #fff;" title="'.$row->clinic_reason.'" data-date="'.$row->service_date.'" data-location="'.$row->location_id.'" data-color-status="'.$row->clinic_status.'"><option value="" style="display:none;"></option><option value="1" style="background-color: #FF2600;">Red</option><option value="0" style="background-color: #96D35F;">Green</option></select>';
                            }

                            return $btn;
                        })->rawColumns(['action','invoice','cepacket','assistant','clinic_document','examinee','designation','x_rays','pre_clinic_sent'])->make(true);           
        }
        
        $statelist = States::join('locations','states.id','=','locations.state_id')->join('appointments','appointments.location_id','=','locations.id')->groupBy('states.id')->select('states.*')->get();

        $allClinics = Location::where('deleted', '=', '0')->get();

        $onCallStatement = $this->getOnCallStatement();

        return view('clinic.list', compact('statelist', 'allClinics', 'onCallStatement'));
    }

    /**
    * This method will be used to get Appointment list based on given conditions
    *
    * @param  Array $state              state name array.
    * @param  Date $from_date           from date for filter the record as start date.      
    * @param  Date $to_date             to date for filter the record as end date.      
    * @param  Boolean $admin            for admin user if admin user flag is true otherwise false.      
    * @param  Array $Appointment_ids    filter the record those examiner have assigned the appointment.      
    * @return array              User name and userId
    */
    protected function fetchAppointmentList($state,$from_date,$to_date,$admin=true,$appointment_ids=[],$userList=[]) {

        try {
            
            if($admin) {

                return $appointmentData = Appointment::leftjoin('users','users.id','=','appointments.user_id')
                ->leftjoin('patients','patients.id','=','appointments.patient_id')
                ->leftjoin('locations','locations.id','=','appointments.location_id')
                ->join('states','states.id','=','locations.state_id')
                ->select('appointments.*','users.name as user_name','locations.name as location_name')
                ->where('appointments.deleted','=','0')
                ->where('appointments.service_date','>=',convertDateIST($from_date))
                ->where('appointments.service_date','<=',convertDateIST($to_date))
                ->when(count($state) > 0,function($query) use ($state) {
                    $query->whereIn('states.id',$state);
                })
                ->groupBy('appointments.service_date')
                ->groupBy('appointments.location_id')
                ->orderBy('appointments.service_date','DESC')
                ->get();

            } else {

                return $appointmentData = Appointment::leftjoin('users','users.id','=','appointments.user_id')
                ->leftjoin('patients','patients.id','=','appointments.patient_id')
                ->leftjoin('locations','locations.id','=','appointments.location_id')
                ->join('states','states.id','=','locations.state_id')
                ->select('appointments.*','users.name as user_name','locations.name as location_name')
                ->where('appointments.deleted','=','0')
                ->where('appointments.service_date','>=',convertDateIST($from_date))
                ->where('appointments.service_date','<=',convertDateIST($to_date))
                ->where(function($subquery) use ($appointment_ids,$userList){
                    $subquery->whereIn('appointments.id',$appointment_ids)
                    ->orwhereIn('appointments.user_id',$userList);
                })
                ->when(count($state) > 0,function($query) use ($state) {
                    $query->whereIn('states.id',$state);
                })
                ->groupBy('appointments.service_date')
                ->groupBy('appointments.location_id')
                ->orderBy('appointments.service_date','DESC')
                ->get();

            }
         //code...
        } catch (\Throwable $th) {
            //throw $th;
            // return $th->getMessage();
            return [];
        }

    }

    public function checkInvoice(string $date,int $location_id) {

    }

    /**
    * This method will be used to get examiner from appointment table
    *
    * @param  string $date       Clinic service date
    * @param  int    $locationId Location Id of the Clinic
    * @return array              User name and userId
    */
    protected function getAllexaminer(string $date = '', int $locationId = 0) {
        
        if (!empty($date) && !empty($locationId)) {
            $examinerList = Appointment::join('users','users.id','=','appointments.user_id')
                            ->where(['appointments.service_date'=>$date,'appointments.location_id'=>$locationId])
                            ->groupBy('appointments.user_id')
                            ->select('appointments.*','users.name as user_name','users.id as user_id')
                            ->get();

            return ['user_name'=>$examinerList->implode('user_name',","),'user_id'=>$examinerList->implode('user_id',",")];
        }
        return [];
    }

    /**
     * This method will be used to get examiner from examiner table
     *
     * @param  string $date       Clinic service date
     * @param  int    $locationId Location Id of the Clinic
     * @return array              Examiner List User name and userId
     */
    protected function getExaminersByDateAndLocation(string $date = '', int $locationId = 0) {
        
        if (!empty($date) && !empty($locationId)) {
            $examinersList = Examiner::where(['service_date'=>$date,'location_id'=>$locationId])->get();

            if (count($examinersList) > 0) {
                $examinerId = $examinersList->pluck('examiner_id');
                return ['examiner_list'=>getuserListByid($examinerId)];
            }
        }
        return [];
        
    }

    /**
     * This method will be used to get Assistants By Date And Location
     *
     * @param  string $date       Clinic service date
     * @param  int    $locationId Location Id of the Clinic
     * @return array              Assistants List User name and userId
     */
    protected function getAssistantsByDateAndLocation(string $date = '', int $locationId = 0) {
        if (!empty($date) && !empty($locationId)) {
            $assistantsList = Assistant::where(['service_date'=>$date, 'location_id'=>$locationId])->get();

            if (count($assistantsList) > 0) {
                $assistantId = $assistantsList->pluck('assistant_id');
                return ['assistant_list'=>getuserListByid($assistantId)];
            }
        }
        return []; 
    }

    /**
     * This method will be used to get Clinic Staff By Date And Location
     *
     * @param  string $date       Clinic service date
     * @param  int    $locationId Location Id of the Clinic
     * @return array              Examiner List User name and userId
     */
    protected function getClinicStaff(string $date = '', int $locationId = 0) {

        if (!empty($date) && !empty($locationId)) {
            $appointmentData = Appointment::join('users','users.id','=','appointments.user_id')
            ->where(['appointments.service_date'=>$date,'appointments.location_id'=>$locationId])
            ->select('appointments.*','users.name as user_name')
            ->get();

            return $appointmentData;
        }
        return [];
    }

    /**
     * This method will be used to create Invoice PDF
     *
     * @param  Illuminate\Http\Request $request
     */
    public function createInvoicePDF(Request $request) {

        try {
            $invoiceServiceDate = $request->invoiceServiceDate;
            $invoiceLocationId = $request->invoiceLocationId;
    
            $appointmentsData = Appointment::where(['service_date'=>$invoiceServiceDate, 'location_id'=>$invoiceLocationId, 'deleted'=>'0'])->where('invoice_url', '!=', '')->where('invoice_url', '!=', NULL)->groupBy('patient_id')->orderBy(DB::raw('CAST(service_time AS time)'),'ASC')->get();

            $clinicInfo = Location::where('id', '=', $invoiceLocationId)->first();
                        
            $clinicName = '';
            if ($clinicInfo) {
                if ($clinicInfo->name != '') {
                    $clinicName = $clinicInfo->name;
                } else {
                    $clinicName = $clinicInfo->actual_address;
                }
            }
            $clinicName = str_replace(', ', '_', $clinicName);
            $clinicName = preg_replace("/[^a-zA-Z0-9]/", "_", $clinicName);

        } catch (\Throwable $th) {
            return redirect()->back()->with('success', 'something went wrong!');
        }

        try {
    
            if (count($appointmentsData) > 0) {
                
                $findPdf = false;
                $oMerger = PDFMerger::init();
                $fileNameArray = [];
                foreach ($appointmentsData as $key => $appointmentData) {
                    
                    $combinedUrl = $appointmentData->invoice_url;
    
                    $urlFileName = basename($combinedUrl);

                    $signatureURL = signatureURL($appointmentData->invoice_url);

                    if (Storage::disk('s3')->exists('invoice/'.$urlFileName)) {
                        
                        $findPdf = true;

                        file_put_contents(public_path()."/".$urlFileName,file_get_contents($signatureURL));
    
                        $fileName = public_path()."/".$urlFileName;
                        $fileNameArray[] = $fileName;
                        // $oMerger->addPDF($fileName, $splitPage);
                        $oMerger->addPDF($fileName, 'all','P');
                    }
                   
                }

                if ($findPdf) {

                    try {
                        //To merge the pages having the page numbers passed in the array.
                        $oMerger->merge();
                        
                    } catch (\Exception $e) {
                        throw new \Exception("exception issue occurs");
                    }
                   
                    // Name the PDF
                    $saveFile = 'invoice_'.convertDate($request->invoiceServiceDate).'_'.$clinicName.'.pdf';
                    
                    // To download the pdf
                    $oMerger->save($saveFile, 'download');
                    
                    if (file_exists($saveFile)) {
                        unlink($saveFile);
                    }
                    
                    $len = count($fileNameArray);
                    for ($i=0; $i<$len; $i++) { 
                        if (file_exists($fileNameArray[$i])) {
                            unlink($fileNameArray[$i]);
                        }
                    }
        
                    return redirect()->back()->with('success','Invoice build successfully downloaded');
                }
                return redirect()->back()->with('success','Invoice are not available');
            }
    
            return redirect()->back()->with('success','Invoices are not found for that clinic and service date');

        } catch (\Throwable $th) {
            if ($th->getMessage() == 'exception issue occurs') {

                \Log::debug('under the ghost script merge function');
            
                $fileRemoveArray = [];
                $mergeFileNameArray = [];

                if (count($appointmentsData) > 0) {
                    foreach ($appointmentsData as $key => $appointmentData) {
        
                        $urlFileName = basename($appointmentData->invoice_url);
                        $signatureURL = signatureURL($appointmentData->invoice_url);
    
                        if (Storage::disk('s3')->exists('invoice/'.$urlFileName)) {
                            $findPdf = true;
                            file_put_contents(base_path()."/gsfolder/".$urlFileName,file_get_contents($signatureURL));
                            $fileName = base_path()."/gsfolder/".$urlFileName;
                            $fileRemoveArray[] = $fileName;
                            $mergeFileNameArray[] = $fileName;
                        }
                    }
    
                    $fileNames = implode(" ", $mergeFileNameArray);
                    $downloadFileName = 'invoice_'.convertDate($request->invoiceServiceDate).'_'.$clinicName.'.pdf';
                    $saveFile = base_path()."/gsfolder/".$downloadFileName;
                    $mergerFileRes = $this->mergerPdfFile($fileNames,$saveFile);
                    \Log::info('Merge File Response-'.$mergerFileRes);

                    $removeLen = count($fileRemoveArray);
                    for ($i=0; $i<$removeLen; $i++) { 
                        if (file_exists($fileRemoveArray[$i])) {
                            unlink($fileRemoveArray[$i]);
                        }
                    }
                    return response()->download($saveFile, $downloadFileName)->deleteFileAfterSend(true);
                }
            } else {
                return redirect()->back()->with('success', $th->getMessage());
            }
        }

    }

    /**
     * This method will be used to create CE Packet PDF
     *
     * @param  Illuminate\Http\Request $request
     */
    public function createCEPacketPDF(Request $request) {
        
        try {

            $cepacketServiceDate = $request->cepacketServiceDate;
            $cepacketLocationId = $request->cepacketLocationId;

            $appointmentsData = Appointment::where(['service_date'=>$cepacketServiceDate, 'location_id'=>$cepacketLocationId, 'deleted'=>'0'])->where('cepacket_url', '!=', '')->where('cepacket_url', '!=', NULL)->groupBy('patient_id')->orderBy(DB::raw('CAST(service_time AS time)'),'ASC')->get();

            if (count($appointmentsData) > 0) {

                $findPdf = false;
                $oMerger = PDFMerger::init();
                $fileNameArray = [];
                foreach ($appointmentsData as $key => $appointmentData) {

                    $combinedUrl = $appointmentData->cepacket_url;

                    $urlFileName = basename($combinedUrl);

                    $signatureURL = signatureURL($appointmentData->cepacket_url);

                    if (Storage::disk('s3')->exists('CEpacket/'.$urlFileName)) {

                        $findPdf = true;
                        file_put_contents(public_path()."/".$urlFileName,file_get_contents($signatureURL));

                        $fileName = public_path()."/".$urlFileName;

                        $fileNameArray[] = $fileName;

                        // $oMerger->addPDF($fileName, $splitPage);
                        $oMerger->addPDF($fileName, 'all', 'P');
                    }
                    
                }

                if ($findPdf) {
                    //To merge the pages having the page numbers passed in the array.
                    $oMerger->merge();

                    $clinicInfo = Location::where('id', '=', $cepacketLocationId)->first();
                    $clinicName = '';
                    if ($clinicInfo) {
                        if ($clinicInfo->actual_address != '') {
                            $clinicName = $clinicInfo->actual_address;
                        } else {
                            $clinicName = $clinicInfo->name;
                        }
                    }
                    // Name the PDF
                    $saveFile = 'records_'.convertDate($request->cepacketServiceDate).'_'.$clinicName.'.pdf';

                    // To download the pdf
                    $oMerger->save($saveFile, 'download');
                    
                    if (file_exists($saveFile)) {
                        unlink($saveFile);
                    }

                    $len = count($fileNameArray);
                    for ($i=0; $i<$len; $i++) { 
                        if (file_exists($fileNameArray[$i])) {
                            unlink($fileNameArray[$i]);
                        }
                    }

                    return redirect()->back()->with('success','Records successfully downloaded!');
                }
                return redirect()->back()->with('success','Record are not available');
            }
            return redirect()->back()->with('success','Records has not found for that clinic and service date');
            
        } catch (\Throwable $th) {
            return redirect()->back()->with('success',$th->getMessage());
        }


    }

    /**
     * This method will be used to get clinic details to edit
     *
     * @param  Illuminate\Http\Request $request
     */
    public function getdataforEdit(Request $request) {

        $validator = Validator::make($request->all(), [
            'date' => 'required',
            'location' => 'required'
        ]);

        if($validator->fails()) {
            return response()->json(['status'=>false,'data'=>[],'msg'=>$validator->errors()->first()]);
        }

        $appointmentData = Appointment::join('locations','locations.id','=','appointments.location_id')
        ->join('states','states.id','=','locations.state_id')
        ->where('appointments.service_date',$request->date)
        ->where('appointments.location_id',$request->location)
        ->orderBy('appointments.service_date','DESC')
        ->select('appointments.*','locations.name as location_name','locations.actual_address as location_address')
        ->first();
        
        if ($appointmentData) {
            
            $editServiceDate = convertDate($request->date);

            // Get Examiners By Date And Location
            $examinersData = $this->getExaminersByDateAndLocation($request->date, $request->location);

            if (count($examinersData) > 0 ) {
                $examinerList = $examinersData['examiner_list']['user_id'];
            } else {
                $examinerList = $this->getAllexaminer($request->date, $request->location)['user_id'];
                
            }

            // Get Assistants By Date And Location
            $assistantData = $this->getAssistantsByDateAndLocation($request->date, $request->location);
            if (count($assistantData) > 0 ) {
                $assistantList = $assistantData['assistant_list']['user_id'];
            } else {
                $assistantList = '';
            }

            return response()->json(['status'=>true,'data'=>$appointmentData,'edit_service_date'=>$editServiceDate,'examiner_list'=>$examinerList,'assistant_list'=>$assistantList]);
        }
        return response()->json(['status'=>false,'data'=>$appointmentData,'examiner_list'=>[]]); 

    }
    
    /**
     * This method is used to add a Clinic Service
     *
     * @param  Illuminate\Http\Request $request
     */
    public function addClinicService(Request $request) {

        $validator = Validator::make($request->all(), [
            'clinicName' => 'required',
            'serviceDate' => 'required'
        ]);

        if ($validator->passes()) {

            $serviceDate = convertDateIST($request->serviceDate);

            $checkClinic = Appointment::where(['service_date'=>$serviceDate,'location_id'=>$request->clinicName,'deleted'=>'0'])->first();
            
            if ($checkClinic) {
                return response()->json(['status'=>false, 'msg'=>'Clinic Service already exists for this date at this location']);
            } else {
                $saveResponse = Appointment::create([
                    'service_date' => $serviceDate, 
                    'location_id' => $request->clinicName,
                    'created_at' => Carbon::now()
                ]);
                
                if ($saveResponse) {
                    if (is_array($request->addExaminerList)) {
                        $insertExaminer = [];
                        foreach ($request->addExaminerList as $key => $examinerList) {
                            $insertExaminer[$key]['service_date'] = $saveResponse->service_date;
                            $insertExaminer[$key]['location_id'] = $saveResponse->location_id;
                            $insertExaminer[$key]['examiner_id'] = $examinerList;
                            $insertExaminer[$key]['created_at'] = Carbon::now();
                        }
                        Examiner::insert($insertExaminer);
                    }
                    if (is_array($request->addAssistantList)) {
                        $insertAssistant = [];
                        foreach ($request->addAssistantList as $key => $assistantList) {
                            $insertAssistant[$key]['service_date'] = $saveResponse->service_date;
                            $insertAssistant[$key]['location_id'] = $saveResponse->location_id;
                            $insertAssistant[$key]['assistant_id'] = $assistantList;
                            $insertAssistant[$key]['created_at'] = Carbon::now();
                        }
                        Assistant::insert($insertAssistant);
                    }
                } else {
                    return response()->json(['status'=>false, 'msg'=>'Something went wrong!']);
                }
            }

            return response()->json(['status'=>true, 'msg'=>'Clinic Service added successfully']);
        }

        return response()->json(['status'=>false, 'msg'=>$validator->errors()->first()]);

    }

    /**
     * This method will be used to update clinic service details
     *
     * @param  Illuminate\Http\Request $request
     */
    public function updateClinicService(Request $request) {

        $validator = Validator::make($request->all(), [
            'service_date' => 'required',
            'location' => 'required'
        ]);

        if ($validator->fails()) {
            return response()->json(['status'=>false, 'data'=>[], 'msg' => $validator->errors()->first()]);
        }

        $newServiceDate = convertDateIST($request->service_date);
        $newclinicLocation = $request->location;

        $insertHistory = $this->saveClinicHistory($request->preServiceDate, $request->preclinicLocation);

        if ($insertHistory) {

            if ($request->preServiceDate == $newServiceDate && $request->preclinicLocation == $newclinicLocation) {
            } else {

                $newClinicData = Appointment::where(['service_date'=>$newServiceDate,'location_id'=>$newclinicLocation,'deleted'=>0])->first();
                $newClinicStatus = 0;
                $newClinicReason = '';   
                if ($newClinicData) {
                    $newClinicStatus = $newClinicData->clinic_status;
                    $newClinicReason = $newClinicData->clinic_reason;
                }
                Appointment::where(['service_date'=>$request->preServiceDate, 'location_id'=>$request->preclinicLocation])->update([
                    'service_date'=>$newServiceDate,
                    'location_id'=>$newclinicLocation,
                    'merged_invoice_status'=>'0',
                    'merged_invoice_url'=>'',
                    'merged_record_status'=>'0',
                    'merged_record_url'=>'',
                    'clinic_status'=>$newClinicStatus,
                    'clinic_reason'=>$newClinicReason,
                ]);
            }
                
            //delete Examiner records
            Examiner::where(['service_date'=>$request->preServiceDate, 'location_id'=>$request->location])->delete();

            //delete Assistants records
            Assistant::where(['service_date'=>$request->preServiceDate, 'location_id'=>$request->location])->delete();

            if (is_array($request->examiner_list)) {
                $this->insertExaminer($request->examiner_list, $request->service_date, $request->location);
            }

            if (is_array($request->assistant_list)) {
                $this->insertAssistant($request->assistant_list, $request->service_date, $request->location);
            }

            Appointment::where(['service_date'=>$newServiceDate, 'location_id'=>$newclinicLocation])->update([
                'user_id'=>0
            ]);

            
            return response()->json(['status'=>true, 'msg'=>'Clinic Service details successfully updated']);
        } else {
            return response()->json(['status'=>false, 'msg'=>'Error in saving history of patient']);
        }

        return response()->json(['status'=>false, 'msg'=>'something went wrong to update Clinic Service details']);
    }

    /**
     * This method will be used to insert Clinic Examiner in the database
     *
     * @param array  $examiner   All details of Examiner
     * @param string $date       Clinic service date
     * @param int    $locationId Location Id of the Clinic
     */
    public function insertExaminer(array $examiner, string $date = '', int $locationId = 0) {
        if (!empty($date) && !empty($locationId)) {
            $insertExaminer = [];
            if (is_array($examiner)) {
                foreach ($examiner as $key => $examinerList) {
                    $insertExaminer[$key]['service_date'] = convertDateIST($date);
                    $insertExaminer[$key]['location_id'] = $locationId;
                    $insertExaminer[$key]['examiner_id'] = $examinerList;
                    $insertExaminer[$key]['created_at'] = Carbon::now();
                }
                return Examiner::insert($insertExaminer);
            } else {
                return [];
            }
        }
        return [];
    }

    /**
     * This method will be used to insert Clinic Assistant in the database
     *
     * @param array  $assistant  All details of Assistant
     * @param string $date       Clinic service date
     * @param int    $locationId Location Id of the Clinic
     */
    public function insertAssistant(array $assistant, string $date = '', int $locationId = 0) {
        if (!empty($date) && !empty($locationId)) {
            $insertAssistant = [];
            if (is_array($assistant)) {
                foreach ($assistant as $key => $assistantList) {
                    $insertAssistant[$key]['service_date'] = convertDateIST($date);
                    $insertAssistant[$key]['location_id'] = $locationId;
                    $insertAssistant[$key]['assistant_id'] = $assistantList;
                    $insertAssistant[$key]['created_at'] = Carbon::now();
                }
                return Assistant::insert($insertAssistant);
            } else {
                return [];
            }
        }
        return [];
    }

    /**
     * This method will be used to count sticky notes By Date And Location
     *
     * @param  string $date       Clinic service date
     * @param  int    $locationId Location Id of the Clinic
     * @return array              Examiner List User name and userId
     */
    public function stickyNoteCount(string $date = '', int $locationId = 0) {
        $totalCount = 0;
        if (!empty($date) && !empty($locationId)) {
            $appointmentList = Appointment::where(['service_date'=>$date, 'location_id'=>$locationId])->get();
            if ($appointmentList) {
                $idList = $appointmentList->pluck('id');
                $totalCount = StickyNote::whereIn('appointment_id', $idList)->where('deleted', '0')->count();
            }
        }
       return $totalCount;
    }

    /**
     * This method is used to cancel clinic appointments for a date
     *
     * @param Illuminate\Http\Request $request
     */
    public function cancelClinicService(Request $request) {
       
        $response = [];
        $serviceDate = $request->serviceDate;
        $locationId = $request->locationId;
        $actionStatus = $request->actionStatus;
        $comment = isset($request->cancel_comment) ? $request->cancel_comment : '';

        if ($serviceDate == '') {
            $response['status'] = false;
            $response['msg'] = 'Service Date is required';
            return response()->json($response);
        }

        if ($locationId == '') {
            $response['status'] = false;
            $response['msg'] = 'Location Id is required';
            return response()->json($response);
        }

        $insertHistory = $this->saveClinicHistory($serviceDate, $locationId);

        if ($insertHistory) {
            if ($actionStatus == $_ENV['APPT_STATUS_CANCEL']) {
                $appointmentsData = Appointment::where(['service_date'=>$serviceDate, 'location_id'=>$locationId, 'status'=>'0', 'deleted'=>'0'])->update([
                    'status'=>$_ENV['APPT_STATUS_CANCEL'],
                    'status_text' => $comment
                ]);

                if ($appointmentsData) {
                    $response['status'] = true;
                    $response['msg'] = 'Appointments cancelled successfully';
                } else {
                    $response['status'] = false;
                    $response['msg'] = 'Something went wrong!';
                }

            } else if ($actionStatus == 0) {
                $appointmentsData = Appointment::where(['service_date'=>$serviceDate, 'location_id'=>$locationId, 'status'=>$_ENV['APPT_STATUS_CANCEL'], 'deleted'=>'0'])->update([
                    'status'=>'0'
                ]);

                if ($appointmentsData) {
                    $response['status'] = true;
                    $response['msg'] = 'Appointments re-activated successfully';
                } else {
                    $response['status'] = false;
                    $response['msg'] = 'Something went wrong!';
                }
            } else {
                $response['status'] = false;
                $response['msg'] = 'Something went wrong!';
            }

        } else {
            $response['status'] = false;
            $response['msg'] = 'Something went wrong!';
        }    

        return response()->json($response);
    }

    /**
     * This method is used to delete clinic appointments for a date
     *
     * @param Illuminate\Http\Request $request
     */
    public function deleteClinicService(Request $request) {
       
        $response = [];
        $serviceDate = $request->serviceDate;
        $locationId = $request->locationId;

        if ($serviceDate == '') {
            $response['status'] = false;
            $response['msg'] = 'Service Date is required';
            return response()->json($response);
        }

        if ($locationId == '') {
            $response['status'] = false;
            $response['msg'] = 'Location Id is required';
            return response()->json($response);
        }

        $insertHistory = $this->saveClinicHistory($serviceDate, $locationId);

        if ($insertHistory) {
            $appointmentsData = Appointment::where(['service_date'=>$serviceDate, 'location_id'=>$locationId, 'deleted'=>'0'])->update([
                'deleted'=>'1'
            ]);
            if ($appointmentsData) {
                $response['status'] = true;
                $response['msg'] = 'Clinic deleted successfully';
            } else {
                $response['status'] = false;
                $response['msg'] = 'Something went wrong!';
            }
        } else {
            $response['status'] = false;
            $response['msg'] = 'Something went wrong!';
        }    

        return response()->json($response);
    }

    /**
     * This method is used to update designation color of a clinic appointments for a date
     *
     * @param Illuminate\Http\Request $request
     */
    public function updateClinicColor(Request $request) {
       
        $response = [];
        $serviceDate  = $request->serviceDate;
        $locationId   = $request->locationId;
        $clinicStatus = $request->clinicStatus;
        $clinicReason = $request->clinicReason;

        if ($serviceDate == '') {
            $response['status'] = false;
            $response['msg'] = 'Service Date is required';
            return response()->json($response);
        }

        if ($locationId == '') {
            $response['status'] = false;
            $response['msg'] = 'Location Id is required';
            return response()->json($response);
        }

        $updateColor = Appointment::where(['service_date'=>$serviceDate, 'location_id'=>$locationId, 'deleted'=>'0'])->update([
            'clinic_status'=>$clinicStatus,
            'clinic_reason'=>$clinicReason
        ]);

        if ($updateColor) {
            $response['status'] = true;
            $response['msg'] = 'Clinic color has been changed successfully';
        } else {
            $response['status'] = false;
            $response['msg'] = 'Something went wrong!';
        }
           

        return response()->json($response);
    }

    /**
     * This method will be used to save clinic history By Date And Location
     *
     * @param  string $date       Clinic service date
     * @param  int    $locationId Location Id of the Clinic
     * @return array              Examiner List User name and userId
     */
    public function saveClinicHistory(string $date = '', int $locationId = 0) {
        if (!empty($date) && !empty($locationId)) {
            $oldPatientRecords = Appointment::where(['service_date'=>$date, 'location_id'=>$locationId])->get();
            
            if (count($oldPatientRecords) > 0) {
                $examinersData = $this->getExaminersByDateAndLocation($date, $locationId);

                if (count($examinersData) > 0) {
                    $examinerIds = $examinersData['examiner_list']['user_id'];
                } else {
                    $examinerIds = $this->getAllexaminer($date, $locationId)['user_id'];
                }

                $assistantData = $this->getAssistantsByDateAndLocation($date, $locationId);

                if (count($assistantData) > 0) {
                    $assistantIds = $assistantData['assistant_list']['user_id'];
                } else {
                    $assistantIds = '';
                }

                $saveClinichistory = [];
                foreach ($oldPatientRecords as $key => $oldPatientRecord) {
                    $saveClinichistory[$key]['appointment_id'] = $oldPatientRecord->id;
                    $saveClinichistory[$key]['service_date'] = $oldPatientRecord->service_date;
                    $saveClinichistory[$key]['service_time'] = $oldPatientRecord->service_time;
                    $saveClinichistory[$key]['patient_id'] = $oldPatientRecord->patient_id;
                    $saveClinichistory[$key]['user_id'] = $oldPatientRecord->user_id;
                    $saveClinichistory[$key]['location_id'] = $oldPatientRecord->location_id;
                    $saveClinichistory[$key]['invoice_url'] = $oldPatientRecord->invoice_url;
                    $saveClinichistory[$key]['cepacket_url'] = $oldPatientRecord->cepacket_url;
                    $saveClinichistory[$key]['combined_url'] = $oldPatientRecord->combined_url;
                    $saveClinichistory[$key]['type_of_exam'] = $oldPatientRecord->type_of_exam;
                    $saveClinichistory[$key]['request_status'] = $oldPatientRecord->request_status;
                    $saveClinichistory[$key]['special_instruction'] = $oldPatientRecord->special_instruction;
                    $saveClinichistory[$key]['case_id'] = $oldPatientRecord->case_id;
                    $saveClinichistory[$key]['status'] = $oldPatientRecord->status;
                    $saveClinichistory[$key]['status_text'] = $oldPatientRecord->status_text;
                    $saveClinichistory[$key]['active'] = $oldPatientRecord->active;
                    $saveClinichistory[$key]['deleted'] = $oldPatientRecord->deleted;
                    $saveClinichistory[$key]['examiner_id'] = $examinerIds;
                    $saveClinichistory[$key]['assistant_id'] = $assistantIds;
                    $saveClinichistory[$key]['updated_by'] = Auth::user()->id;
                    $saveClinichistory[$key]['created_at'] = Carbon::now();
                    $saveClinichistory[$key]['updated_at'] = Carbon::now();
                }

                // Save previous history of patient
                return ClinicHistory::insert($saveClinichistory);
            }
            return false;
        }
        return false;
    }

    /**
     * This method will be used to find Clinic Documents By Date And Location
     *
     * @param  string $date       Clinic service date
     * @param  int    $locationId Location Id of the Clinic
     * @return array              Examiner List User name and userId
     */
    protected function findClinicDocuments(string $date = '', int $locationId = 0) {
        if (!empty($date) && !empty($locationId)) {
            $scrapModel = new ScrapModel();
            $DocumentList = $scrapModel->select_query('clinic_documents', ['service_date'=> $date ,'location_id' => $locationId, 'deleted'=>'0']);

            return $DocumentList;
        }
        return [];
    }

    /**
     * This method is used to merge and download clinic documents
     *
     * @param Illuminate\Http\Request $request
     */
    public function MergeAndDownloadClinicDocument(Request $request) {

        try {

            $validator = Validator::make($request->all(), [
                'service_date' => 'required',
                'location' => 'required'
            ]);

            if ($validator->fails()) {

                return redirect()->back()->with('success',$validator->errors()->first());
            }

            $serviceDate = $request->service_date;
            $location = $request->location;

            $DocumentList = $this->findClinicDocuments($serviceDate, $location);
            
            if (count($DocumentList) > 0) {
    
                $oMerger = PDFMerger::init();

                foreach ($DocumentList as $doclist) {

                    $combinedUrl = $doclist->path;

                    $urlFileName = basename($combinedUrl);

                    $signatureURL = signatureURL($combinedUrl);

                    file_put_contents(public_path()."/".$urlFileName,file_get_contents($signatureURL));

                    $fileName = public_path()."/".$urlFileName;

                    $oMerger->addPDF($fileName, 'all');
                    
                }

                //To merge the pages.
                $oMerger->merge();

                // Name the PDF
                $saveFile = 'clinicDocuments_'.date("mdYHis").'.pdf';

                // To download the pdf
                $oMerger->save($saveFile, 'download');
                
                if (file_exists($saveFile)) {
                    unlink($saveFile);
                }

                if (file_exists($fileName)) {
                    unlink($fileName);
                }

                return redirect()->back()->with('success', 'Document has successfully downloaded');
            }

            return redirect()->back()->with('success', 'Document not available');

        } catch (\Throwable $th) {

            return redirect()->back()->with('success', $th->getMessage());
        }
    }

    /**
     * This method is used to add or update on call statement
     *
     * @param  Illuminate\Http\Request $request
     */
    public function addOnCallStatement(Request $request) {

        $validator = Validator::make($request->all(), [
            'onCallStatement' => 'required'
        ]);

        if ($validator->passes()) {
            $checkStatement = DB::table('on_call_statement')->first();
           
            if ($checkStatement) {
                $saveResponse = DB::table('on_call_statement')->update([
                    'statement' => $request->onCallStatement,
                    'updated_at' => Carbon::now()
                ]);
            } else {
                $saveResponse = DB::table('on_call_statement')->insert([
                    'statement' => $request->onCallStatement,
                    'created_at' => Carbon::now()
                ]);
            }
                
            if ($saveResponse) {
                return response()->json(['status'=>true, 'msg'=>'On call number updated successfully', 'statement'=>$request->onCallStatement]);
            } else {
                return response()->json(['status'=>false, 'msg'=>'Something went wrong!']);
            }
        }
        return response()->json(['status'=>false, 'msg'=>$validator->errors()->first()]);
    }

    public function getOnCallStatement() {

        $statement = '';

        $onCallStatement = DB::table('on_call_statement')->first();
        if ($onCallStatement) {
            $statement = $onCallStatement->statement;
        }
        return $statement;
    }

    public function searchExaminee(Request $request) {

        if (preg_match("/^(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])-[0-9]{4}$/", $request->searchKeyword)) {
            $request->searchKeyword = convertDateIST($request->searchKeyword);
        }

        $patientData = Appointment::join('patients','patients.id','=','appointments.patient_id')
                            ->join('locations','locations.id','=','appointments.location_id')
                            ->join('states','states.id','=','locations.state_id')
                            ->where('patients.first_name','like','%'.$request->searchKeyword.'%')
                            ->where('appointments.deleted','=','0')
                            ->orWhere('patients.phone','like','%'.$request->searchKeyword.'%')
                            ->orWhere('patients.dob','like','%'.$request->searchKeyword.'%')
                            ->orWhere('appointments.case_id','like','%'.$request->searchKeyword.'%')
                            ->select(DB::raw("DATE_FORMAT(appointments.service_date, '%m-%d-%Y') as appointment_date"),'appointments.location_id','appointments.id','locations.name as clinic_name','states.name as state_name','patients.first_name as examinee_name','patients.phone as examinee_phone',DB::raw("DATE_FORMAT(patients.dob, '%m-%d-%Y') as examinee_dob"),'appointments.case_id','appointments.service_date')
                            ->get();
                            
        foreach ($patientData as $patient)
        {
            if ($patient->examinee_phone != '') {
                $patient->examinee_phone = formatPhoneNumber($patient->examinee_phone);
            } else {
                $patient->examinee_phone = '';
            }

            if ($patient->case_id == '') {
                $patient->case_id = '';
            }

            if ($patient->examinee_dob == '') {
                $patient->examinee_dob = '';
            }
        }

        if ($patientData) {
            if (count($patientData) > 0) {
                return response()->json(['status'=>true,'data'=>$patientData]);
            } else {
                return response()->json(['status'=>false,'msg'=>'no examinee found!']);
            }
        } else {
            return response()->json(['status'=>false,'msg'=>'something went wrong!']);
        }
    }

    public function masterExport(Request $request) {

        $fromDate = $request->from_date;
        $toDate   = $request->to_date;
        
        $fileName = "master_export_".$fromDate."_".$toDate." '.xls";

        $appointmentDataList = getAppointmentListByDate($fromDate, $toDate);

        if (count($appointmentDataList) > 0) {

            return view('clinic.multipleExportFile', compact('appointmentDataList','fileName'));
        } else {
            return redirect()->back()->with('status', 'No clinic found for selected date range!');
        }
    }

    public function downloadMergedInvoice(Request $request) {

        $validator = Validator::make($request->all(), [
            'mergedinvoiceServiceDate' => ['required'],
            'mergedinvoiceLocationId' => ['required']
        ]);

        if ($validator->fails()) {

            return redirect()->back()->with('status',$validator->errors()->first());
        }

        $invoiceServiceDate = $request->mergedinvoiceServiceDate;
        $invoiceLocationId = $request->mergedinvoiceLocationId;

        $appointmentsData = Appointment::where(['service_date'=>$invoiceServiceDate, 'location_id'=>$invoiceLocationId, 'deleted'=>'0'])->where('merged_invoice_url', '!=', '')->where('merged_invoice_url', '!=', NULL)->where('merged_invoice_status', '1')->first();
        
        if ($appointmentsData) {
            $clinicInfo = Location::where('id', '=', $invoiceLocationId)->first();
                        
            $clinicName = '';
            if ($clinicInfo) {
                if ($clinicInfo->name != '') {
                    $clinicName = $clinicInfo->name;
                } else {
                    $clinicName = $clinicInfo->actual_address;
                }
            }
            $clinicName = str_replace(', ', '_', $clinicName);
            $clinicName = preg_replace("/[^a-zA-Z0-9]/", "_", $clinicName);

            $urlFileName = basename($appointmentsData->merged_invoice_url);
            $downloadFileName = 'invoice_'.convertDate($invoiceServiceDate).'_'.$clinicName.'.pdf';

            if (Storage::disk('s3')->exists('clinicInvoice/'.$urlFileName)) {
                $filePath = 'clinicInvoice/'.$urlFileName;
                $file = Storage::disk('s3')->get($filePath);
                $mimeType = Storage::disk('s3')->getDriver()->getMimetype($filePath); 
                $mimeSize = Storage::disk('s3')->getDriver()->getSize($filePath);

                $headers = [
                'Content-Type' => $mimeType, 
                'Content-Description' => 'File Transfer',
                "Content-Length" => $mimeSize,
                'Content-Disposition' => "attachment; filename=".$downloadFileName
                ];
        
                return response($file, 200, $headers);
            } else {
                return redirect()->back()->with('success','Merged Invoice not available!');
            }
        }
        return redirect()->back()->with('success','Merged Invoice not prepared for the clinic on this date!');

    }

    public function downloadMergedRecord(Request $request) {

        $validator = Validator::make($request->all(), [
            'mergedRecordServiceDate' => ['required'],
            'mergedRecordLocationId' => ['required']
        ]);

        if ($validator->fails()) {

            return redirect()->back()->with('status',$validator->errors()->first());
        }
        
        $recordServiceDate = $request->mergedRecordServiceDate;
        $recordLocationId = $request->mergedRecordLocationId;
    
        $appointmentsData = Appointment::where(['service_date'=>$recordServiceDate, 'location_id'=>$recordLocationId, 'deleted'=>'0'])->where('merged_record_url', '!=', '')->where('merged_record_url', '!=', NULL)->where('merged_record_status', '1')->first();
        
        if ($appointmentsData) {
            $clinicInfo = Location::where('id', '=', $recordLocationId)->first();
                        
            $clinicName = '';
            if ($clinicInfo) {
                if ($clinicInfo->name != '') {
                    $clinicName = $clinicInfo->name;
                } else {
                    $clinicName = $clinicInfo->actual_address;
                }
            }
            $clinicName = str_replace(', ', '_', $clinicName);
            $clinicName = preg_replace("/[^a-zA-Z0-9]/", "_", $clinicName);
    
            $urlFileName = basename($appointmentsData->merged_record_url);
            $downloadFileName = 'record_'.convertDate($recordServiceDate).'_'.$clinicName.'.pdf';
    
            if (Storage::disk('s3')->exists('clinicRecords/'.$urlFileName)) {
                $filePath = 'clinicRecords/'.$urlFileName;
                $file = Storage::disk('s3')->get($filePath);
                $mimeType = Storage::disk('s3')->getDriver()->getMimetype($filePath); 
                $mimeSize = Storage::disk('s3')->getDriver()->getSize($filePath);
    
                $headers = [
                'Content-Type' => $mimeType, 
                'Content-Description' => 'File Transfer',
                "Content-Length" => $mimeSize,
                'Content-Disposition' => "attachment; filename=".$downloadFileName
                ];
        
                return response($file, 200, $headers);
            } else {
                return redirect()->back()->with('success','Merged Record not available!');
            }
        }
        return redirect()->back()->with('success','Merged Record not prepared for the clinic on this date!');
    
    }

    public function mergerPdfFile($fileArray,$outputFileName) {

        try {
            
            //Create the GhostScript command for extract the particular pages from pdf
            $gsCmd = 'gs -dBATCH -dNOPAUSE -q -sDEVICE=pdfwrite -sOutputFile='.$outputFileName.' '.$fileArray.'';

            \Log::debug('ghostscript merger command'.$gsCmd);

            // return $gsCmd;
            //Run it using PHP's exec function.
            $output = array();
            $return = null;
            $cmd = exec($gsCmd,$output,$return);

            if ($return != 0) {
                \Log::debug('under the failed file merge response');
                return false;
            } else {
                \Log::debug('under the success file merge response');
                return $cmd;
            }

        } catch (\Exception $e) {
            echo "under the merge pdf function-".$e->getMessage();
            return false;
        }
    }

    public function changeXraysStatus(Request $request) {
     
        if ($request->xraysValue == true) {
            $xrayStatus = '1';
        } else {
            $xrayStatus = '2';
        }
        
        $updatedStatus = Appointment::where(['service_date'=>$request->service_date, 'location_id'=>$request->location_id,'deleted'=>'0'])->update([
            'xray_checkbox'=> $xrayStatus
        ]);
        
        if ($updatedStatus) {
            return response()->json(['status'=>true, 'msg'=>'Xrays value updated successfully!']);
        } else {
            return response()->json(['status'=>false, 'msg'=>'Something went wrong!']); 
        }
    }

}