<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Goutte\Client;
use Symfony\Component\DomCrawler\Crawler;
use Illuminate\Support\Facades\DB;
use App\Models\ScrapModel;
use Illuminate\Support\Facades\Storage;
use mikehaertl\pdftk\Pdf;
use Symfony\Component\HttpClient\HttpClient;
use Illuminate\Support\Facades\Crypt;
use LynX39\LaraPdfMerger\Facades\PdfMerger as PDFMerger;

/**
* This class is used to scrap the data from ERE Portal.
*
* PHP version 7.4.23
*
* @category  Supporting Script
* @package   Webscrap Integration 
* @author    Chetu
* @copyright 2021 Moonlight Examination.
*/
class WebscrapController extends Controller {
    
    /**
    * This function is used to load model and config constant.
    */
    public function __construct() {

        $this->scrapmodel = new ScrapModel();
        // echo $this->scrapmodel->insert_query('appointments',['service_date'=>'1970-01-01','service_time'=>'03:00 PM','patient_id'=>'2','location_id'=>'4','user_id'=>'12','special_instruction'=>'','special_instruction'=>'PENDING']);
        // echo $this->saveAppointmentData(['appt_date' => '2022-01-05','appt_time' =>'03:00 PM','pateint_id' => '2','provider_id' => '12','location_id' => '4','special_intruction'=>'','request_status'=>'PENDING']);
        // die;

        $this->scrapFields = config('constants.scrapFields');

        $this->scrapStatus = config('constants.scrapStatus');

        $this->client = new Client(HttpClient::create(['timeout' => 560]));
    }

    /**
    * This function will be used to access the ERE Portal.
    *
    * @param  string $username  username for login 
    * @param  string $password  pasword for login
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function LoginIntoEREPortal($username,$password) {
        
        $url = config('constants.loginUrl'); // get from config/constants.php

        $LoginResponse = $this->client->request('POST',$url,[
            'uid'=>$username,
            'password'=>$password,
            'BTN_NEXT'=>"Sign+In"
        ],[],[
            'HTTP_CONTENT_TYPE' => 'application/x-www-form-urlencoded',
            'Origin'=>'https://secure.ssa.gov',
            'Referer'=>'https://secure.ssa.gov/acu/iresear/login?URL=%2Fapps9%2FEREHome%2FErhm01View'
        ]);
       
        if (isset($this->client->getResponse()->getHeaders()['x-xss-protection'])) {
            return false;
        } else {
            return $LoginResponse;    
        }
         
    }

    /**
    * This function is used to scrap the data from ERE Website Portal, this function is call to when cron has executed.
    *
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function ScrapDataFromEREPortal() {

        ini_set('memory_limit','-1');

        $StateCrendentialList = $this->scrapmodel->getStateCrendentails();

        if (count($StateCrendentialList) > 0) {

            foreach ($StateCrendentialList as $key => $stateval) {
                
                try {
                    
                    \Log::debug('CRON has started to run');
                    //this is used to store field indexes data
                    $StatusIndexArray = [];

                    //this is used to store temperory scrapped data 
                    $ScrappedDataArray = []; 

                    $totalRecord = 0;//used as total record counter

                    $scrappedRecord = 0;//used as total scrapped record counter

                    // if ($stateval->id == 2) {

                    //     continue;
                    // }

                    $CronStartTime = date("Y-m-d H:i:s");

                    $StatusIndexArray['state_id'] = $stateval->id;

                    //decrypt password.
                    $loginPassword = Crypt::decryptString($stateval->user_password);

                    //this function is used to login into the ERE Web portal.
                    $crawler = $this->LoginIntoEREPortal($stateval->user_name,$loginPassword);
                    
                    if (!$crawler) {
                        $err = 'Please Check your Login crendentials';
                        // \Log::Info();
                        \Log::info('unable to login for this state id-'.$stateval->id);
                        throw new \Exception('unable to login for that state');
                    }

                    $crawler = $this->client->click($crawler->selectLink('Access Electronic Requests')->link());

                    //used for getting table headings from the ERE Website List Page.
                    $crawler->filter('thead tr')->each(function ($node,$key) use (&$StatusIndexArray,&$ScrappedDataArray) {

                        $ScrappedDataArray = [];

                        $object = json_encode($node->children()->each(function($childNode) {
                            return $childNode->text();
                        }));

                        $datas = json_decode($object);

                        for ($i=0; $i < count($datas); $i++) { 
                            
                            if (isset($this->scrapFields['request_status']) && $datas[$i] == $this->scrapFields['request_status']) {
                                $StatusIndexArray['request_status'] = $i;
                            }
                            if (isset($this->scrapFields['appt_date']) && $datas[$i] == $this->scrapFields['appt_date']) {
                                $StatusIndexArray['appt_date'] = $i;
                            }
                            if (isset($this->scrapFields['appt_time']) && $datas[$i] == $this->scrapFields['appt_time']) {
                                $StatusIndexArray['appt_time'] = $i;
                            }
                            if (isset($this->scrapFields['request_date']) && $datas[$i] == $this->scrapFields['request_date']) {
                                $StatusIndexArray['request_date'] = $i;
                            }
                            if (isset($this->scrapFields['ssn_no']) && $datas[$i] == $this->scrapFields['ssn_no']) {
                                $StatusIndexArray['ssn_no'] = $i;
                            }
                            if (isset($this->scrapFields['patient_name']) && $datas[$i] == $this->scrapFields['patient_name']) {
                                $StatusIndexArray['patient_name'] = $i;
                            }
                        }
                    });
                    
                    //For check the Request Status key
                    if (!isset($StatusIndexArray['request_status'])) {
                        // throw new \Exception("Can't be find the REQUEST STATUS COLUMN", 1);
                        // Error logging with full information
                        \Log::info('unable to find request status key for this state_id-'.$stateval->id);
                        throw new \Exception('does not found request status heading for this state');
                                       
                    }

                    $crawler->filter('tbody tr')->each(function ($node,$key) use (&$StatusIndexArray,&$ScrappedDataArray,&$totalRecord,&$scrappedRecord,&$CronStartTime) {

                        try {

                            $object = json_encode($node->children()->each(function ($childNode) {
                                return $childNode->text();
                            }));
                            
                            $datas = json_decode($object);

                            if ($datas[$StatusIndexArray['request_status']] == $this->scrapStatus) {

                                $appt_datekey = isset($this->scrapFields['appt_date']) ? $this->scrapFields['appt_date'] : "appt_date";

                                $appt_timekey = isset($this->scrapFields['appt_time']) ? $this->scrapFields['appt_time'] : "appt_time";

                                $ScrappedDataArray['patient_name'] = isset($StatusIndexArray['patient_name']) ? $datas[$StatusIndexArray['patient_name']] : "";
                                $ScrappedDataArray['ssn_no'] = isset($StatusIndexArray['ssn_no']) ? $datas[$StatusIndexArray['ssn_no']] : "";
                                $ScrappedDataArray['request_date'] = isset($StatusIndexArray['request_date']) ? date("m-d-Y",strtotime($datas[$StatusIndexArray['request_date']])) : "";
                                $ScrappedDataArray[$appt_datekey] = isset($StatusIndexArray['appt_date']) ? $datas[$StatusIndexArray['appt_date']] : "";
                                $ScrappedDataArray[$appt_timekey] = isset($StatusIndexArray['appt_time']) ? date("H:i:s",strtotime($datas[$StatusIndexArray['appt_time']])) : "";
                                $ScrappedDataArray['request_status'] = isset($StatusIndexArray['request_status']) ? $datas[$StatusIndexArray['request_status']] : "";
                                $ScrappedDataArray['link_text'] = $node->children()->filter('a')->first()->text();

                                $selectlink = $node->children()->filter('a')->first();
                                $crawler = $this->client->click($node->selectLink($selectlink->text())->link());
                              

                                //this is used to scrap the patient details page data.
                                $datas1 = $crawler->filter('div.yui3-u-1-2 .content')->each(function ($node_child) use (&$ScrappedDataArray) {
                                    // print_r($node_child->text());
                                    $expl = explode("<br>",$node_child->html());
                                    $save_data_arr = [];

                                    foreach ($expl as $key => $value) {
                                        $expldata = explode("<strong>", $value);
                                        $expldata[0] = str_replace(array("#", "'", ";",":",":-"), '', trim($expldata[0]));
                                        $expldata[1] = strip_tags(trim($expldata[1]));
                                        $ScrappedDataArray[$expldata[0]] = $expldata[1];
                                    }

                                });

                                //this is used to find the special instruction and item descripiton. 
                                $service_data = $crawler->filter('div.uef-container div.bd div > p')->each(function ($node_child) use (&$ScrappedDataArray) {
                                    // print_r($node_child->text());
                                    $service_d = [];
                                    $text_split = explode(":", $node_child->text());
                                    if(count($text_split) > 0 && isset($this->scrapFields['special_intruction']) && $text_split[0] == $this->scrapFields['special_intruction']) {
                                        $ScrappedDataArray[$text_split[0]] = $text_split[1];
                                    }
                                
                                });

                                //this is used to find services/typeofexams  datas
                                $servicedata = $crawler->filter('div.content div.uef-container div.bd div > p')->each(function ($pchild) {
                                    return $pchild->text();
                                });

                                $servicedatas = json_encode($servicedata);
                                $servicedatasarr = json_decode($servicedatas);
                                // print_r($d);
                                $type_of_exams = [];
                                for ($i=0; $i < count($servicedatasarr); $i++) { 
                                    $dd = explode(":", $servicedatasarr[$i]);
                                    if(isset($this->scrapFields['item_description']) && $dd[0] == $this->scrapFields['item_description']) {
                                        $serviceid = $this->getserviceId($dd[1]);
                                        $type_of_exams[] = $serviceid;
                                    }
                                    
                                }

                                $ScrappedDataArray['type_of_exam'] = $type_of_exams;

                                $DocList = $crawler->filter('tbody > tr')->each(function ($node_child) {
                                    // print_r($node_child->text());
                                    $pdf_array = [$node_child->children()->filter('a')->text(),$node_child->children()->filter('a')->attr('href')];
                                    // $pdf_array[$node_child->children()->filter('a')->text()] = $node_child->children()->filter('a')->attr('href');
                                    return $pdf_array;
                                });

                                $jsondata = json_encode($DocList);
                                $pdfdata = json_decode($jsondata);

                                $ScrappedDataArray['documents'] = $pdfdata;
                                $save_array1 = [];
                                foreach ($ScrappedDataArray as $listkey => $listdata) {
                            
                                    foreach ($this->scrapFields as $key => $scrapfield) {
                                       
                                        if ($scrapfield == $listkey) {
                                            $save_array1[$key] = $listdata;
                                        }

                                        if (isset($this->scrapFields['location']) && $listkey == $this->scrapFields['location']) {

                                            $location_split_data = explode(",",$ScrappedDataArray['Location']);
                                            // print_r($location_split_data);
                                            $location_length = count($location_split_data);
                                            $state_array = $location_length > 0 ? explode(" " ,trim($location_split_data[$location_length-1])) : [];
                                            $save_array1['cityname'] = $location_length > 0 && isset($location_split_data[$location_length-2]) ? trim($location_split_data[$location_length-2]) : "";
                                            $save_array1['address'] = $location_length > 0 && isset($location_split_data[$location_length-3]) ? trim($location_split_data[$location_length-3]) : "";
                                            $save_array1['statename'] = count($state_array) > 0 && isset($state_array[0]) ? $state_array[0] : "";
                                            $save_array1['zipcode'] = count($state_array) > 0 && isset($state_array[1]) ? $state_array[1] : "";
                                            
                                        }
                                    }

                                }

                                
                                //save pateint , provider ,appointment and documents data
                                if (isset($save_array1['patient_name']) && isset($save_array1['appt_date']) && isset($save_array1['appt_time']) && isset($save_array1['provider_name']) && isset($save_array1['statename']) && $save_array1['statename'] != '') {
                                    
                                    \Log::info('checkArray-'.json_encode($save_array1));

                                    //
                                    $resdata = $this->scrapmodel->select_query('states',['code'=>$save_array1['statename']]);
                                    $save_array1['state_id'] = count($resdata) > 0 ? $resdata[0]->id : "";
                                    $save_array1['city_id'] = $this->checkCityByName($save_array1['cityname'],$save_array1['state_id']);
                                    $save_array1['location_id'] = $this->checkLocationByName($save_array1['address'],$save_array1['state_id'],$save_array1['city_id'],$save_array1['zipcode'],$servicedatasarr);

                                    \Log::info('success to find all the keys that are required for save');

                                    $dob = isset($save_array1['patient_dob']) ? date("Y-m-d",strtotime($save_array1['patient_dob'])) : "";

                                    \Log::info('save Patient-'.json_encode($save_array1));

                                    $pateint_id = $this->getpatientId(['patient_name'=>$save_array1['patient_name'],'patient_dob'=>$dob]);
                                    $provider_id = $this->getproviderId(['provider_name'=>$save_array1['provider_name']]);
                                    $special_intruction = isset($save_array1['special_intruction']) ? $save_array1['special_intruction'] : "";
                                    // echo "dsf"; 
                                    $appoint_id = $this->saveAppointmentData(['appt_date' => $save_array1['appt_date'],'appt_time' => $save_array1['appt_time'],'pateint_id' => $pateint_id,'provider_id' => $provider_id,'location_id' => $save_array1['location_id'],'special_intruction'=>$special_intruction,'request_status'=>$ScrappedDataArray['request_status']]);

                                    \Log::info('appointment_id-'.$appoint_id);
                                    if ($appoint_id > 0) {
                                        
                                        foreach ($ScrappedDataArray['documents'] as $outerkey => $doclist) {

                                            /*
                                            always every index has two index, first index is documents name and second one is request url. 
                                            */
                                            $fileCount = $outerkey+1; 
                                            $url_ = "https://secure.ssa.gov".$doclist[1];
                                            $filename = public_path().'/documents/'.str_replace(" ","-",str_replace(",","",$ScrappedDataArray['patient_name'])."-".$doclist[0]."_".$pateint_id."-".$fileCount."-".$appoint_id)."-details.pdf";
                                            $Savefilename = str_replace(" ","-",str_replace(",","",$ScrappedDataArray['patient_name'])."-".$doclist[0]."_".$pateint_id."-".$fileCount."-".$appoint_id)."-details.pdf";
                                            $urlpath = $this->DownloadFileFromEREPortal($url_,$Savefilename);
                                            $this->saveDocumentsPath($appoint_id,$doclist[0],$urlpath);

                                        }

                                        //create inovoice and cepacket.
                                        $this->createInvoiceAndcepacket($StatusIndexArray['state_id'],$appoint_id);

                                        //save mutliple item descripton that's found in ERE portal
                                        foreach ($ScrappedDataArray['type_of_exam'] as $key => $typeofexam) {

                                            $this->scrapmodel->insert_query('appointment_services',['appointment_id'=>$appoint_id,'service_id'=>$typeofexam,'created_at'=>date("Y-m-d H:i:s")]);
                                        }
                                    }
                                    else {
                                        
                                        \Log::info('something went wrong to save the appoinment data');

                                        $this->scrapmodel->insert_query('failed_records',['error_status'=>'Other Exception','error_log'=>json_encode($ScrappedDataArray),'error_msg'=>'something went wrong to save appointment data','start_time'=>$CronStartTime,'end_time'=>date("Y-m-d H:i:s"),'state_id'=>$StatusIndexArray['state_id'],'location_id'=> $save_array1['location_id'],'patient_id'=>$pateint_id]);
                                    }

                                   
                                   $scrappedRecord++;

                        
                                }
                                else {

                                    if (!isset($save_array1['statename']) || $save_array1['statename'] == '') {

                                        $this->scrapmodel->insert_query('failed_records',['error_status'=>'State Not Found','error_log'=>json_encode($ScrappedDataArray),'error_msg'=>'soemthing went wrong to find state Name','start_time'=>$CronStartTime,'end_time'=>date("Y-m-d H:i:s"),'state_id'=>$StatusIndexArray['state_id']]);

                                    } else if (!isset($save_array1['patient_name'])) {

                                        $this->scrapmodel->insert_query('failed_records',['error_status'=>'Patient Not Found','error_log'=>json_encode($ScrappedDataArray),'error_msg'=>'soemthing went wrong to find Pateint Name','start_time'=>$CronStartTime,'end_time'=>date("Y-m-d H:i:s"),'state_id'=>$StatusIndexArray['state_id']]);

                                    } else if (!isset($save_array1['provider_name'])) {

                                        $this->scrapmodel->insert_query('failed_records',['error_status'=>'Provider Not Found','error_log'=>json_encode($ScrappedDataArray),'error_msg'=>'something went wrong to find Provider Name','start_time'=>$CronStartTime,'end_time'=>date("Y-m-d H:i:s"),'state_id'=>$StatusIndexArray['state_id']]);
                                    }
                                    else {

                                        $this->scrapmodel->insert_query('failed_records',['error_status'=>'Appointment Not Found','error_log'=>json_encode($ScrappedDataArray),'error_msg'=>'something went wrong to find appoinment date or time.','start_time'=>$CronStartTime,'end_time'=>date("Y-m-d H:i:s"),'state_id'=>$StatusIndexArray['state_id']]);
                                    }

                                    \Log::info('something went wrong to find fields');
                                    \Log::debug(json_encode($ScrappedDataArray));
                                }
                                
                                \Log::info(json_encode($ScrappedDataArray));

                                $totalRecord++;
                            } 

                        } catch (\Exception $e) {
                            
                            $this->scrapmodel->insert_query('failed_records',['error_status'=>'Other Exception','error_log'=>json_encode($ScrappedDataArray),'error_msg'=>'something went wrong , in exception case','start_time'=>$CronStartTime,'end_time'=>date("Y-m-d H:i:s"),'state_id'=>$StatusIndexArray['state_id']]);

                            \Log::error(json_encode($ScrappedDataArray));

                        } catch (\InvalidArgumentException $e) {

                            $this->scrapmodel->insert_query('failed_records',['error_status'=>'Appointment Not Found','error_log'=>json_encode($ScrappedDataArray),'error_msg'=>'something went wrong , in InvalidArgumentException case','start_time'=>$CronStartTime,'end_time'=>date("Y-m-d H:i:s"),'state_id'=>$StatusIndexArray['state_id']]);

                            \Log::error(json_encode($ScrappedDataArray));

                        } catch (\Error $e) {
                            // Handle error
                            
                            $this->scrapmodel->insert_query('failed_records',['error_status'=>'Other Exception','error_log'=>json_encode($ScrappedDataArray),'error_msg'=>'something went wrong due error has occured','start_time'=>$CronStartTime,'end_time'=>date("Y-m-d H:i:s"),'state_id'=>$StatusIndexArray['state_id']]);

                            \Log::error(json_encode($ScrappedDataArray));
                        }

                    });

                    if ($scrappedRecord > 0) {
                        \Log::debug('CRON has success to scrapped the records');
                        $this->scrapmodel->insert_query('cron_activities',['start_time' =>$CronStartTime,'total_records'=>$totalRecord,'status'=>1,'total_scrapped'=>$scrappedRecord,'state_id'=>$stateval->id,'end_time'=>date("Y-m-d H:i:s")]);
                        $response['status'] = '1';
                        $response['message'] = 'Record has successfully saved to DB';
                    } else {
                        \Log::debug('CRON has failed to scrapped the record');
                        $this->scrapmodel->insert_query('cron_activities',['start_time' =>$CronStartTime,'total_records'=>$totalRecord,'status'=>0,'total_scrapped'=>$scrappedRecord,'state_id'=>$stateval->id,'end_time'=>date("Y-m-d H:i:s")]);
                        $response['status'] = '0';
                        $response['message'] = 'NO Record Found to scrap';
                    } 
                    echo json_encode($response);
                  
                } catch (\Exception $e) { 
                   
                    $err = $e->getMessage()." -lineNo ".$e->getLine();
                    \Log::error($err);

                    $this->scrapmodel->insert_query('cron_activities',['start_time' =>$CronStartTime,'total_records'=>$totalRecord,'status'=>0,'total_scrapped'=>$scrappedRecord,'error_msg'=>$err,'state_id'=>$stateval->id,'end_time'=>date("Y-m-d H:i:s")]);

                    echo $err;

                } catch (\InvalidArgumentException $e) {

                    $err = $e->getMessage()." -lineNo ".$e->getLine();
                    \Log::error($err);

                    $this->scrapmodel->insert_query('cron_activities',['start_time' =>$CronStartTime,'total_records'=>$totalRecord,'status'=>0,'total_scrapped'=>$scrappedRecord,'error_msg'=>$err,'state_id'=>$stateval->id,'end_time'=>date("Y-m-d H:i:s")]);

                    echo $err;
                    
                } catch (\Error $e) {
                    // Handle error
                    $err = $e->getMessage()." -lineNo ".$e->getLine();
                    \Log::error($err);

                    $this->scrapmodel->insert_query('cron_activities',['start_time' =>$CronStartTime,'total_records'=>$totalRecord,'status'=>0,'total_scrapped'=>$scrappedRecord,'error_msg'=>$err,'state_id'=>$stateval->id,'end_time'=>date("Y-m-d H:i:s")]);

                    echo $err;
                }

            }
        }

    }

    /**
    * This function is used to fetch id and insert type of exam.
    *
    * @param  string $name  Type of exam name 
    * @return int           return service id
    * @throws Exception     Any issues encountered
    */
    public function getserviceId($name) {

        $resdata = $this->scrapmodel->select_query('services',['name' => $name]);

        if(count($resdata) > 0) {
            \Log::debug('retrieve service id at service function');
            return $resdata[0]->id;
        }
        \Log::debug('insert service data retrieve id at service function');
        return $this->scrapmodel->insert_query('services',['name' => $name,'created_at'=>date("Y-m-d H:i:s")]);   
    }

    /**
    * This function is used to fetch the city id from the city table.
    *
    * @param  string $name      city name 
    * @param  string $state_id  state id
    * @return int               return city id
    * @throws Exception         Any issues encountered
    */
    public function checkCityByName($name,$state_id) {

        $resdata = $this->scrapmodel->select_query('cities',['name' => $name]);

        if(count($resdata) > 0) {
            \Log::debug('retrieve city_id at checkCityByName function');
            return $resdata[0]->id;
        }
        \Log::debug('insert city name and retrieve its id at checkCityByName function');
        return $this->scrapmodel->insert_query('cities'
            ,['name' => $name, 'state_id' => $state_id]
        );   
    }

    /**
    * This function is used to fetch the address from the location table.
    *
    * @param  string $address   address of location 
    * @param  string $state_id  state id of location
    * @return int               return location id.
    * @throws Exception         Any issues encountered
    */
    public function checkLocationByName($address,$state_id,$city_id,$zipcode,$serviceDatas) {


        //program for the categorized the clinic type.
        $keyWordsArray = config('constants.keyWords');

        //Assign the default clinic type id that are saved same as clini_type table in our datatase.
        $clinicTypeId = '2';

        if (is_array($serviceDatas) && count($serviceDatas) > 0) {

            for ($i=0; $i < count($serviceDatas); $i++) { 
     
                $serviceDataArray = explode(":", $serviceDatas[$i]);
                
                foreach ($keyWordsArray as $key => $list) {
                    
                    for ($j=0; $j < count($list); $j++) { 

                        if (count($serviceDataArray) > 1 && str_contains(trim($serviceDataArray[1]), $list[$j])) {

                            $clinicTypeId = $key;
                            break;
                        }
                    }
                }
                
            }
        }

        // $resdata = $this->scrapmodel->select_query('locations',['address' => $address,'zip_code'=>$zipcode]);
        $resdata = $this->scrapmodel->select_query('locations',['address' => $address,'clinic_type_id'=>$clinicTypeId]);
        \Log::debug(json_encode($serviceDatas).'serviceData');
        if(count($resdata) > 0) {
            \Log::debug('retrieve location id at checkLocationByName function');
            return $resdata[0]->id;
          
        }
        \Log::debug('insert location data and retrieve its id at checkLocationByName function');

        return $this->scrapmodel->insert_query('locations'
            ,['name' => $address, 'address' => $address,'state_id' => $state_id,'city_id'=>$city_id,'zip_code'=>$zipcode,'clinic_type_id' => $clinicTypeId]
        );   
    }

    /**
    * This function is used to fetch the address from the location table.
    *
    * @param  array $data       patient information (name,dob) 
    * @return int               return patient id.
    * @throws Exception         Any issues encountered
    */
    public function getpatientId($data=array()) {

        $resdata = $this->scrapmodel->select_query('patients',['first_name' => $data['patient_name'], 'dob' => $data['patient_dob']]);

        if(count($resdata) > 0) {
            \Log::debug('retrieve patient id at getpatientId function');
            $this->scrapmodel->update_query('patients',['first_name' => $data['patient_name'], 'last_name' => $data['patient_name'], 'dob' => $data['patient_dob']],['id'=>$resdata[0]->id]);
            return $resdata[0]->id;
        }
        \Log::debug('insert patient data and retrieve patient id at getpatientId function');
        return $this->scrapmodel->insert_query('patients'
            ,['first_name' => $data['patient_name'], 'last_name' => $data['patient_name'], 'dob' => $data['patient_dob'],'created_at' =>date("Y-m-d H:i:s")]
        );   
    }

    /**
    * This function is used to fetch the address from the location table.
    *
    * @param  array $data       provider information (name) 
    * @return int               return provider id.
    * @throws Exception         Any issues encountered
    */
    public function getproviderId($data=array()) {

        $resdata = $this->scrapmodel->select_query('users',['name'=>$data['provider_name'],'role_id'=>'3']);

        if(count($resdata) > 0) {
            return $resdata[0]->id;
        }
        return $this->scrapmodel->insert_query('users'
            ,['name' => $data['provider_name'],'role_id'=>'3','created_at' =>date("Y-m-d H:i:s")]
        );   
    }


    /**
    * This function is used to fetch the address from the location table.
    *
    * @param  array $data       appointment information (appointment date,appointment time,patient_id) 
    * @return int               return appointment id.
    * @throws Exception         Any issues encountered
    */
    public function saveAppointmentData($data=array()) {

        $date = date("Y-m-d",strtotime($data['appt_date']));

        $resdata = $this->scrapmodel->select_query('appointments',['patient_id' => $data['pateint_id'],'service_date' => $date,'service_time' => $data['appt_time']]);

        if(count($resdata) > 0) {
            \Log::debug('retrieve appoinment id at saveAppointmentData function');
            return $resdata[0]->id;
        }
        \Log::debug('insert appoinment data and retrieve appoinment id at saveAppointmentData function');
        // echo "else";
        
        $saveRes = $this->scrapmodel->insert_query('appointments',['service_date' => $date,'service_time' => $data['appt_time'],'patient_id' => $data['pateint_id'],'user_id' => $data['provider_id'],'location_id' => $data['location_id'],'special_instruction'=>$data['special_intruction'],'request_status'=> $data['request_status'],'created_at' =>date("Y-m-d H:i:s")]);
        return $saveRes;
    }


    /**
    * This function is used to insert or update documents path to attchements table.
    *
    * @param  int $appointment_id   appointment id.
    * @param  string $filename      save filename.
    * @param  int $url              aws bucket path. 
    * @return int                   return documents id.
    * @throws Exception             Any issues encountered
    */
    public function saveDocumentsPath($appointment_id,$filename,$url) {

        $resdata = $this->scrapmodel->select_query('attachments',['appointment_id' => $appointment_id,'url'=>$url]);

        if(count($resdata) > 0) {
            \Log::debug('retrieve and update docoument id at saveDocumentsPath function');
            $this->scrapmodel->update_query('attachments',['appointment_id' => $appointment_id,'original_name'=>$filename,'url'=>$url],['id'=>$resdata[0]->id]);

            return $resdata[0]->id;
        }
        \Log::debug('insert documents file and retrieve documents id at saveDocumentsPath function');
        return $this->scrapmodel->insert_query('attachments',['appointment_id' => $appointment_id,'original_name'=>$filename,'url'=>$url,'created_at' =>date("Y-m-d H:i:s")]);
    }

    /**
    * This function is used to download the pdf documents from the ERE patient details page.
    *
    * @param  string $url           url of request where find the pdf document.
    * @param  string $filename      download filename. 
    * @return object                return json response.
    * @throws Exception             Any issues encountered
    */
    public function DownloadFileFromEREPortal($url,$filename) {

        \Log::debug('initiate download the docoument at DownloadFileFromEREPortal function');
        $crawler = $this->client->request('GET', $url, [], [],[
            'HTTP_CONTENT_TYPE' => 'application/x-www-form-urlencoded',
            'Origin'=>'https://secure.ssa.gov',
            'Referer'=>'https://secure.ssa.gov/acu/iresear/login?URL=%2Fapps9%2FEREHome%2FErhm01View'
        ]);/*  */

        $StatusCode = $this->client->getResponse()->getStatusCode();
        if($StatusCode == 200) {
            \Log::debug('request has success with status code '.$StatusCode.' at DownloadFileFromEREPortal function');
            $response = $this->client->getResponse()->getContent();
            $path = $this->saveDocumentToS3bucket('document/'.$filename,$response);
            return $path;
        } else {
            \Log::debug('request has success failed with status code '.$StatusCode.'DownloadFileFromEREPortal function');
            return "";
        }  
    }

    /**
    * This function is used for save the document file to S3 bucket.
    *
    * @param  string $filename      filename for save to aws bucket.
    * @param  object $file          file data as raw content. 
    * @return string                return path url
    * @throws Exception             Any issues encountered
    */
    public function saveDocumentToS3bucket($filename,$file) {
        
        \Log::debug('initiate to save documents into the s3 bucket');
        $path = Storage::disk('s3')->put($filename, $file,'private');
        return Storage::disk('s3')->url($filename);
    }

    /**
    * This function is used to create invoice pdf.
    *
    * @param  int $stateId          state id of location.
    * @param  int $appointment_id   appointment id. 
    * @throws Exception             Any issues encountered
    */ 
    public function createInvoiceAndcepacket($stateId,$appointment_id) {
        
        try {
        	
            \Log::debug('initiate createInvoice function');

            $stateList = $this->scrapmodel->select_query('states',['id'=>$stateId]);

            if(count($stateList) > 0 && $stateList[0]->invoice_extraction != '') {

                \Log::debug('successful find state id at createInvoice function');

                $documentsList = $this->scrapmodel->select_query('attachments',['appointment_id' => $appointment_id,'original_name'=>'Request Letter']);

                if(count($documentsList) > 0) {

                    \Log::debug('successful find documentsList at createInvoice function');
                    $combined_url = $documentsList[0]->url;
                    $splitPagedata = $stateList[0]->invoice_extraction;
                    $splitPage  = explode(",",$splitPagedata);

                    $urlfilename = basename($combined_url);
                    
                    // access private s3 URL
                    $signatureURL = signatureURL($combined_url);

                    file_put_contents(public_path()."/".$urlfilename,file_get_contents($signatureURL));

                    $filename = public_path()."/".$urlfilename;

                    $pdfPageCount = $this->countPages($filename);

                    if (file_exists($filename) && $pdfPageCount > 0 ) {

                        $oMerger = PDFMerger::init();
                        //Pass the page numbers as an array. Here 2 and 4 are passed.
                        // $oMerger->addPDF($filename,$splitPage);
                        $oMerger->addPDF($filename,$splitPagedata,'P');
                        //To merge the pages having the page numbers passed in the array.
                        $oMerger->merge();
                        //To save the pdf. 
                        /***** This pdf will be created in the same directory where the orignal PDF is there*****/
                        $saveFile = public_path()."/invoice-file-".$appointment_id.".pdf";
                        $oMerger->save($saveFile);
                        $s3filename = "invoice/invoice-file-".md5($appointment_id).".pdf";
                        $invoive_url = $this->saveDocumentToS3bucket($s3filename,file_get_contents($saveFile));
                        if(file_exists($saveFile)) {
                            unlink($saveFile);
                        }
                        $this->scrapmodel->update_query('appointments',['invoice_url' => $invoive_url,'combined_url'=>$combined_url],['id'=>$appointment_id]);
                    }

                    if(file_exists($filename)) {
                        unlink($filename);
                    }
                }
                else {
                    \Log::debug('failed to find documentsList at createInvoice function');
                }

                $attachementList = $this->scrapmodel->select_query('attachments',['appointment_id' => $appointment_id]);
                
                if(count($attachementList) > 0) {

                    \Log::debug('successful find documentsList for CE packet');
                    $CepacketPages = [];
                    $invoive_url = '';
                    $combined_url = '';
                    $CEpacketMerger = PDFMerger::init();
                    $FileRemoveArray = [];
                    $fileCheck = false;
                    $mergeFileNameArray = [];
                    // $ces3pathurl = '';
                    foreach ($attachementList as $key => $attachement) {

                        if($attachement->original_name == 'Request Letter') {

                            $combined_url = $attachement->url;
                            $splitPagedata = $stateList[0]->invoice_extraction;
                            $splitPage  = explode(",",$splitPagedata);

                            //get the file Name
                            $urlfilename = basename($combined_url);

                            // access private s3 URL
                            $signatureURL = signatureURL($combined_url);

                            file_put_contents(public_path()."/".$urlfilename,file_get_contents($signatureURL));

                            $filename = public_path()."/".$urlfilename;

                            $pdfPageCount = $this->countPages($filename);

                            if (file_exists($filename) && $pdfPageCount > 0 ) {

                                //$FileRemoveArray array for unlink/delete the files. 
                                $FileRemoveArray[] = $filename;
                                $pdfCount = $pdfPageCount;
                                $CEPacket = range(1,$pdfCount);
                                \Log::debug('pagesArrayJson-'.json_encode(['cepacket'=>$CEPacket,'pdfcount'=>$pdfCount]));
                                $CepacketPages =  array_diff($CEPacket,$splitPage);
                                \Log::debug('pagesArray-'.implode(",", $CepacketPages));
                                $pageList = implode(",", $CepacketPages);
                                $outputFileName = public_path()."/".'createcepacketfrominvoice.pdf';
                                $FileRemoveArray[] = $outputFileName;
                                $extractRes = $this->extractPagesFromPdf($filename,$pageList,$outputFileName);

                                if($extractRes != false) {
                                    \Log::debug('under the extractRes');
                                    $mergeFileNameArray[] = $outputFileName;
                                }

                            }
                        }

                        if($attachement->original_name != 'Request Letter') {

                            $urlfilename = basename($attachement->url);

                            // access private s3 URL
                            $signatureURL = signatureURL($attachement->url);

                            file_put_contents(public_path()."/".$urlfilename,file_get_contents($signatureURL));

                            $cefilename = public_path()."/".$urlfilename;

                            if (file_exists($cefilename) && $this->countPages($cefilename) > 0 ) {
                                $fileCheck = true;
                                $FileRemoveArray[] = $cefilename; 
                                $mergeFileNameArray[] = $cefilename;
                            }
                        }

                    }

                    \Log::debug('mergeFileNameArray-'.json_encode($mergeFileNameArray));

                    if (count($mergeFileNameArray) > 0) {

                        if (count($mergeFileNameArray) == 1) {

                            $saveFile = $mergeFileNameArray[0];

                            if(file_exists($saveFile)) {

                                $s3filename = 'CEpacket/'."cepacket_".md5($appointment_id).".pdf";
                                $ces3pathurl = $this->saveDocumentToS3bucket($s3filename,file_get_contents($saveFile));
                    
                            }

                        } else {

                            \Log::debug('under the mergeFileNameArray condition');
                            $fileNames = implode(" ", $mergeFileNameArray);
                            $saveFile = public_path()."/cepacket_".$appointment_id.".pdf";
                            $FileRemoveArray[] = $saveFile;
                            $mergerFileRes = $this->mergerPdfFile($fileNames,$saveFile);

                            \Log::info('Merge File Response-'.$mergerFileRes);
                            \Log::info('check File under the merfeFileNameArray-'.file_exists($saveFile));
                            if($mergerFileRes != false && file_exists($saveFile)) {

                                \Log::debug('under the merge file response');

                                $s3filename = 'CEpacket/'."cepacket-".md5($appointment_id).".pdf";
                                $ces3pathurl = $this->saveDocumentToS3bucket($s3filename,file_get_contents($saveFile));
                            }
                        }

                        $this->scrapmodel->update_query('appointments',['cepacket_url'=>$ces3pathurl,'combined_url'=>$combined_url],['id'=>$appointment_id]);

                        
                    }

                    \Log::debug('file remove array-'.json_encode($FileRemoveArray));

                    for ($i=0; $i < count($FileRemoveArray); $i++) {
                       if(file_exists($FileRemoveArray[$i])) {
                            \Log::debug('file has deleted successfully');
                            unlink($FileRemoveArray[$i]);
                        } 
                    }

                }
                else {
                    \Log::debug('failed to find documentsList at createCEpacket function');
                }

                //unset the variable 
                if (isset($oMerger)) {
                	unset($oMerger);
                }
                if (isset($CEpacketMerger)) {
                	unset($CEpacketMerger);
                }
                if (isset($filename)) {
                	unset($filename);
                }
                if (isset($FileRemoveArray)) {
                	unset($FileRemoveArray);
                }
                if (isset($attachementList)) {
                	unset($attachementList);
                }
                if (isset($stateList)) {
                	unset($stateList);
                }
                if (isset($pdfPageCount)) {
                	unset($pdfPageCount);
                }	
                                
            }
            else {
                \Log::debug('failed to find state id at createInvoice function');
            }
        } catch (\Exception $e) {
            echo $e->getMessage()."under the invoice";
            // throw new \Exception('unable to create invoice and cepacket');
        }
        catch (\Error $e) {
            echo $e->getMessage()."under the invoice";
            // throw new \Exception('unable to create invoice and cepacket');
        }   
     
    }


    public function extractPagesFromPdf($filePath,$pageList,$outputFileName) {

        try {
            
            //Create the GhostScript command for extract the particular pages from pdf
            $gsCmd = 'gs -sDEVICE=pdfwrite -dNOPAUSE -dBATCH -dSAFER -sPageList='.$pageList.' -sOutputFile='.$outputFileName.' '.$filePath.'';

            \Log::debug('ghostscript command-'.$gsCmd);

            // return $gsCmd;
            //Run it using PHP's exec function.
            $output = array();
            $return = null;
            $cmd = exec($gsCmd,$output,$return);

            if ($return != 0) {
                \Log::debug('ghostscript command response-'.$return);
                return false;
            } else {
                return $cmd;
            }

        } catch (\Exception $e) {
            echo "while extract pages".$e->getMessage();
            return false;
        }
    }

    public function mergerPdfFile($fileArray,$outputFileName) {

        try {
            
            //Create the GhostScript command for extract the particular pages from pdf
            $gsCmd = 'gs -dBATCH -dNOPAUSE -q -sDEVICE=pdfwrite -sOutputFile='.$outputFileName.' '.$fileArray.'';

            \Log::debug('ghostscript merger command'.$gsCmd);

            // return $gsCmd;
            //Run it using PHP's exec function.
            $output = array();
            $return = null;
            $cmd = exec($gsCmd,$output,$return);

            if ($return != 0) {
                \Log::debug('under the failed file merge response');
                return false;
            } else {
                \Log::debug('under the success file merge response');
                return $cmd;
            }

        } catch (\Exception $e) {
            echo "under the merge pdf function-".$e->getMessage();
            return false;
        }
    }

    /**
    * This function is used to get the Pdf pages Count.
    *
    * @param  string $path      path of file. 
    * @throws Exception         Any issues encountered
    */  
    public function countPagesBackup($path) {
        
        $pdftext = file_get_contents($path);
        $num = preg_match_all("/\/Page\W/", $pdftext,$matches);
        # $num = preg_match_all("/\/Count\s+(\d+)/", $pdftext,$matches);
        return $num;   
    }


    /**
    * This function is used to get the Pdf pages Count.
    *
    * @param  string $path      path of file. 
    * @throws Exception         Any issues encountered
    */  
    public function countPages($path) {
        
    	try {
    		
    		//Create the GhostScript command for get pdf page count
	        $gsCmd = 'gs -q -dNODISPLAY -c "('.$path.') (r) file runpdfbegin pdfpagecount = quit";';
	        // return $gsCmd;
	        //Run it using PHP's exec function.
	        $output = array();
	        $return = null;
	        $cmd = exec($gsCmd,$output,$return);

            if ($return != 0) {
                \Log::debug('PageCountCommand-'.$gsCmd);
                return 0;
            } else {
                return $cmd;
            }
			// return $return != 0 ? 0 : $cmd;

    	} catch (\Exception $e) {
			
			return 0;    		
    	}

       
        
    }
    
    public function buildInvoice() {

        $filename1 = public_path()."/Covey-Elisha-Request-Letter_230-0-details.pdf";
        $filename2 = public_path()."/Covey-Elisha-Request-Letter_29-0-details.pdf";

        $pdfMarger = PDFMerger::init();
        
        $pdfMarger->addPDF($filename1,'all','P');
        $pdfMarger->addPDF($filename2,'all','P');
        $pdfMarger->merge();
        $saveFile = public_path()."/invoice-file-xyz.pdf";
        return $pdfMarger->save($saveFile,'download');

    }

}
