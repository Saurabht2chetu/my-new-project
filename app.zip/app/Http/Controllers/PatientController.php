<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\ClinicController;
use App\Models\Roles;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use DataTables;
use App\Models\Appointment;
use App\Models\Assistant;
use App\Models\Patient;
use App\Models\States;
use App\Models\Note;
use App\Models\Location;
use App\Models\StickyNote;
use App\Models\ClinicData;
use App\Models\ClinicDataHistory;
use App\Models\ClinicHistory;
use App\Models\PatientHistory;
use App\Models\ScrapModel;
use Illuminate\Contracts\Filesystem\Filesystem;
use League\Flysystem\AwsS3v3\AwsS3Adapter;
use Storage;
use Config;
use Validator;
use DB;


/**
* This class is used to interact with the Examinee List Module
*
* PHP version 8.0.8
*
* @category  Supporting_Script
* @package   ExamineeList_Module
* @author    Chetu
* @copyright 2022 Chetu
*/
class PatientController extends ClinicController {
    
    /**
    * This function will be used to render the Examinee Page.
    *
    * @param  string $date  service date of appointment 
    * @param  string $location_id  location id of appointment
    * @return object         html page 
    * @throws Exception      Any issues encountered
    */
    public function PatientList($date,$location_id) {

        $locationData = Location::where('id',$location_id)->first();
        $examinerList = '';

        $examinerList = $this->getExaminersByDateAndLocation($date,$location_id); 
        $assistnlist = $this->getAssistantsByDateAndLocation($date,$location_id); 

        $assitants = count($assistnlist) > 0 ? $assistnlist['assistant_list']['user_name'] : "";
        $examiners = count($examinerList) > 0 ? $examinerList['examiner_list']['user_name'] : $this->getAllexaminer($date,$location_id)['user_name'];
        
        $clinicDataList = ClinicData::where(['service_date'=> $date,'location_id'=> $location_id])->first();

        $seviceList = DB::table('services')->get();

        //fetch clinic documents based on service-date and location
        $Scrapmodel = new ScrapModel();
        $clinicDocuments = $Scrapmodel->select_query('clinic_documents',['service_date'=>$date,'location_id'=>$location_id]);

        $locationList = Location::where('deleted','0')->orderBy('name','ASC')->get();

        //get clinic calculation data
        $checkCalculationList = $Scrapmodel->select_query('clinic_calculations',['service_date'=>$date,'location_id'=>$location_id]);
        
        //
        $onCallStatement = $this->getOnCallStatement();

        return view('clinic.patientlist',['date'=>$date,'location_id'=>$location_id,'locationData'=>$locationData,'examiner_list'=>$examiners,'assistant_list'=>$assitants,'clinicDataList'=>$clinicDataList,'seviceList'=>$seviceList,'clinicDocuments' => $clinicDocuments,'locationList' =>$locationList,'checkCalculationList'=>$checkCalculationList,'onCallStatement' => $onCallStatement]);
        
    }

    /**
    * This function will be used to get examinee list.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function getPatientList(Request $request) {

        
        if ($request->ajax()) {

            $patientData = Appointment::leftjoin('users','users.id','=','appointments.user_id')
                            ->join('patients','patients.id','=','appointments.patient_id')
                            ->join('locations','locations.id','=','appointments.location_id')
                            ->join('states','states.id','=','locations.state_id')
                            ->orderBy(DB::raw('CAST(appointments.service_time AS time)'),'ASC')
                            // ->groupBy('patient_id')
                            ->where('appointments.service_date',$request->date)
                            ->where('appointments.location_id',$request->location_id)
                            ->where('appointments.deleted',0)
                            ->select('appointments.*','users.name as user_name','states.name as location_name','patients.first_name as patient_name','patients.phone as patient_phone','patients.dob')
                            ->get();          
          
            return  Datatables::of($patientData)
                        ->addIndexColumn()
                        ->addColumn('action', function($row) {
                            
                            if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID']) {

                                $btn = '<div class="db-action-box"><div class="db-action-box edit-icon"><p class="editbtn" data-toggle="tooltip" data-placement="top" title="Edit" data-id="'.$row->id.'"><i class="far fa-edit"></i></p>';

                                if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID']) {

                                    $btn.= '<p class="delete-appointment" title="Delete" data-id="'.$row->id.'"><i class="fas fa-times"></i></p><p><a target="_blank" title="View History" href="'.url('appointment-history').'/'.$row->id.'"><i class="fa fa-eye" aria-hidden="true"></i></a></p></div></div>';
                                }
                                
                            } else {

                                $btn = '<div class="db-action-box"><div class="edit-icon"><p class="access_denied" data-toggle="tooltip" data-placement="top" title="Edit"><i class="far fa-edit"></i></p></div></div>';
                            }

                            return $btn;

                        })->addColumn('status', function($row) {

                            if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID']) {

                                if($row->status == $_ENV['APPT_STATUS_BROKEN']) {
                                    $btn = '<div class="db-action-box"><div><p class="unbroken" data-toggle="tooltip" data-placement="left" data-id="'.$row->id.'" data-status="0" title="Unbreak" data-original-title="Broken"><i class="fas fa-ban text-danger"></i><a style="cursor:pointer;" title="'.$row->status_text.'">Broken</a></p></div></div>';
                                } else if ($row->status == $_ENV['APPT_STATUS_CANCEL']) {
                                    $btn = '<div class="db-action-box"><div class="delete-icon"><p class="status_uncancel" data-id="'.$row->id.'" data-status="1" title="Uncancel" ><i class="fas fa-undo"></i><a style="cursor:pointer;" title="'.$row->status_text.'">Cancelled</a></p></div></div>';
                                } else {
                                    $btn = '<div class="db-action-box"><div><p class="no_show" data-toggle="tooltip" data-placement="left" data-id="'.$row->id.'" data-status="1" title="Broken" data-original-title="Broken"><i class="fas fa-ban"></i></p></div><div class="delete-icon"><p class="status_cancel" data-id="'.$row->id.'" data-status="1" title="Cancel" ><i class="fas fa-times"></i></p></div></div>';
                                }

                            } else {

                                if($row->status == $_ENV['APPT_STATUS_BROKEN']) {
                                    $btn = '<div class="db-action-box"><div><p class="unbroken" data-toggle="tooltip" data-placement="left" data-id="'.$row->id.'" data-status="0" title="UnBroken" data-original-title="Broken"><i class="fas fa-ban text-danger"></i><a style="cursor:pointer;" title="'.$row->status_text.'">Broken</a></p></div></div>';
                                } else if ($row->status == $_ENV['APPT_STATUS_CANCEL']) {
                                    $btn = '<a style="cursor:pointer;" title="'.$row->status_text.'">Cancelled</a>';
                                } else {
                                    $btn = '<div class="db-action-box"><div><p class="no_show" data-toggle="tooltip" data-placement="left" data-id="'.$row->id.'" data-status="1" title="Broken" data-original-title="Broken"><i class="fas fa-ban"></i></p></div></div>';
                                }
                            }
                        
                            return $btn;
                            
                        })->addColumn('dob', function($row) {

                            $dob = $row->dob != '' ? date("m-d-Y",strtotime($row->dob)) : '';

                            return $dob;

                        })->addColumn('patient_phone', function($row) {

                            $phone = formatPhoneNumber($row->patient_phone);
                            // return $phone;

                            if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID']) {

                                $phoneNumber =  '<span class="p-1">'.$phone.'</span><a class="phonebtn pt-0" data-patient-id="'.$row->patient_id.'" title="Update Phone Number" data-phone_number="'.$phone.'" style="font-size:13px;cursor:pointer;" ><i class="far fa-edit"></i></a>';

                            } else {
                                $phoneNumber = $phone;
                            }
                            return $phoneNumber;

                        })->addColumn('special_request', function($row) {
                            
                            $specialRequest = $row->special_instruction != '' && $row->special_instruction != null ? $row->special_instruction : '';

                            if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID']) {

                                $specialRequestBtn =  '<span class="p-1">'.$specialRequest.'</span><a class="specialrequestbtn pt-0" data-appointment="'.$row->id.'" title="Update Special Request" data-special_request="'.$specialRequest.'" style="font-size:13px;cursor:pointer;" ><i class="far fa-edit"></i></a>';

                            } else {
                                $specialRequestBtn = $specialRequest;
                            }
                            return $specialRequestBtn;

                        })->addColumn('case_id', function($row) {
                            
                            if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID']) { 

                                $btn =  '<span class="p-1">'.$row->case_id.'</span><a class="caseidbtn pt-0" data-appointment="'.$row->id.'" title="Update Case Id" data-case_id="'.$row->case_id.'" style="font-size:13px;cursor:pointer;" ><i class="far fa-edit"></i></a>';

                            } else {
                                $btn = '<span class="p-1">'.$row->case_id.'</span>';
                            }
                            return $btn;

                        })->addColumn('call_note', function($row) {
        
                            if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID']) {
                                $html = '<a href="" class="p-1 addcallnote" data-appointment="'.$row->id.'">add</a><br>';
                            } else {
                                $html = '<a href="" class="m-1 access_denied" data-appointment="'.$row->id.'">add</a><br>';
                            }

                            $checkcallNote = $this->getCallnoteByAppointment($row->id);
                            if (count($checkcallNote) > 0) {
                                $html.='<a  class="viewcallNotebtn text-warning" href="" data-appointment="'.$row->id.'" >view</a>';
                            }

                            return $html;

                        })->addColumn('sticky_note', function($row) {
                            
                            $stickyNotes = $this->getStickynoteByAppointment($row->id);
                            $stickyContent = '';
                            if(count($stickyNotes) > 0) {
                                $stickyContent = $stickyNotes[0]->sticky_note;
                            }

                            if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID']) {
                                $html = '<a href="" class="m-1 addstickynote" data-appointment="'.$row->id.'">add</a><br>';
                            } else {
                                $html = '<a href="" class="m-1 access_denied" data-appointment="'.$row->id.'">add</a><br>';
                            }
                           
                            $checkcallNote = $this->getStickynoteByAppointment($row->id);
                            if (count($checkcallNote) > 0) {
                                $html.='<a href="" class="m-1 viewstickyNotebtn text-warning" data-appointment="'.$row->id.'" title="'.$stickyContent.'" >view</a>';
                            }
                            return $html;

                        })->addColumn('invoice', function($row) {

                            $btn = '<a href="'.route('pdfviewer',['url' => $row->invoice_url]).'" target="_blank">view</a>';

                            return $btn;

                        })->addColumn('cepacket', function($row) {

                            if ($row->cepacket_url == '') {
                                return ' - ';
                            } else {
                                return '<a target="_blank" href="'.signatureURL($row->cepacket_url).'">view</a>';
                            }
                            
                        })->addColumn('service_time', function($row) {
        
                            return $row->service_time != '' ? convertTime($row->service_time) : '';
                            
                        })->rawColumns(['action','invoice','cepacket','examinee','print','case_id','call_note','sticky_note','status','special_request','patient_phone'])->make(true);
                        
        }
    }

    /**
    * This function will be used to update the case-id.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function updateCaseId(Request $request) {
           
        $validator = Validator::make($request->all(), [
            'appointment_id' => 'required',
            'case_id' => 'required'
        ]);

        if($validator->fails()) {

            return response()->json(['status'=>false,'msg' => $validator->errors()->first()]);
        }

        $saveAppointmentHistory = $this->saveAppointmentHistory($request->appointment_id);
    
        if (!$saveAppointmentHistory) {

            return response()->json(['status'=>false,'msg' => 'Something went wrong to save appointment history']);
        }

        $saveRes = Appointment::where('id',$request->appointment_id)->update([
            'case_id'=>$request->case_id,
        ]);

        if($saveRes) {
            return response()->json(['status'=>true,'msg'=>'Case Id has successfully updated']);
        }
        return response()->json(['status'=>false,'msg'=>'something went wrong to update Case Id']);
    }

    /**
    * This function will be used to update the Special Request
    *
    * @param  object $request request data 
    * @return object          Json response from the server containing Tasks
    * @throws Exception       Any issues encountered
    */
    public function updateSpecialRequest(Request $request) {
           
        $validator = Validator::make($request->all(), [
            'special_request_appt_id' => 'required'
        ]);

        if($validator->fails()) {

            return response()->json(['status'=>false, 'msg' => $validator->errors()->first()]);
        }

        $saveAppointmentHistory = $this->saveAppointmentHistory($request->special_request_appt_id);
    
        if (!$saveAppointmentHistory) {

            return response()->json(['status'=>false,'msg' => 'Something went wrong to save appointment history']);
        }

        $saveRes = Appointment::where('id',$request->special_request_appt_id)->update([
            'special_instruction'=>$request->current_special_request,
        ]);

        if($saveRes) {
            return response()->json(['status'=>true, 'msg'=>'Special Request has successfully updated']);
        }
        return response()->json(['status'=>false, 'msg'=>'something went wrong to update Special Request']);
    }


    /**
    * This function will be used to update the Special Request
    *
    * @param  object $request request data 
    * @return object          Json response from the server containing Tasks
    * @throws Exception       Any issues encountered
    */
    public function updatePhoneNumber(Request $request) {
           
        $validator = Validator::make($request->all(), [
            'phone_patient_id' => 'required'
        ]);

        if($validator->fails()) {

            return response()->json(['status'=>false, 'msg' => $validator->errors()->first()]);
        }

        $saveExamineeHistory  = $this->savePatientHistory($request->phone_patient_id);

        if (!$saveExamineeHistory) {
            return response()->json(['status'=>false,'msg' => 'Something went wrong to Examinee history']);
        }

        $currentPhoneNumber = isset($request->current_phone_number) ? str_replace(["|","-","&"],'',$request->current_phone_number) : '';

        $saveRes = Patient::where('id',$request->phone_patient_id)->update([
            'phone'=>$currentPhoneNumber,
        ]);

        if($saveRes) {
            return response()->json(['status'=>true, 'msg'=>'Phone number has successfully updated']);
        }
        return response()->json(['status'=>false, 'msg'=>'something went wrong to update phone number']);
    }

    /**
    * This function will be used to update the appointment status.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function updateAppointmentStatus(Request $request) {
           
        try {
            
            $validator = Validator::make($request->all(), [
                'appointment_id' => 'required',
                'status' => 'required'
            ]);
            
            if($validator->fails()) {
    
                return response()->json(['status'=>false,'msg' => $validator->errors()->first()]);
            }
    
            $saveHistory = $this->saveAppointmentHistory($request->appointment_id);
    
            if (!$saveHistory) {
    
                return response()->json(['status'=>false,'msg' => 'Something went wrong to save history']);
            }
    
            $updateRes = Appointment::where('id',$request->appointment_id)->update([
                'status'=>$request->status,
                'status_text' => $request->broken_comment
            ]);
    
            if($updateRes) {

                return response()->json(['status'=>true,'msg'=>'status has successfully updated']);
            }

            return response()->json(['status'=>false,'msg'=>'something went wrong to update Assistant']);

        } catch (\Throwable $th) {
            //throw $th;
            return response()->json(['status'=>false,'msg'=> $th->getMessage()]);
        }

        
    }

    /**
    * This function will be used to add call note based on each appointment.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function addCallNote(Request $request) {
        
        try {

            $validator = Validator::make($request->all(), [
                'appointment_id' => 'required',
                'call_note' => 'required'
            ]);
    
            if($validator->fails()) {
    
                return response()->json(['status' => false, 'msg' => $validator->errors()->first()]);
            }
    
            $saveRes = Note::create([
                'appointment_id' => $request->appointment_id,
                'call_note' => $request->call_note,
                'created_at' => Carbon::now(),
                'updated_by' => Auth::user()->id
            ]);
    
            if($saveRes) {
                return response()->json(['status'=>true,'msg'=>'Call note has successfully added']);
            }

            return response()->json(['status'=>false,'msg'=> 'something went wrong']);

        } catch (\Throwable $th) {
            //throw $th;
            return response()->json(['status'=>false, 'msg' => $th->getMessage()]);
        }
    }

    /**
    * This function will be used to save clinic data based on location and service date.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function addClinicData(Request $request) {
        
        try {
            
            $validator = Validator::make($request->all(), [
                'service_date' => 'required',
                'location_id' => 'required',
            ]);

            if ($validator->fails()) {

                return redirect()->back()->with('status', $validator->errors()->first());
            }

            $checkClinicData = ClinicData::where(['service_date' => $request->service_date,'location_id' => $request->location_id])->first();

            $adminWriteIn = $request->clinic_admin_write_in;

            $updateArray = [
                'service_date' => $request->service_date,
                'location_id' => $request->location_id,
                'updated_by' => Auth::user()->id
            ];

            $team_member = isset($request->team_member) ? $updateArray['team_member'] = $request->team_member : $updateArray['team_member'] = '';
            $contact_type = isset($request->contact_type) ? $updateArray['contact_type'] = $request->contact_type : '';
            $chart_type = isset($request->chart_type) ? $updateArray['chart_type'] = $request->chart_type : $updateArray['chart_type'] = '';
            $x_ray_vendor = isset($request->x_ray_vendor) ? $updateArray['x_ray_vendor'] = $request->x_ray_vendor : $updateArray['x_ray_vendor'] = '';
            $from_date = isset($request->from_date) ? $updateArray['from_time'] = $request->from_date : $updateArray['from_time'] = '';
            $to_date = isset($request->to_date) ? $updateArray['to_time'] = $request->to_date : $updateArray['to_time'] = '';
            $training = isset($request->training) ? $updateArray['training'] = '1' : $updateArray['training'] = '0';
            $email = isset($request->email) ? $updateArray['email'] = '1' : $updateArray['email'] = '0';
            $invite = isset($request->invite) ? $updateArray['invite'] = '1' : $updateArray['invite'] = '0';
            $xray = isset($request->xray) ? $updateArray['xray'] = '1' : $updateArray['xray'] = '0';

            if (Auth::user()->role_id == $_ENV['ASSISTANT_ROLE_ID'] || Auth::user()->role_id == $_ENV['EXAMINER_ROLE_ID']) {

                $updateArray['assistant_write_in'] = isset($request->clinic_assistant_write_in) ? $request->clinic_assistant_write_in : '';
            }

            if (Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID']) {

                $updateArray['admin_write_in'] = isset($request->clinic_admin_write_in) ? $request->clinic_admin_write_in : '';
                $updateArray['assistant_write_in'] = isset($request->clinic_assistant_write_in) ? $request->clinic_assistant_write_in : '';
            }

            if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID']) {

                $updateArray['assistant_write_in'] = isset($request->clinic_assistant_write_in) ? $request->clinic_assistant_write_in : '';
                $updateArray['admin_write_in'] = isset($request->clinic_admin_write_in) ? $request->clinic_admin_write_in : '';
            }

            if ($checkClinicData) {
                        
                $savehistory = $this->saveClinicDataHistory($checkClinicData->id);

                if (!$savehistory) {
                    return redirect()->back()->with('status', 'Something went wrong to save clinic history');
                }

                $updateArray['updated_at'] = Carbon::now();

                $saveRes = ClinicData::where('id',$checkClinicData->id)->update($updateArray);

                
                if($saveRes) {

                    return redirect()->back()->with('status', 'Clinic details saved successfully');
                }
                return redirect()->back()->with('status', 'Clinic details saved successfully');

            } else {

                $updateArray['created_at'] = Carbon::now();

                $saveRes = ClinicData::create($updateArray);
        
                if($saveRes) {
                    return redirect()->back()->with('status', 'Clinic details saved successfully');
                }
                return redirect()->back()->with('status', 'Clinic details saved successfully');
            }
            
        } catch (\Throwable $th) {
            //throw $th;
            return redirect()->back()->with('status', $th->getMessage());
        }
    }

    /**
    * This function will be used to add sticky note based on appointment.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function addStickyNote(Request $request) {
        
        try {

            $validator = Validator::make($request->all(), [
                'appointment_id' => 'required',
                'sticky_note' => 'required'
            ]);
    
            if($validator->fails()) {
    
                return response()->json(['status'=>false,'msg' => $validator->errors()->first()]);
            }
    
            $saveRes = StickyNote::create([
                'appointment_id'=> $request->appointment_id,
                'sticky_note'=> $request->sticky_note,
                'created_at'=> Carbon::now(),
                'updated_by' => Auth::user()->id
            ]);
    
            if($saveRes) {

                return response()->json(['status'=>true,'msg'=>'Sticky note has successfully added']);
            }
            return response()->json(['status'=>false,'msg'=>'something went wrong to add sticky note']);

        } catch (\Throwable $th) {
            
            return response()->json(['status'=>false,'msg'=> $th->getMessage() ]);
        }
    }

    /**
    * This function will be used to get sticky note list from the 'sticky_notes' table.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function getstickyNote(Request $request) {
           
        $validator = Validator::make($request->all(), [
            'appointment_id' => 'required'
        ]);

        if($validator->fails()) {
            return response()->json(['status'=>false,'msg' => $validator->errors()->first()]);
        }

        $Noteslist = $this->getStickynoteByAppointment($request->appointment_id);

        if(count($Noteslist) > 0) {
            $table = '<div class="table-responsive"><table class="table table-bordered"><thead><tr><th>Note</th><th>Created Date</th><th>Action</th></tr></thead><tbody>';

            foreach ($Noteslist as $list) {
            
                $table .= '<tr><td>'.$list->sticky_note.'</td><td>'.date("m-d-Y",strtotime($list->created_at)).'</td><td><p class="sticky_deletebtn" title="Delete" data-id="'.$list->id.'"><i class="fas fa-times"></i></p></td></tr>';
            }
            $table.='</tbody></table></div>';

            return response()->json(['status'=>true,'data'=>$table,'msg'=>'Call note has successfully added']);
        }
        return response()->json(['status'=>false,'msg'=>'No sticky note Found','data'=>'']);
    }

    /**
    * This function will be used to get call note list from the 'call_notes' table.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function getcallNote(Request $request) {
           
        $validator = Validator::make($request->all(), [
            'appointment_id' => 'required'
        ]);

        if($validator->fails()) {
            
            return response()->json(['status'=>false,'msg' => $validator->errors()->first()]);
        }

        $Noteslist = $this->getCallnoteByAppointment($request->appointment_id);

        if(count($Noteslist) > 0) {

            $table = '<div class="table-responsive"><table class="table table-bordered"><thead><tr><th>Note</th><th>Created Date</th><th>Action</th></tr></thead><tbody>';

            foreach ($Noteslist as $list) {
            
                $table .= '<tr><td>'.$list->call_note.'</td><td>'.date("m-d-Y",strtotime($list->created_at)).'</td><td><p class="callnote_deletebtn" title="Delete" data-id="'.$list->id.'"><i class="fas fa-times"></i></p></td></tr>';
            }
            $table.='</tbody></table></div>';

            return response()->json(['status'=>true,'data'=>$table,'msg'=>'Call note has successfully added']);
        }
        return response()->json(['status'=>false,'msg'=>'No call note Found','data'=>'']);
    }

    /**
    * This function will be used to delete the sticky note from the 'sticky_notes' table.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function RemoveStickyNote(Request $request) {
           
        $validator = Validator::make($request->all(), [
            'sticky_id' => 'required'
        ]);

        if($validator->fails()) {
            
            return response()->json(['status'=>false,'msg' => $validator->errors()->first()]);
        }

        $updateRes = StickyNote::where('id',$request->sticky_id)->update([
            'deleted' => '1',
            'updated_at'=>Carbon::now()
        ]);

        if ($updateRes) {

            return response()->json(['status'=>true,'msg'=>'Sticky Note deleted successfully!']);
        }

        return response()->json(['status'=>false,'msg'=>'something went wront']);
    }

    /**
    * This function will be used to delete the call note
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function removeCallNote(Request $request) {
           
        $validator = Validator::make($request->all(), [
            'callNote_id' => 'required'
        ]);

        if($validator->fails()) {
            
            return response()->json(['status'=>false,'msg' => $validator->errors()->first()]);
        }

        $updateRes = Note::where('id',$request->callNote_id)->update([
            'deleted' => '1',
            'updated_at'=>Carbon::now()
        ]);

        if ($updateRes) {

            return response()->json(['status'=>true,'msg'=>'Call Note deleted successfully!']);
        }

        return response()->json(['status'=>false,'msg'=>'something went wront']);
    }

    /**
    * This function will be used to get call note based on appointment-id.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    protected function getCallnoteByAppointment(int $appointment_id) {

        return Note::where(['appointment_id' => $appointment_id,'deleted'=>'0'])->orderBy('id','DESC')->get();

    }

    /**
    * This function will be used to get call sticky based on appointment-id.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    protected function getStickynoteByAppointment(int $appointment_id) {

        return StickyNote::where(['appointment_id' => $appointment_id,'deleted'=>'0'])->orderBy('id','DESC')->get();

    }

    /**
    * This function will be used to view the pdf file.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function pdfviewerold(Request $request) {

        if(!isset($request->url)) {
            return "something went wrong";
        }
        return view('clinic.pdfviewer',['file'=>$request->url]);
    }

    public function pdfviewer(Request $request) {
      
        if($request->url == '') {
            return "file not found";
        }

        $signatureURL = signatureURL($request->url);
        
        return view('clinic.pdfviewer',['file'=>$signatureURL]);
    }

    /**
    * This function will be used to save the examinee into the database.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function addPatient(Request $request) {

        try {

            $validator = Validator::make($request->all(), [
                'service_date' => 'required',
                'location' => 'required',
                // 'service_time' => 'required',
                'add_first_name' => 'required',
                'add_last_name' => 'required',
                // 'dob' => 'required',
                // 'add_phone' => 'required|phone_len_validate',
            ]);
    
            if($validator->fails()) {
    
                return response()->json(['status'=>false,'msg' => $validator->errors()->first()]);
            }

            $fullName = $request->add_first_name." ".$request->add_last_name;

            if (isset($request->dob) && $request->dob != '') {

                $checkPatient = $this->getPatientByField(['first_name' => $fullName, 'dob' => date("Y-m-d",strtotime($request->dob))]);
                
            } else {
                $checkPatient = $this->getPatientByField(['first_name' => $fullName, 'dob' => '']);
               
            }
            
 
            if (count($checkPatient) > 0) {

                return response()->json(['status'=>false,'msg' => 'Examinee is already exists']);
            }

            // $checkCaseId = $this->getAppointmentByField(['case_id'=>$request->add_case_id]);
            
            // if (count($checkCaseId) > 0) {

            //     return response()->json(['status'=>false,'msg' => 'Case Id is already exists']);
            // }

            
            $phoneNo = isset($request->add_phone) ? str_replace(["|","-","&"],'',$request->add_phone) : '';
            $dob = isset($request->dob) && $request->dob != '' ? convertDateIST($request->dob) : '';

            $saveRes = Patient::create([
                'first_name' => $fullName,
                'last_name' => $fullName,
                'dob' => $dob,
                'phone' => $phoneNo,
                'created_at'=>Carbon::now()
            ]);
    
            if($saveRes) {

                $Savefilename = str_replace(" ","-",str_replace(",","",$fullName)."-"."_".$saveRes->id)."-details.pdf";
                $invoicepath  = '';
                $cepacketpath = '';
                if ($request->hasFile('invoice')) {
                    $Filevalidator = Validator::make($request->all(), [
                        'invoice' => 'required|mimes:pdf|max:52000'
                    ]);
            
                    if($Filevalidator->fails()) {
                        return response()->json(['status'=>false,'msg' => $Filevalidator->errors()->first()]);
                    }

                    $originalExtension = $request->invoice->getClientOriginalExtension();
                    if ($originalExtension != 'pdf') {
                        return response()->json(['status'=>false,'msg'=>'something went suspected!']);
                    }

                    $invoiceOriginalName = $request->invoice->getClientOriginalName();
                    $invoiceArray = explode(".", $invoiceOriginalName);

                    if (count($invoiceArray) !== 2) {
                        if ($invoiceArray[1] == "php") {
                            return response()->json(['status'=>false,'msg'=>'something went suspected!']);
                        } else {
                            return response()->json(['status'=>false,'msg'=>'No periods allowed in filename, please try again!']);
                        }
                    }

                    $invoiceFile = $request->file('invoice');
                    $invoicepath = $this->saveDocumentToS3bucket('invoice/'.$Savefilename,file_get_contents(
                        $invoiceFile));
                }
                if ($request->hasFile('cepacket')) {
                    $Filevalidator = Validator::make($request->all(), [
                        'cepacket' => 'required|mimes:pdf|max:52000'
                    ]);
            
                    if($Filevalidator->fails()) {
                        return response()->json(['status'=>false,'msg' => $Filevalidator->errors()->first()]);
                    }

                    $originalExtension = $request->cepacket->getClientOriginalExtension();
                    if ($originalExtension != 'pdf') {
                        return response()->json(['status'=>false,'msg'=>'something went suspected!']);
                    }

                    $cepacketOriginalName = $request->cepacket->getClientOriginalName();
                    $cepacketArray = explode(".", $cepacketOriginalName);

                    if (count($cepacketArray) !== 2) {
                        if ($cepacketArray[1] == "php") {
                            return response()->json(['status'=>false,'msg'=>'something went suspected!']);
                        } else {
                            return response()->json(['status'=>false,'msg'=>'No periods allowed in filename, please try again!']);
                        }
                    }

                    $cepacketFile = $request->file('cepacket');
                    $cepacketpath = $this->saveDocumentToS3bucket('CEpacket/'.$Savefilename,file_get_contents($cepacketFile));
                }
       
                $specialRequestText = isset($request->add_special_request) ? $request->add_special_request : "";
                $examTypeText = isset($request->exam_type) ? $request->exam_type : ""; 
                
                $serviceTime = isset($request->service_time) && $request->service_time != '' ? date('H:i:s',strtotime($request->service_time)) : '';
              
                $caseId = isset($request->add_case_id) && $request->add_case_id != '' ? $request->add_case_id : '';

                $saveAppointmentRes = Appointment::create([
                    'location_id' => $request->location,
                    'service_date' => $request->service_date,
                    'service_time' => $serviceTime, 
                    'patient_id' => $saveRes->id,
                    'case_id' => $caseId,
                    'invoice_url' => $invoicepath,
                    'cepacket_url' => $cepacketpath,
                    'type_of_exam' => $examTypeText,
                    'special_instruction' => $specialRequestText,
                    'created_at' => Carbon::now()
                ]);
    
                if ($saveAppointmentRes) {
                    $savedAppointmentId = $saveAppointmentRes->id;
                    $newClinicData = Appointment::where(['service_date'=>$request->service_date,'location_id'=>$request->location,'deleted'=>0])->first();

                    if ($newClinicData) {
                        $newClinicStatus = $newClinicData->clinic_status;
                        $newClinicReason = $newClinicData->clinic_reason;

                        Appointment::where(['id'=>$savedAppointmentId])->update([
                            'clinic_status'=>$newClinicStatus,
                            'clinic_reason'=>$newClinicReason
                        ]);
                    }
                    
                    return response()->json(['status'=>true,'msg'=>'Examinee has successfully added']);
                    
                }
                return response()->json(['status'=>false,'msg'=>'something went wrong to save appointment']);
            }
    
            return response()->json(['status'=>false,'msg'=>'something went wrong to save examinee']);

        } catch (\Throwable $th) {

            return response()->json(['status'=>false,'msg'=>$th->getMessage()."-".$th->getLine()]);
        }
    }

    /**
    * This function will be used to update the examinee into the database.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function updatePatient(Request $request) {
        
        // return $request->all();
        try {

            $updateData = [];

            $validator = Validator::make($request->all(), [
                'service_date' => 'required',
                'location' => 'required',
                'first_name' => 'required',
                'last_name' => 'required',
                'appointment_id'=>'required',
                'edit_service_date' => 'required'
            ]);
    
            if($validator->fails()) {
    
                return response()->json(['status'=>false,'msg' => $validator->errors()->first()]);
            }

            $checkAppointment = $this->getAppointmentByField(['id'=>$request->appointment_id]);
            
            if (count($checkAppointment) > 0) {
                
                $fullName = $request->first_name." ".$request->last_name;

                if (isset($request->dob) && $request->dob != '') {

                    $checkPatient = Patient::where(['first_name' => $fullName, 'dob' => date("Y-m-d",strtotime($request->dob))])->where('id','!=',$checkAppointment[0]->patient_id)->first();
                    
                } else {
                    $checkPatient = Patient::where(['first_name' => $fullName, 'dob' => '',])->where('id','!=',$checkAppointment[0]->patient_id)->first();
                }

                if ($checkPatient) {

                    return response()->json(['status'=>false,'msg' => 'Examinee already exists']);
                }
                // echo "<pre>";
                // print_r( $checkPatient);die("sdfsdf");
                // $checkCaseId = Appointment::where(['case_id'=>$request->case_id])->where('id','!=',$checkAppointment[0]->id)->first();
                
                // if ($checkCaseId) {
                //     return response()->json(['status'=>false,'msg' => 'Case Id is already exists']);
                // }

                $savePatienthistory  = $this->savePatientHistory($checkAppointment[0]->patient_id);

                if (!$savePatienthistory) {

                    return response()->json(['status'=>false,'msg' => 'Something went wrong to Examinee history']);
                }

                $saveHistory = $this->saveAppointmentHistory($request->appointment_id);

                if (!$saveHistory) {

                    return response()->json(['status'=>false,'msg' => 'Something went wrong to save history']);
                }

                $prevServiceDate = $checkAppointment[0]->service_date;
                $newServiceDate = convertDateIST($request->edit_service_date);
                $prevLocationId = $checkAppointment[0]->location_id;

                $newClinicStatus = 0;
                $newClinicReason = '';

                if (($prevLocationId != $request->location) || (strtotime($prevServiceDate) != strtotime($newServiceDate))) {
                    $updatePreviousRecords = Appointment::where(['service_date'=>$prevServiceDate,'location_id'=>$prevLocationId,'deleted'=>0])->update([
                        'merged_invoice_status'=>'0',
                        'merged_invoice_url'=>'',
                        'merged_record_status'=>'0',
                        'merged_record_url'=>'',
                    ]);
                    if ($updatePreviousRecords) {
                    } else {
                        return response()->json(['status'=>false,'msg'=>'something went wrong to update previous status']);
                    }

                    $newClinicData = Appointment::where(['service_date'=>$newServiceDate,'location_id'=>$request->location,'deleted'=>0])->first();
                    
                    if ($newClinicData) {
                        $newClinicStatus = $newClinicData->clinic_status;
                        $newClinicReason = $newClinicData->clinic_reason;
                    }
                }
                
                $invoiceFilename = str_replace([" ","'",'"',""],"-",str_replace(",","",$fullName)."-".$checkAppointment[0]->id)."-invoice-details.pdf";
                $cepacketFilename = str_replace([" ","'",'"',""],"-",str_replace(",","",$fullName)."-".$checkAppointment[0]->id)."-records-details.pdf";
                
                $updateData['invoice_update'] = '0';
                if ($request->hasFile('invoice')) {
                    
                    $Filevalidator = Validator::make($request->all(), [
                        'invoice' => 'required|mimes:pdf|max:52000'
                    ]);
            
                    if($Filevalidator->fails()) {
            
                        return response()->json(['status'=>false,'msg' => $Filevalidator->errors()->first()]);
                    }

                    $originalExtension = $request->invoice->getClientOriginalExtension();
                    if ($originalExtension != 'pdf') {
                        return response()->json(['status'=>false,'msg'=>'something went suspected!']);
                    }

                    $invoiceOriginalName = $request->invoice->getClientOriginalName();
                    $invoiceArray = explode(".", $invoiceOriginalName);

                    if (count($invoiceArray) !== 2) {
                        if ($invoiceArray[1] == "php") {
                            return response()->json(['status'=>false,'msg'=>'something went suspected!']);
                        } else {
                            return response()->json(['status'=>false,'msg'=>'No periods allowed in filename, please try again!']);
                        }
                    }

                    $invoiceFile = $request->file('invoice');
                    $invoicepath = $this->saveDocumentToS3bucket('invoice/'.$invoiceFilename,file_get_contents(
                        $invoiceFile));

                    $updateData['invoice_url'] = $invoicepath;
                    $updateData['invoice_update'] = '1'; 
                }
                if (!($request->hasFile('invoice'))) {
                    $updateData['invoice_update'] = '0';
                }

                if ($request->hasFile('cepacket')) {

                    $Filevalidator = Validator::make($request->all(), [
                        'cepacket' => 'required|mimes:pdf|max:52000'
                    ]);
            
                    if($Filevalidator->fails()) {
            
                        return response()->json(['status'=>false,'msg' => $Filevalidator->errors()->first()]);
                    }

                    $originalExtension = $request->cepacket->getClientOriginalExtension();
                    if ($originalExtension != 'pdf') {
                        return response()->json(['status'=>false,'msg'=>'something went suspected!']);
                    }

                    $cepacketOriginalName = $request->cepacket->getClientOriginalName();
                    $cepacketArray = explode(".", $cepacketOriginalName);

                    if (count($cepacketArray) !== 2) {
                        if ($cepacketArray[1] == "php") {
                            return response()->json(['status'=>false,'msg'=>'something went suspected!']);
                        } else {
                            return response()->json(['status'=>false,'msg'=>'No periods allowed in filename, please try again!']);
                        }
                    }

                    $cepacketFile = $request->file('cepacket');
                    $cepacketpath = $this->saveDocumentToS3bucket('CEpacket/'.$cepacketFilename,file_get_contents(
                        $cepacketFile));
                    $updateData['cepacket_url'] = $cepacketpath;
                    $updateData['record_update'] = '1';
                }

                if (!($request->hasFile('cepacket'))) {
                    $updateData['record_update'] = '0';
                }


                
                $phoneNo = isset($request->phone) ? str_replace(["|","-","&"],'',$request->phone) : '';
                
                $dob = isset($request->dob) && $request->dob != '' ? convertDateIST($request->dob) : '';
                $saveRes = Patient::where('id',$checkAppointment[0]->patient_id)->update([
                    'first_name' => $fullName,
                    'last_name' => $fullName,
                    'dob' => $dob,
                    'phone' => $phoneNo,
                    'updated_at'=>Carbon::now()
                ]);

                // return $saveRes;
                 
                if($saveRes) {
                    
                    //array for store update data into appointment table. 
                    
                    $updateData['location_id'] = $request->location;
                    $updateData['service_date'] = convertDateIST($request->edit_service_date);
                    $updateData['service_time'] = isset($request->service_time) && $request->service_time != '' ? date('H:i:s',strtotime($request->service_time)) : '';
                    $updateData['case_id'] = isset($request->case_id) ? $request->case_id : '';
                    $updateData['updated_at'] = Carbon::now();

                    $updateData['special_instruction'] = $request->special_request;
                    $updateData['type_of_exam'] = $request->edit_type_of_exam;
                    
                    $Savefilename = str_replace(" ","-",str_replace(",","",$fullName)."-"."_".$checkAppointment[0]->pateint_id)."-details.pdf";
                    $updateData['merged_invoice_status'] = '0';
                    $updateData['merged_invoice_url'] = '';
                    $updateData['merged_record_status'] = '0';
                    $updateData['merged_record_url'] = '';
                    $updateData['clinic_status'] = $newClinicStatus;
                    $updateData['clinic_reason'] = $newClinicReason;
                    
                    $saveAppointmentRes = Appointment::where('id',$checkAppointment[0]->id)->update($updateData);
        
                    if ($saveAppointmentRes) {
        
                        return response()->json(['status'=>true,'msg'=>'Examinee has successfully updated']); 
                    }

                    return response()->json(['status'=>false,'msg'=>'something went wrong to update appointment']);
                }

                return response()->json(['status'=>false,'msg'=>'something went wrong to update examinee']);
            }

            return response()->json(['status'=>false,'msg'=>'No Appointment found']);

        } catch (\Throwable $th) {

            return response()->json(['status'=>false,'msg'=>$th->getMessage()."-".$th->getLine()]);
        }
    }

    /**
    * This function will be used to get appointment list from the database based on given fields/conditions.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    protected function getAppointmentByField(array $data) {

        return Appointment::where($data)->get();

    }
    
    /**
    * This function will be used to save the examinee into the database.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    protected function getPatientByField(array $data,$row=true) {
 
        return $row ? Patient::where($data)->get() : Patient::where($data)->first();

    }

    public function getSechduleAppointmentCount(string $date,int $location) {

        return Appointment::where('status','!=',2)->where('patient_id','!=','0')->where(['service_date'=>$date,'location_id' => $location,'deleted'=>0])->count();
    }

    public function getShowedAppointmentCount(string $date,int $location) {

        return Appointment::where('status',0)->where('patient_id','!=','0')->where(['service_date'=>$date,'location_id'=>$location,'deleted'=>0])->count();
    }
    
    /**
    * This function will be used to sechdule/showed count based on appointment that values are showed into the examinee list page.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function getSechduleCount(Request $request) {
        
        $totalSechdule = $this->getSechduleAppointmentCount($request->date,$request->location);

        $totalShowed = $this->getShowedAppointmentCount($request->date,$request->location);

        return response()->json(['status'=>true,'msg'=>'something went wront','totalSechdule'=>$totalSechdule,'totalShowed'=>$totalShowed]);
    }

    /**
    * This function will be used to save the required file into the s3 bucket.
    *
    * @param  object $request  request data 
    * @return string         return file url where file has saved 
    * @throws Exception      Any issues encountered
    */
    public function saveDocumentToS3bucket($filePath,$file) {
        
        $path = Storage::disk('s3')->put($filePath,$file,'private');
        return Storage::disk('s3')->url($filePath);
    }

    /**
    * This function will be used to get examinee detail for edit/update the examinee.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function getPatientDetails(Request $request) {

        try {

            $validator = Validator::make($request->all(), [
                'appointment_id' => 'required',
            ]);
    
            if($validator->fails()) {
                return response()->json(['status'=>false,'data'=>[],'msg'=>$validator->errors()->first()]);
            }
    
            $appointmentData = Appointment::join('locations','locations.id','=','appointments.location_id')
            ->join('patients','patients.id','=','appointments.patient_id')
            ->where('appointments.id',$request->appointment_id)
            ->orderBy('appointments.service_date','DESC')
            ->select('appointments.id as appointment_id','appointments.special_instruction','appointments.type_of_exam','appointments.service_date','appointments.service_time','appointments.invoice_url','appointments.cepacket_url','appointments.case_id','appointments.status','appointments.status_text','appointments.location_id','patients.*')
            ->first();
            
            if ($appointmentData) {
                
                $appointmentData->service_time = $appointmentData->service_time != '' ? date("h:i A",strtotime($appointmentData->service_time)) : ''; 
                $appointmentData->service_date = $appointmentData->service_date != '' ? convertDate($appointmentData->service_date) : '';
                $appointmentData->dob = $appointmentData->dob != '' ? convertDate($appointmentData->dob) : '';
                $appointmentData->phone = formatPhoneNumber($appointmentData->phone);

                return response()->json(['status'=>true,'data'=>$appointmentData]);
            }
            return response()->json(['status'=>false,'data'=>[],'msg'=>'No Record found']);

        } catch (\Throwable $th) {
            return response()->json(['status'=>false,'data'=>[],'msg'=>'something went wrong']);
            //throw $th;\
        }
         
    }

    /**
    * This function will be used to export required data from the database based on service-date and location.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function exportPatientDetails(Request $request) {

        // return $request->all();
        
        $date = $request->service_date;
        $location = $request->location;
        
        $examinerList = $this->getExaminersByDateAndLocation($date,$location); 

        //get Examiner List
        $examiners = count($examinerList) > 0 ? $examinerList['examiner_list']['user_name'] : $this->getAllexaminer($date,$location)['user_name'];

        //get Assistant List
        $assistnlist = $this->getAssistantsByDateAndLocation($date,$location); 
        $assitants = count($assistnlist) > 0 ? $assistnlist['assistant_list']['user_name'] : "";

        $locationList = Location::where('id',$location)->first();

        $locationName = $locationList ? $locationList->name : '';

        $fileLocationName = str_replace(array(" "), '-', trim($locationName));
        // Excel file name for download 
        $fileName = "Examineedetails-".strtolower($fileLocationName)."-".convertDate($date).".xls"; 
        
        $appointmentData = Appointment::join('patients','patients.id','=','appointments.patient_id')
        ->where('appointments.service_date',$date)
        ->where('appointments.location_id',$location)
        ->where('appointments.deleted','0')
        // ->groupBy('appointments.patient_id')
        // ->orderBy('appointments.service_date','DESC')
        ->orderBy(DB::raw('CAST(service_time AS time)'),'ASC')
        ->select('appointments.id as appointment_id','appointments.service_date','appointments.service_time','appointments.invoice_url','appointments.special_instruction','appointments.cepacket_url','appointments.case_id','appointments.status','appointments.status_text','patients.*')
        ->get();

        $totalSechdule = $this->getSechduleAppointmentCount($date,$location);

        $totalShowed = $this->getShowedAppointmentCount($date,$location);

        $clinicDataList = ClinicData::where(['service_date'=> $date,'location_id'=> $location])->first();
        
        $Scrapmodel = new ScrapModel();
        //get clinic calculation data
        $CalculationList = $Scrapmodel->select_query('clinic_calculations',['service_date'=>$date,'location_id'=>$location]);

        // return compact('examinerList','locationList','fileName','appointmentData','date','locationName','examiners','totalSechdule','totalShowed','clinicDataList','CalculationList','assitants');
        
        return view('clinic.exportfile',compact('examinerList','locationList','fileName','appointmentData','date','locationName','examiners','totalSechdule','totalShowed','clinicDataList','CalculationList','assitants'));

    }

    public function masterExport(Request $request) {

    }

    /**
    * This function will be used to track user activity and save its data into the database related to appointment changes.
    *
    * @param  object $request  request data 
    * @return boolean         return true or false
    * @throws Exception      Any issues encountered
    */
    public function saveAppointmentHistory($appointmentId) {

        $oldPatientRecords = Appointment::where(['id'=>$appointmentId, 'deleted'=>'0'])->first();
        
        if ($oldPatientRecords) {

            $examinersData = $this->getExaminersByDateAndLocation($oldPatientRecords->service_date, $oldPatientRecords->location_id);

            if (count($examinersData) > 0) {
                $examinerIds = $examinersData['examiner_list']['user_id'];
            } else {
                $examinerIds = $this->getAllexaminer($oldPatientRecords->service_date, $oldPatientRecords->location_id)['user_id'];
            }

            $assistantData = $this->getAssistantsByDateAndLocation($oldPatientRecords->service_date, $oldPatientRecords->location_id);

            if (count($assistantData) > 0) {
                $assistantIds = $assistantData['assistant_list']['user_id'];
            } else {
                $assistantIds = '';
            }

            $saveClinichistory = [];
            $saveClinichistory['appointment_id'] = $oldPatientRecords->id;
            $saveClinichistory['service_date'] = $oldPatientRecords->service_date;
            $saveClinichistory['service_time'] = $oldPatientRecords->service_time;
            $saveClinichistory['patient_id'] = $oldPatientRecords->patient_id;
            $saveClinichistory['user_id'] = $oldPatientRecords->user_id;
            $saveClinichistory['location_id'] = $oldPatientRecords->location_id;
            $saveClinichistory['invoice_url'] = $oldPatientRecords->invoice_url;
            $saveClinichistory['cepacket_url'] = $oldPatientRecords->cepacket_url;
            $saveClinichistory['combined_url'] = $oldPatientRecords->combined_url;
            $saveClinichistory['type_of_exam'] = $oldPatientRecords->type_of_exam;
            $saveClinichistory['request_status'] = $oldPatientRecords->request_status;
            $saveClinichistory['special_instruction'] = $oldPatientRecords->special_instruction;
            $saveClinichistory['case_id'] = $oldPatientRecords->case_id;
            $saveClinichistory['status'] = $oldPatientRecords->status;
            $saveClinichistory['active'] = $oldPatientRecords->active;
            $saveClinichistory['deleted'] = $oldPatientRecords->deleted;
            $saveClinichistory['examiner_id'] = $examinerIds;
            $saveClinichistory['assistant_id'] = $assistantIds;
            $saveClinichistory['updated_by'] = Auth::user()->id;
            $saveClinichistory['created_at'] = Carbon::now();
            $saveClinichistory['invoice_update'] = $oldPatientRecords->invoice_update;
            $saveClinichistory['record_update'] = $oldPatientRecords->record_update;


            // Save previous history of patient
            return ClinicHistory::create($saveClinichistory);
        }

        return false;
    }
    
    /**
    * This function will be used to track user activity and save its data into the database related to patient changes.
    *
    * @param  object $request  request data 
    * @return boolean         return true or false
    * @throws Exception      Any issues encountered
    */
    protected function savePatientHistory(int $patient_id) {

        $patientList = $this->getPatientByField(['id'=>$patient_id],false);

        if ($patientList) {

            $saveDataArray = [];
            $saveDataArray['patient_id'] = $patientList->id;
            $saveDataArray['first_name'] = $patientList->first_name;
            $saveDataArray['last_name'] = $patientList->last_name;
            $saveDataArray['phone'] = $patientList->phone;
            $saveDataArray['dob'] = $patientList->dob;
            $saveDataArray['active'] = $patientList->active;
            $saveDataArray['updated_by'] = Auth::user()->id;
            $saveDataArray['created_at'] = Carbon::now();
            $saveDataArray['updated_at'] = Carbon::now();
            
            $Scrapmodel = new ScrapModel();
            return $Scrapmodel->insert_query('patient_history',$saveDataArray);
        }
        return false;
    }

    /**
    * This function will be used to track user activity and save its data into the database related to clinic changes.
    *
    * @param  object $request  request data 
    * @return boolean         return true or false
    * @throws Exception      Any issues encountered
    */
    protected function saveClinicDataHistory(int $id) {

        $clinicList = ClinicData::where('id',$id)->first();

        if ($clinicList) {

            $saveDataArray = [];
            $saveDataArray['clinic_id'] = $clinicList->id;
            $saveDataArray['service_date'] = $clinicList->service_date;
            $saveDataArray['location_id'] = $clinicList->location_id;
            $saveDataArray['team_member'] = $clinicList->team_member;
            $saveDataArray['contact_type'] = $clinicList->contact_type;
            $saveDataArray['chart_type'] = $clinicList->chart_type;
            $saveDataArray['x_ray_vendor'] = $clinicList->x_ray_vendor;
            $saveDataArray['from_time'] = $clinicList->from_time;
            $saveDataArray['to_time'] = $clinicList->to_time;
            $saveDataArray['admin_write_in'] = $clinicList->admin_write_in;
            $saveDataArray['assistant_write_in'] = $clinicList->assistant_write_in;
            $saveDataArray['training'] = $clinicList->training;
            $saveDataArray['email'] = $clinicList->email;
            $saveDataArray['invite'] = $clinicList->invite;
            $saveDataArray['updated_by'] = Auth::user()->id;
            $saveDataArray['created_at'] = Carbon::now();
            // $saveDataArray['xray'] = $clinicList->xray;

            $Scrapmodel = new ScrapModel();
            
            return $Scrapmodel->insert_query('clinic_data_history',$saveDataArray);
        }
        return false;
    }

    /**
    * This function will be used to upload the clinic document that functionality perform under the examinee list page.
    *
    * @param  object $request  request data 
    * @return boolean         return true or false
    * @throws Exception      Any issues encountered
    */
    public function uploadClinicDocuments(Request $request) {

        try {

            $validator = Validator::make($request->all(), [
                'service_date' => 'required',
                'location_id' => 'required',
                'clinic_file'=>  'required|mimes:pdf|max:52000'
            ]);

            if ($validator->fails()) {
    
                return redirect()->back()->with('status',$validator->errors()->first());
            }

            $checkAppointment = $this->getAppointmentByField(['service_date' => $request->service_date,'location_id' => $request->location_id,'deleted' => '0']);

            if (count($checkAppointment) == 0) {
    
                return redirect()->back()->with('status','Appointment is not found for this date-'.$request->service_date.' location_id-'.$request->location_id.'');
            }

            $documentPath = '';

            if ($request->hasFile('clinic_file')) {

                $originalExtension = $request->clinic_file->getClientOriginalExtension();
                if ($originalExtension != 'pdf') {
                    return redirect()->back()->with('status','something went suspected!');
                }

                $clinicFileOriginalName = $request->clinic_file->getClientOriginalName();
                $clinicFileArray = explode(".", $clinicFileOriginalName);

                if (count($clinicFileArray) !== 2) {
                    if ($clinicFileArray[1] == "php") {
                        return redirect()->back()->with('status','something went suspected!');
                    } else {
                        return redirect()->back()->with('status','No periods allowed in filename, please try again!');
                    }
                }
                
                $documetfile = $request->file('clinic_file');

                $Savefilename = "documentFile-".date("YmdHis").'.pdf';

                $documentPath = $this->saveDocumentToS3bucket('clinicDocument/'.$Savefilename,file_get_contents(
                    $documetfile));
            }

            $Scrapmodel = new ScrapModel();

            $checkRecord = [];//$Scrapmodel->select_query('clinic_documents',['service_date'=>$request->service_date,'location_id'=>$request->location_id]);

            $saveDataArray = [];
            $saveDataArray['service_date'] = date("Y-m-d",strtotime($request->service_date));
            $saveDataArray['location_id'] = $request->location_id;
            $saveDataArray['path'] = $documentPath;
            $saveDataArray['updated_by'] = Auth::user()->id;

            if (count($checkRecord) > 0) {
                
                $saveDataArray['updated_at'] = Carbon::now();

                $updateRes = $Scrapmodel->update_query('clinic_documents',$saveDataArray,['service_date'=>$request->service_date,'location_id'=>$request->location_id]);

                if ($updateRes) {
                    
                    return redirect()->back()->with('status','File has successfully updated');
                }

            } else {
                
                $saveDataArray['created_at'] = Carbon::now();
                
                $saveRes = $Scrapmodel->insert_query('clinic_documents',$saveDataArray);

                if ($saveRes) {

                    return redirect()->back()->with('status','File has successfully uploaded');
                }

                return redirect()->back()->with('status','Something went wrong to upload the file');
            }

        } catch (\Throwable $th) {
            
            return redirect()->back()->with('status',$th->getMessage());

        } catch (\Exception $th) {
            
            return redirect()->back()->with('status',$th->getMessage());
        }
    }

    public function saveClinicCalculations(Request $request) {
        
        $validator = Validator::make($request->all(), [
            'service_date' => 'required',
            'location_id' => 'required',
            'submitted_by' => 'required',
            'submitted_date' => 'required',
            'examiner_pay' => 'required',
            'revenue' => 'required'
        ]);

        if ($validator->fails()) {

            return redirect()->back()->with('status', $validator->errors()->first());
        }

        $Scrapmodel = new ScrapModel();

        $checkData = $Scrapmodel->select_query('clinic_calculations',['service_date'=>$request->service_date,'location_id'=>$request->location_id]);

        $saveDataArray = [
            'service_date' => $request->service_date,
            'location_id' => $request->location_id,
            'submitted_by' => $request->submitted_by,
            'submitted_date' => convertDateIST($request->submitted_date),
            'examiner_pay' => $request->examiner_pay,
            'revenue' => $request->revenue
        ];
        if (count($checkData) > 0) {

            try {

                $saveDataArray['updated_at'] = Carbon::now();

                $saveRes = $Scrapmodel->update_query('clinic_calculations',$saveDataArray,['id'=>$checkData[0]->id]);

                if ($saveRes) {

                    return redirect()->back()->with('status', 'Clinic details has successfully saved');
                }

                return redirect()->back()->with('status', 'Clinic details has not saved');
                
            } catch (\Throwable $th) {
                //throw $th;
                return redirect()->back()->with('status', 'Something went wrong to save clinic details');
            }

        } else {

            try {
                $saveDataArray['created_at'] = Carbon::now();
                $saveRes = $Scrapmodel->insert_query('clinic_calculations',$saveDataArray);

                if ($saveRes) {

                    return redirect()->back()->with('status', 'Clinic details has successfully saved');
                }
                return redirect()->back()->with('status', 'Clinic details has not saved');
            } catch (\Throwable $th) {
                //throw $th;
                return redirect()->back()->with('status', 'Something went wrong to save clinic details');
            }
           
        }
    }
    
    /**
    * This function will be used to delete the appointment
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function deleteAppointment(Request $request) {
           
        try {
            $validator = Validator::make($request->all(), [
                'appointment_id' => 'required'
            ]);
            
            if($validator->fails()) {
                return response()->json(['status'=>false,'msg' => $validator->errors()->first()]);
            }
    
            $saveHistory = $this->saveAppointmentHistory($request->appointment_id);
    
            if (!$saveHistory) {
    
                return response()->json(['status'=>false,'msg' => 'Something went wrong to save history']);
            }
    
            $updateAppt = Appointment::where('id',$request->appointment_id)->update([
                'deleted'=>'1',
                'updated_at' => Carbon::now(),
                'updated_by' => Auth::user()->id
            ]);
    
            if($updateAppt) {
                return response()->json(['status'=>true,'msg'=>'Appointment deleted successfully!']);
            }

            return response()->json(['status'=>false,'msg'=>'something went wrong to delete Appointment']);

        } catch (\Throwable $th) {
            return response()->json(['status'=>false, 'msg'=> $th->getMessage()]);
        }

        
    }

    public function getAppointmentHistory($appointmentId) {

        $currentRecord = Appointment::leftjoin('users','users.id','=','appointments.user_id')
        ->join('patients','patients.id','=','appointments.patient_id')
        ->join('locations','locations.id','=','appointments.location_id')
        ->orderBy('id','DESC')
        ->where('appointments.id',$appointmentId)
        ->where('appointments.deleted',0)
        ->select('appointments.*','users.name as user_name','locations.name as location_name','patients.first_name as patient_name','patients.phone as patient_phone','patients.dob')
       ->distinct()->first();

        $historyRecord = ClinicHistory::join('patients','patients.id', '=','clinic_history.patient_id')
        ->join('users','users.id','=','clinic_history.updated_by')
        ->join('locations','locations.id','=','clinic_history.location_id')
        ->orderBy('clinic_history.id','DESC')
        ->where('clinic_history.appointment_id',$appointmentId)->select('clinic_history.*','users.name as user_name','locations.name as location_name','patients.first_name as patient_name')->get();

        $examinersAndAssistants = $this->currentExaminerAssistantRecord($appointmentId);
      
        $getLastUser = ClinicHistory::where('appointment_id',$appointmentId)->orderBy('updated_at', 'desc')->get();
       
        $updatedByUser = [];
        $updatedAtApptHistory = [];
        for ($i=1; $i<=count($getLastUser); $i++) {
            if (isset($getLastUser[$i]['updated_by'])) {
                $data =  User::find($getLastUser[$i]['updated_by']);    
                $updatedByUser[] = $data->name;
            }
            if (isset($getLastUser[$i]['updated_at'])) {
                $updatedAtApptHistory[] = date('m-d-Y H:i:s', strtotime($getLastUser[$i]['updated_at']));
            }
        }
    
     
        $getLastUserNew = ClinicHistory::where('appointment_id',$appointmentId)->orderBy('updated_at', 'desc')->first();
        $firstName = '';
        $updatedAtApptHistoryLatest = '';

        if (isset($getLastUserNew )) {
            $nameValue =  User::find($getLastUserNew->updated_by);
            $firstName = $nameValue->name;
            $updatedAtApptHistoryLatest = date('m-d-Y H:i:s', strtotime($getLastUserNew->updated_at));
        }
      
        return view('clinic.appointment-history', compact('historyRecord', 'currentRecord','updatedByUser','firstName','updatedAtApptHistory','updatedAtApptHistoryLatest','examinersAndAssistants'));
    }

    public function getExamineeHistory($patientId) {

       $patientRecord = PatientHistory::join('patients','patients.id', '=','patient_history.patient_id')
       ->join('users','users.id','=','patient_history.updated_by')
       ->orderBy('patient_history.updated_at','DESC')
       ->where('patients.id', $patientId)->select('patient_history.*','users.name')->get();
       
       $currentPatientRecord = Patient::where('id',$patientId)
       ->first();

       $getLastUserPatient = PatientHistory::where('patient_id',$patientId)->orderBy('updated_at', 'desc')->get();
        
        $updatedByUserPatient = [];
        $updatedAtPatient = [];
        for ($i=1; $i<=count($getLastUserPatient); $i++) {
            if (isset($getLastUserPatient[$i]['updated_by'])) {
                $dataUpdatedBy =  User::find($getLastUserPatient[$i]['updated_by']);    
                $updatedByUserPatient[] = $dataUpdatedBy->name;
            }
            if (isset($getLastUserPatient[$i]['updated_at'])) {
                $updatedAtPatient[] = date('m-d-Y H:i:s', strtotime($getLastUserPatient[$i]['updated_at']));
            }
        }
    
        $getLastUserNewPatient = PatientHistory::where('patient_id',$patientId)->orderBy('updated_at', 'desc')->first();
        $firstNamePatient = '';
        $updatedAtLatest = '';

        if (isset($getLastUserNewPatient )) {
            $nameValuePatient =  User::find($getLastUserNewPatient->updated_by);
            $firstNamePatient = $nameValuePatient->name;
            $updatedAtLatest = date('m-d-Y H:i:s', strtotime($getLastUserNewPatient->updated_at));
        }

       return view('clinic.patient-history', compact('patientRecord','currentPatientRecord','updatedByUserPatient','firstNamePatient','updatedAtPatient','updatedAtLatest'));
    }

    public function getClinicDataHistory($date,$locationId) {
        $appt = Appointment::where(['id'=>$locationId])->first();
        $historyRecord= ClinicDataHistory::where(['service_date'=> $date,'location_id'=> $locationId])
        ->orderBy('created_at', 'desc')
        ->get();

        $currentClinicRecord = ClinicData::where(['service_date'=> $date,'location_id'=> $locationId])->first();
   
        return view('clinic.clinicdatalist', ['date'=>$date,'location_id'=>$locationId],compact('historyRecord', 'appt', 'currentClinicRecord'));
    }

    public function currentExaminerAssistantRecord($appointmentId){
        $oldPatientRecords = Appointment::where(['id'=>$appointmentId, 'deleted'=>'0'])->first();
        $examinersData = [];
        $assistantData = [];
        if ($oldPatientRecords) {

            $examinersData = $this->getExaminersByDateAndLocation($oldPatientRecords->service_date, $oldPatientRecords->location_id);
            $assistantData = $this->getAssistantsByDateAndLocation($oldPatientRecords->service_date, $oldPatientRecords->location_id);
        }
        
        return [$examinersData, $assistantData];
    }

}