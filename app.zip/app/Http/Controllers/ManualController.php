<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use LynX39\LaraPdfMerger\Facades\PdfMerger as PDFMerger;

class ManualController extends Controller
{
    //
    public function manualInvoice() {
        $filename = public_path()."/zmanual/Dale Lockhart.pdf";
        $invoiceRule = '2,3,4,5';
        $pdfMarger = PDFMerger::init();
        
        $pdfMarger->addPDF($filename, $invoiceRule, 'P');
        $pdfMarger->merge();
        $saveFile = public_path()."/zmanual/request_letter.pdf";
        return $pdfMarger->save($saveFile);
    }

    public function manualCEPacketBackupxxx() {

        $filename = public_path()."/zmanual/Dale Lockhart.pdf";
        $invoiceRule = '2,3,4,5';
        $splitPage  = explode(",",$invoiceRule);
        $CepacketPages = [];
        $invoive_url = '';
        $combined_url = '';
        $CEpacketMerger = PDFMerger::init();
        $FileRemoveArray = [];
        $fileCheck = false;
        $mergeFileNameArray = [];

        $pdfPageCount = $this->countPages($filename);
        $FileRemoveArray[] = $filename;
        $pdfCount = $pdfPageCount;
        $CEPacket = range(1,$pdfCount);
        $CepacketPages =  array_diff($CEPacket,$splitPage);
        $pageList = implode(",", $CepacketPages);
        $outputFileName = public_path()."/".'createcepacketfrominvoice.pdf';
        $FileRemoveArray[] = $outputFileName;
        $extractRes = $this->extractPagesFromPdf($filename,$pageList,$outputFileName);
        if($extractRes != false) {
            \Log::debug('under the extractRes');
            $mergeFileNameArray[] = $outputFileName;
        }

        $pdfMarger = PDFMerger::init();
        
        $pdfMarger->addPDF($filename, $invoiceRule, 'P');
        $pdfMarger->merge();
        $saveFile = public_path()."/zmanual/request_letter.pdf";
        return $pdfMarger->save($saveFile);
    }

    public function manualCEPacket() {
        
        $filename = public_path()."/DaleLockhart.pdf";
        $invoiceRule = '2,3,4,5';
        $pdfMarger1 = PDFMerger::init();
        
        $pdfMarger1->addPDF($filename, $invoiceRule, 'P');
        $pdfMarger1->merge();
        $saveFile1 = public_path()."/invoice130.pdf";
        $pdfMarger1->save($saveFile1);

        $filename1 = public_path()."/DaleLockhart.pdf";
        $pdfPageCount = $this->countPages($filename1);
        // dd($pdfPageCount);
        $invoiceRule1 = [2,3,4,5];
        $CEPacket = range(1,$pdfPageCount);
        // dd($CEPacket);
        $CepacketPages =  array_diff($CEPacket,$invoiceRule1);
        // dd($invoiceRule);
        $pageList = implode(",", $CepacketPages);

        $pdfMarger = PDFMerger::init();
        
        $pdfMarger->addPDF($filename1, $pageList, 'P');
        $pdfMarger->merge();
        $saveFile = public_path()."/ce_packet130.pdf";
        $pdfMarger->save($saveFile);
    }

    public function extractPagesFromPdf($filePath,$pageList,$outputFileName) {

        try {
            
            //Create the GhostScript command for extract the particular pages from pdf
            $gsCmd = 'gs -sDEVICE=pdfwrite -dNOPAUSE -dBATCH -dSAFER -sPageList='.$pageList.' -sOutputFile='.$outputFileName.' '.$filePath.'';

            \Log::debug('ghostscript command-'.$gsCmd);

            // return $gsCmd;
            //Run it using PHP's exec function.
            $output = array();
            $return = null;
            $cmd = exec($gsCmd,$output,$return);

            if ($return != 0) {
                \Log::debug('ghostscript command response-'.$return);
                return false;
            } else {
                return $cmd;
            }

        } catch (\Exception $e) {
            echo "while extract pages".$e->getMessage();
            return false;
        }
    }

    public function countPages($path) {
        
    	try {
    		
    		//Create the GhostScript command for get pdf page count
	        $gsCmd = 'gs -q -dNODISPLAY -c "('.$path.') (r) file runpdfbegin pdfpagecount = quit";';
	        // return $gsCmd;
	        //Run it using PHP's exec function.
	        $output = array();
	        $return = null;
	        $cmd = exec($gsCmd,$output,$return);

            if ($return != 0) {
                \Log::debug('PageCountCommand-'.$gsCmd);
                return 0;
            } else {
                return $cmd;
            }
			// return $return != 0 ? 0 : $cmd;

    	} catch (\Exception $e) {
			
			return 0;    		
    	}
    }
}
