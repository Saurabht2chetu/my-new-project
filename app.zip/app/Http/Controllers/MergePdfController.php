<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Appointment;
use App\Models\Location;
use Storage;
use DB;

use function PHPSTORM_META\type;

class MergePdfController extends Controller
{

    public function mergeClinicInvoices() {

        \Log::info('invoked mergeClinicInvoices function');
       
        $clinics = Appointment::where('deleted','0')
                            ->where('merged_invoice_status','0')
                            ->where('invoice_url', '!=', '')
                            ->where('invoice_url', '!=', NULL)
                            ->groupBy('service_date')
                            ->groupBy('location_id')
                            ->select('service_date','location_id')
                            ->orderBy('service_date','DESC')
                            ->get();

        if (count($clinics) > 0) {
            foreach($clinics as $clinic) {
                $serviceDate = $clinic->service_date;
                $locationId = $clinic->location_id;

                $mergedPath = $this->mergeInvoicePDF($serviceDate, $locationId);
                \Log::info('merged path -'.$mergedPath);
                if ($mergedPath != '') {
                    $UpdateLoc = Appointment::where('service_date', $serviceDate)->where('location_id', $locationId)->where('deleted', '0')->update([
                        'merged_invoice_url'  => $mergedPath, 
                        'merged_invoice_status'   => 1
                    ]);
                }
            }
            return true;
        }
        return false;
    }

    public function mergeInvoicePDF($serviceDate, $locationId) {
        \Log::info('invoked mergeInvoicePDF function_'.$serviceDate.'_'.$locationId);
        $invoiceServiceDate = $serviceDate;
        $invoiceLocationId = $locationId;

        $appointmentsData = Appointment::where(['service_date'=>$invoiceServiceDate, 'location_id'=>$invoiceLocationId, 'deleted'=>'0'])->where('invoice_url', '!=', '')->where('invoice_url', '!=', NULL)->groupBy('patient_id')->orderBy(DB::raw('CAST(service_time AS time)'),'ASC')->get();

        $clinicInfo = Location::where('id', '=', $invoiceLocationId)->first();
                    
        $clinicName = '';
        if ($clinicInfo) {
            if ($clinicInfo->name != '') {
                $clinicName = $clinicInfo->name;
            } else {
                $clinicName = $clinicInfo->actual_address;
            }
        }

        $clinicName = str_replace(', ', '_', $clinicName);
        $clinicName = preg_replace("/[^a-zA-Z0-9]/", "_", $clinicName);
        
        $fileRemoveArray = [];
        $mergeFileNameArray = [];

        if (count($appointmentsData) > 0) {
            foreach ($appointmentsData as $key => $appointmentData) {

                $urlFileName = basename($appointmentData->invoice_url);
                $signatureURL = signatureURL($appointmentData->invoice_url);

                if (Storage::disk('s3')->exists('invoice/'.$urlFileName)) {
                    file_put_contents(base_path()."/gsfolder/".$urlFileName,file_get_contents($signatureURL));
                    $fileName = base_path()."/gsfolder/".$urlFileName;
                    $fileRemoveArray[] = $fileName;
                    $mergeFileNameArray[] = $fileName;
                }
            }

            if (is_array($mergeFileNameArray) && count($mergeFileNameArray) > 0) {
                $fileNames = implode(" ", $mergeFileNameArray);
                $downloadFileName = 'cron_invoice_'.convertDate($serviceDate).'_'.$clinicName.'.pdf';
                $saveFile = base_path()."/gsfolder/".$downloadFileName;
                $fileRemoveArray[] = $saveFile;
                $mergerFileRes = $this->mergerPdfFile($fileNames, $saveFile);
                \Log::info('Merge File Response-'.$mergerFileRes);
                $mergedInvoiceS3PathUrl = '';
                if ($mergerFileRes == true && file_exists($saveFile)) {

                    \Log::debug('under the cron merge file response');

                    $s3FileName = 'clinicInvoice/'.$downloadFileName;
                    $mergedInvoiceS3PathUrl = $this->saveDocumentToS3bucket($s3FileName, file_get_contents($saveFile));
                }
                
                $removeLen = count($fileRemoveArray);
                \Log::info('URL'.$mergedInvoiceS3PathUrl.'- arraycount'.$removeLen);
                for ($i=0; $i<$removeLen; $i++) { 
                    if (file_exists($fileRemoveArray[$i])) {
                        unlink($fileRemoveArray[$i]);
                    }
                }

                return $mergedInvoiceS3PathUrl;
            } else {
                return '';
            }
        }

        return '';
    }

    public function mergeClinicRecords() {

        \Log::info('invoked mergeClinicRecords function');
    
        $recordsClinics = Appointment::where('deleted','0')
                            ->where('merged_record_status','0')
                            ->where('cepacket_url', '!=', '')
                            ->where('cepacket_url', '!=', NULL)
                            ->groupBy('service_date')
                            ->groupBy('location_id')
                            ->select('service_date','location_id')
                            ->orderBy('service_date','DESC')
                            ->get();
    
        if (count($recordsClinics) > 0) {
            foreach($recordsClinics as $clinic) {
                $recordServiceDate = $clinic->service_date;
                $recordLocationId = $clinic->location_id;
    
                $mergedRecordPath = $this->mergeRecordsPDF($recordServiceDate, $recordLocationId);
                \Log::info('merged path -'.$mergedRecordPath);
                if ($mergedRecordPath != '') {
                    $UpdateLoc = Appointment::where('service_date', $recordServiceDate)->where('location_id', $recordLocationId)->where('deleted', '0')->update([
                        'merged_record_url'  => $mergedRecordPath, 
                        'merged_record_status'   => 1
                    ]);
                }
            }
            return true;
        }
        return false;
    }

    public function mergeRecordsPDF($serviceDate, $locationId) {
        \Log::info('invoked mergeRecordsPDF function_'.$serviceDate.'_'.$locationId);
        $recordsServiceDate = $serviceDate;
        $recordsLocationId = $locationId;
    
        $recordsData = Appointment::where(['service_date'=>$recordsServiceDate, 'location_id'=>$recordsLocationId, 'deleted'=>'0'])->where('cepacket_url', '!=', '')->where('cepacket_url', '!=', NULL)->groupBy('patient_id')->orderBy(DB::raw('CAST(service_time AS time)'),'ASC')->get();
    
        $clinicInfo = Location::where('id', '=', $recordsLocationId)->first();
                    
        $clinicName = '';
        if ($clinicInfo) {
            if ($clinicInfo->name != '') {
                $clinicName = $clinicInfo->name;
            } else {
                $clinicName = $clinicInfo->actual_address;
            }
        }
    
        $clinicName = str_replace(', ', '_', $clinicName);
        $clinicName = preg_replace("/[^a-zA-Z0-9]/", "_", $clinicName);
        
        $recordRemoveArray = [];
        $mergeRecordNameArray = [];
    
        if (count($recordsData) > 0) {
            foreach ($recordsData as $key => $recordData) {
    
                $urlRecordName = basename($recordData->cepacket_url);
                $recordSignatureURL = signatureURL($recordData->cepacket_url);
    
                if (Storage::disk('s3')->exists('CEpacket/'.$urlRecordName)) {
                    file_put_contents(base_path()."/gsfolder/".$urlRecordName,file_get_contents($recordSignatureURL));
                    $recordName = base_path()."/gsfolder/".$urlRecordName;
                    $recordRemoveArray[] = $recordName;
                    $mergeRecordNameArray[] = $recordName;
                }
            }
    
            if (is_array($mergeRecordNameArray) && count($mergeRecordNameArray) > 0) {
                $recordNames = implode(" ", $mergeRecordNameArray);
                $downloadRecordName = 'cron_records_'.convertDate($serviceDate).'_'.$clinicName.'.pdf';
                $saveRecord = base_path()."/gsfolder/".$downloadRecordName;
                $recordRemoveArray[] = $saveRecord;
                $mergerRecordRes = $this->mergerPdfFile($recordNames, $saveRecord);
                \Log::info('Records Merge File Response-'.$mergerRecordRes);
                $mergedRecordS3PathUrl = '';
                if ($mergerRecordRes == true && file_exists($saveRecord)) {
    
                    \Log::debug('under the cron records merge file response');
    
                    $s3RecordName = 'clinicRecords/'.$downloadRecordName;
                    $mergedRecordS3PathUrl = $this->saveDocumentToS3bucket($s3RecordName, file_get_contents($saveRecord));
                }
                
                $removeLength = count($recordRemoveArray);
                \Log::info('URL'.$mergedRecordS3PathUrl.'- arraycount'.$removeLength);
                for ($i=0; $i<$removeLength; $i++) { 
                    if (file_exists($recordRemoveArray[$i])) {
                        unlink($recordRemoveArray[$i]);
                    }
                }
    
                return $mergedRecordS3PathUrl;
            } else {
                return '';
            }
        }
    
        return '';
    }

    public function mergerPdfFile($fileArray, $outputFileName) {
        \Log::info('invoked mergerPdfFile function');
        try {
            
            //Create the GhostScript command for extract the particular pages from pdf
            $gsCmd = 'gs -dBATCH -dNOPAUSE -q -sDEVICE=pdfwrite -sOutputFile='.$outputFileName.' '.$fileArray.'';

            \Log::debug('ghost script pdfmerger command'.$gsCmd);

            // return $gsCmd;
            //Run it using PHP's exec function.
            $output = array();
            $return = null;
            $cmd = exec($gsCmd,$output,$return);

            if ($return != 0) {
                \Log::debug('under the failed file merge response');
                return false;
            } else {
                \Log::debug('under the success file merge response');
                return true;
            }

        } catch (\Exception $e) {
            echo "under the merge pdf function-".$e->getMessage();
            return false;
        }
    }

    /**
    * This function is used for save the document file to S3 bucket.
    *
    * @param  string $filename      filename for save to aws bucket.
    * @param  object $file          file data as raw content. 
    * @return string                return path url
    * @throws Exception             Any issues encountered
    */
    public function saveDocumentToS3bucket($filename, $file) {
        
        \Log::debug('initiate to save documents into the s3 bucket');
        $path = Storage::disk('s3')->put($filename, $file, 'private');
        return Storage::disk('s3')->url($filename);
    }

}
