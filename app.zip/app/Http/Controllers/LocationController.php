<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Location;
use App\Models\States;
use App\Models\City;
use DataTables;
use Validator;
use Carbon\Carbon;
use DB;

/**
* This class is used to interact with the Clinic Locations Module
*
* PHP version 8.0.8
*
* @category  Supporting_Script
* @package   Locations_Module
* @author    Chetu
* @copyright 2021 Chetu
*/

class LocationController extends Controller {

    /**
    * This function will be used to render the list page of location.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function index(Request $request) {

        $action = checkPermission($request->path());
        $states = States::select('*')
            ->orderBy('name', 'Asc')->get();
        $cities = City::select('*')->orderBy('name', 'Asc')->get();
        $clinicTypes = DB::table('clinic_types')->get();

        if ($request->ajax()) {

            $data = Location::leftjoin('states', 'states.id', '=', 'locations.state_id')->leftjoin('cities', 'cities.id', '=', 'locations.city_id')->where('locations.deleted', '=', '0')->select('locations.*', 'states.name as state_name', 'cities.name as city_name')->get();
            
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($row) use ($action) {
                    if ($action == 1) {
                        $btn = '<div class="db-action-box"><div class="edit-icon"><p class="editbtn" data-toggle="tooltip" data-placement="top" title="Edit" data-id="'.$row->id.'"><i class="far fa-edit"></i></p></div><div class="delete-icon"><p class="deletebtn" title="Delete" data-id="'.$row->id.'"><i class="fas fa-times"></i></p></div>';
                    } else {
                        $btn = '<div class="db-action-box"><div class="edit-icon"><p class="access_denied"  data-toggle="tooltip" data-placement="top" title="Edit" ><i class="far fa-edit"></i></p></div><div class="delete-icon"><p class="access_denied" title="Delete" ><i class="fas fa-times"></i></p></div>';
                    }
                    return $btn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }

        return view('locations.list', compact('action', 'states', 'cities', 'clinicTypes'));
    }

    /**
    * This function will be used to add location.
    *
    * @param  object $request   request data 
    * @return object            Json response from the server containing Tasks
    * @throws Exception         Any issues encountered
    */
    public function addLocation(Request $request) {

        try {

            $validator = Validator::make($request->all(), [
                'stateName'     => 'required',
                'cityName'      => 'required',
                'locationName'  => 'required',
                'clinicType'    => 'required'
            ]);
    
            if (isset($request->other_city)) {
    
                $checkeCity = City::where(['name' =>$request->other_city])->first();
    
                if ($checkeCity) {
                    return response()->json(['status'=>false, 'msg'=>'City already exists']);
                }
    
                $city = City::create([
                        'name'      => $request->other_city, 
                        'state_id'  => $request->stateName,
                        'created_at'=> Carbon::now()
                ]);
    
                $cityID = $city ? $city->id : 0; 
            } else {
                $cityID = $request->cityName; 
            }
    
            if ($validator->passes()) {
    
                $location = Location::create([
                    'state_id'  => $request->stateName, 
                    'city_id'   => $cityID,
                    'name'      => $request->locationName,
                    'actual_address' => $request->actualAddress,
                    'clinic_type_id' => $request->clinicType,
                    'created_at'=> Carbon::now()
                ]);
    
                if ($location) {
                    return response()->json(['status'=>true, 'msg'=>'Location has successfully created']);
                } 
    
                return response()->json(['status'=>false, 'msg'=>'something went wrong to add user']);
            }
    
            return response()->json(['status'=>false, 'msg'=>$validator->errors()->first()]);

        } catch (\Throwable $th) {

            //throw $th;
            return response()->json(['status'=>false, 'msg' => $th->getMessage()]);
        }
    
        
    }

    /**
    * This function will be used to fetch the required data for edit the location.
    *
    * @param  object $request   request data 
    * @return object            Json response from the server containing Tasks
    * @throws Exception         Any issues encountered
    */
    public function editLocation(Request $request) { 
        
        try {
           
            $location = Location::where('id', $request->id)->first();
            
            $city = City::where('id', $location->city_id)->value('name');
            $state = States::where('id', $location->state_id)->value('name');
        
            if ($location) {
                return response()->json(['status'=>true, 'data'=>$location, 'city' =>$city, 'state'=>$state, 'msg'=>'record found successfully']);
            }
            return response()->json(['status'=>false, 'data'=>[], 'msg'=>'User does not found']);

        } catch (\Throwable $th) {
            //throw $th;
            return response()->json(['status'=>false, 'data'=>[], 'msg'=>$th->getMessage()]);
        }
        
    }

    /**
    * This function will be used to update the location.
    *
    * @param  object $request   request data 
    * @return object            Json response from the server containing Tasks
    * @throws Exception         Any issues encountered
    */
    public function updateLocation(Request $request) {

        try {

            $response = [];
            $idval = $request->idval;

            if ($idval == '') {
                $response['status'] = false;
                $response['msg'] = 'Id is required';
                return response()->json($response);
            }

            $UpdateLoc = Location::where('id', $idval)->update([
                'name'  => $request->locationName, 
                'actual_address'   => $request->actualAddress,
                'clinic_type_id'   => $request->clinicType
            ]);

            if ($UpdateLoc) {
                $response['status'] = true;
                $response['msg'] = 'Location has successfully updated';
            } else {
                $response['status'] = false;
                $response['msg'] = 'something went wrong to update user';
            }

            return response()->json($response);

        } catch (\Throwable $th) {
            //throw $th;
            return response()->json(['status' => false , 'msg' =>$th->getMessage()]);
        }
    }

    /**
    * This function will be used to delete the location.
    *
    * @param  object $request   request data 
    * @return object            Json response from the server containing Tasks
    * @throws Exception         Any issues encountered
    */
    public function deleteLocation(Request $request) {

        try {

            $response = [];
            $idval = $request->idval;

            if ($idval == '') {
                $response['status'] = false;
                $response['msg'] = 'Id is required';
                return response()->json($response);
            }

            $UpdateRes = Location::where('id', $idval)->update([
                'deleted' =>'1',
            ]);

            if ($UpdateRes) {
                $response['status'] = true;
                $response['msg'] = 'Location has successfully deleted';
            } else {
                $response['status'] = false;
                $response['msg'] = 'something went wrong to perform the delete functionality';
            }

            return response()->json($response);

        } catch (\Throwable $th) {
            //throw $th;
            return response()->json(['status'=>false,'msg'=> $th->getMessage()]);
        }
    }

    /**
    * This function will be used to fetch the requied state based on id.
    *
    * @param  object $request   request data 
    * @return object            Json response from the server containing Tasks
    * @throws Exception         Any issues encountered
    */
    public function fetchState(Request $request) {

        try {

            $data['states'] = City::where("state_id", $request->state_id)->get(["name", "id"]);
            return response()->json($data);

        } catch (\Throwable $th) {
            //throw $th;
            return response()->json([]);
        }
       
    }
}