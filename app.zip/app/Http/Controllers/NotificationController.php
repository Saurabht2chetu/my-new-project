<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\NotificationTemplate;
use App\Http\Controllers\PatientController;
use App\Models\Appointment;
use Auth;
use DataTables;
use Validator;
use App\Models\Patient;
use App\Models\NotificationMessages;
use App\Models\Notifications;
use App\Models\ScrapModel;
use Carbon\Carbon;

/**
* This class is used to interact with the Notification Reminder Module
*
* PHP version 8.0.8
*
* @category  Supporting_Script
* @package   ExamineeList_Module
* @author    Chetu
* @copyright 2022 Chetu
*/
class NotificationController extends PatientController {
    
    /**
    * This function will be used to render the Notification template page.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function index(Request $request) {
      
        $action = 1;
        
        if ($request->ajax()) {

            $NoficationTemplateList = NotificationTemplate::where('deleted','0')->get();

            return  Datatables::of($NoficationTemplateList)
                        ->addIndexColumn()
                        ->addColumn('action', function($row) {
                            
                            if (Auth::user()->role_id == '2' || Auth::user()->role_id == '1') {

                                $btn = '<div class="db-action-box"><div class="edit-icon"><p class="template_editbtn" data-toggle="tooltip" data-placement="top" title="Edit" data-id="'.$row->id.'"><i class="far fa-edit"></i></p></div><div class="delete-icon"><p class="template_deletebtn" title="Delete" data-id="'.$row->id.'" data-action="0"><i class="fas fa-times"></i></p></div></div>';
                                
                            } else {

                                $btn = '<div class="db-action-box"><div class="edit-icon"><p class="access_denied" data-toggle="tooltip" data-placement="top" title="Edit"><i class="far fa-edit"></i></p></div></div>';
                            }

                            return $btn;

                        })->rawColumns(['action'])->make(true);
               
        }

        return view('notification.list');
    }

    /**
    * This function will be used to get template based on fields.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    protected function checkTemplate(array $dataField = array(),$Toarray = true) {
        
        try {
            return $Toarray ? NotificationTemplate::where($dataField)->get() : NotificationTemplate::where($dataField)->first();
            
        } catch (\Throwable $th) {
            //throw $th;
           return [];
        }
        
        
    }

    /**
    * This function will be used to add new Template.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function addNewTemplate(Request $request) {

        try {

            $validator = Validator::make($request->all(), [
                'title' => 'required',
                'template_message' => 'required'
            ]);
            
            $message = trim($request->template_message);
            $title  = trim($request->title);

            if($validator->fails()) {
    
                return response()->json(['status'=>false,'msg'=>$validator->errors()->first()]);
            }
    
            $checktemplate = $this->checkTemplate(['title'=>$title,'deleted'=>'0']);
    
            if (count($checktemplate) > 0) {
                
                return response()->json(['status'=>false,'msg'=>'This template is already exist']);

            } else {
                $saveRes = NotificationTemplate::create([
                   'title' => $title,
                   'message'=> $message
                ]);
    
                if ($saveRes) {
    
                    return response()->json(['status'=>true,'msg'=>'Template has successfully created']);
                }
    
                return response()->json(['status'=>false,'msg'=>$validator->errors()->first()]);
            }

        } catch (\Throwable $th) {
            //throw $th;
            return response()->json(['status'=>false,'msg'=>$th->getMessage()]);
        }

    }

    /**
    * This function will be used to get template for edit/update.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function getTemplate(Request $request) {
        
        try {

            $validator = Validator::make($request->all(), [
                'template_id' => 'required',
            ]);

            if ($validator->fails()) {
    
                return response()->json(['status'=>false,'data'=>[],'msg'=>$validator->errors()->first()]);
            }

            $gettemplate = $this->checkTemplate(['id'=> $request->template_id,'deleted'=> 0],false);
    
            if ($gettemplate) {
                
                return response()->json(['status'=>true,'data'=> $gettemplate,'msg'=>'Template has found successfully']);
            }

            return response()->json(['status'=>false,'data'=> [],'msg'=>'Template has not found']);
            

        } catch (\Throwable $th) {
            //throw $th;
            return response()->json(['status'=>false,'data' => [],'msg' => $th->getMessage()]);
        }
    } 

    /**
    * This function will be used to update template.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function updateTemplate(Request $request) {

        try {

            $validator = Validator::make($request->all(), [
                'template_id' => 'required',
                'title' => 'required',
                'template_message' => 'required'
            ]);

            $message = trim($request->template_message);
            $title  = trim($request->title);
    
            if($validator->fails()) {
    
                return response()->json(['status'=>false,'msg'=>$validator->errors()->first()]);
            }
    
            $checktemplate = NotificationTemplate::where(['title'=>$title,'deleted'=>'0'])->where('id','!=',$request->template_id)->first();
    
            if ($checktemplate) {
                
                return response()->json(['status'=>false,'msg'=>'This template is already exist']);

            } else {
                $saveRes = NotificationTemplate::where('id',$request->template_id)->update([
                   'title' => $title,
                   'message'=> $message
                ]);
    
                if ($saveRes) {
    
                    return response()->json(['status'=>true,'msg'=>'Template has successfully updated']);
                }
    
                return response()->json(['status'=>false,'msg'=>$validator->errors()->first()]);
            }

        } catch (\Throwable $th) {
            //throw $th;
            return response()->json(['status'=>false,'msg'=>$th->getMessage()]);
        }

    }

    /**
    * This function will be used to delete template.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function deleteTemplate(Request $request) {

        try {

            $validator = Validator::make($request->all(), [
                'template_id' => 'required',
            ]);
    
            if ($validator->fails()) {
    
                return response()->json(['status'=>false,'msg'=>$validator->errors()->first()]);
            }
    
            $checktemplate = $this->checkTemplate(['id'=> $request->template_id,'deleted'=> 0],false);
    
            if ($checktemplate) {
                
                $saveRes = NotificationTemplate::where('id',$request->template_id)->update([
                    'deleted' => 1,
                ]);

                if ($saveRes) {

                    return response()->json(['status'=>true,'msg'=>'Template has successfully deleted']);
                }

                return response()->json(['status'=>false,'msg'=>'something went wrong to update']);
            } 
    
            return response()->json(['status'=>false,'msg'=>'No Template Found']);
            

        } catch (\Throwable $th) {
            //throw $th;
            return response()->json(['status'=>false,'msg'=>$th->getMessage()]);
        }

    }

    /**
    * This function will be used to render the notification view page and fetch the requierd of notification page.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function appointmentReminder(Request $request) {

        if ($request->ajax()) {

            $NoficationTemplateList = Notifications::join('notification_template','notification_template.id','=','notifications.template_id')
            ->select('notifications.*','notification_template.title as template_name')
            ->orderBy('notifications.id','DESC')
            ->get();

            return  Datatables::of($NoficationTemplateList)
                        ->addIndexColumn()
                        ->addColumn('examinee_list', function($row) {
                            
                            $btn = '<a target="_blank" href="'.route('get.notification.examineeList',$row->id).'">view</a>';
                            return $btn;

                        })->addColumn('service_date', function($row) {
                            
                            return convertDate($row->service_date);

                        })->addColumn('date', function($row) {
                            
                            $date = date("m-d-Y h:i A",strtotime($row->created_at));
                            return $date;

                        })->addColumn('color_name', function($row) {
                            
                            if ($row->color_status == 0) {
                                $text = ' <label class="form-check-label font-weight-bold mt-1 ml-2" for=""><span class="color_designation" style="background:#96D35F!important;"></span></label>';                  
                            } else if ($row->color_status == 1) {
                                $text = ' <label class="form-check-label font-weight-bold mt-1 ml-2" for=""><span class="color_designation bg-danger" style="background:#FF2600!important;"></span></label>';
                            } else {
                                $text= ' <label class="form-check-label font-weight-bold mt-1 ml-2" for=""><span class="color_designation" style="background:#FFF76B!important;"></span></label>';
                            }
                            
                            return $text;
                            
                        })->rawColumns(['examinee_list','color_name'])->make(true);
               
        }

        $templateList = $this->checkTemplate(['deleted' => '0']);

        return view('notification.notification',['templateList'=>$templateList]);
    }

    /**
    * This function will be used to render the examinee list page whoose recieved the notification.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function appointmentExamineeList($notificationId) {

        return view('notification.examineeList',['notificationId' => $notificationId]);
    }

    /**
    * This function will be used to get appointment examinee list.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function getappointmentExamineeList(Request $request) {

        if ($request->ajax()) {

            $NoficationTemplateList = NotificationMessages::join('patients','patients.id','=','notification_messages.patient_id')->select('notification_messages.*','patients.first_name as patient_name','patients.phone as patient_phone')->where('notification_messages.notification_id',$request->notification_id)->get();

            return Datatables::of($NoficationTemplateList)
                    ->addIndexColumn()
                    ->addColumn('message_status', function($row) {
                        
                        if ($row->status == 0) {
                            $text = '<span class="badge badge-danger" title="'.$row->error_msg.'">Undelivered</span>';                  
                        } else {
                            $text = '<span class="badge badge-success" >Delivered</span>';  
                        }
                        return $text;
                        
                    })->addColumn('patient_phone', function($row) {
                        
                        return formatPhoneNumber($row->patient_phone);
                        
                    })->rawColumns(['message_status'])->make(true);
               
        }
        
    }

    /**
    * This function will be used to get all sent notification.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function getAllSentNotification(Request $request)  {

        $response = [
            'data' => [],
            'draw' => 0,
            'input' =>[],
            'recordsFiltered' => 0,
            'recordsTotal' => 0
        ];

        return response()->json($response);
    }

    /**
    * This function will be used to send notification.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function sendNotification(Request $request) {
        // return $request->all();
        
        $validator = Validator::make($request->all(), [
            'service_date' => 'required',
            'clinic_list' => 'required',
            'color_type' => 'required',
            'template_name' => 'required'
        ]);
        
        if($validator->fails()) {

            return response()->json(['status'=>false,'msg'=>$validator->errors()->first()]);
        }

        $date = convertDateIst($request->service_date);

        $appointmentList = Appointment::join('patients','patients.id','=','appointments.patient_id')
        ->select('appointments.*','patients.phone')
        ->where('appointments.deleted','=','0')
        ->where('patients.phone','!=',null)
        ->where('patients.phone','!=','')
        ->where('appointments.status','!=',$_ENV['APPT_STATUS_CANCEL'])
        ->where('appointments.service_date',$date)
        ->whereIn('appointments.location_id',$request->clinic_list)
        ->groupBy('appointments.patient_id')
        ->orderBy('appointments.service_date','DESC')
        ->get();
      
       
        if (count($appointmentList) > 0) {
            
            // \Log::info('appointment list has found sucessfully under the send notification');
            \Log::info('appointment list data-'.json_encode($appointmentList));
            
            $templateList = $this->checkTemplate(['id'=> $request->template_name],false);

            if ($templateList) {

                // \Log::info('Template list has found sucessfully under the send notification');

                $MessageTemplate = $templateList->message;
                
                \Log::info('Template Message -'.$MessageTemplate);
                
                $sendStatus = false;

                $saveNotification = Notifications::create([
                    'service_date'=> $date,
                    'template_id'=> $request->template_name,
                    'color_status'=> $request->color_type,
                    'created_at'=> Carbon::now()
                ]);
                
                if ($saveNotification) {
                    
                    // \Log::info('notification list data has saved into notification table under the send notification');

                    foreach ($appointmentList as $appointList) {
                        
                        $data1=[];
                        $data1['day'] = date("l",strtotime($appointList->service_date)); 
                        $data1['date'] = date("m-d-Y",strtotime($appointList->service_date)); 
                        $data1['time'] = date("h:i A",strtotime($appointList->service_time));
                        $createMessageTemplate = $this->createMessageTemplate($MessageTemplate,$data1);

                        if ($createMessageTemplate != '') {
                        
                            $data = [
                                'notification_id'=>$saveNotification->id,
                                'patient_id'=>$appointList->patient_id,
                                'message'=>$createMessageTemplate
                            ];

                            try {
                            
                                $saveTemplateRes = $this->saveNotificationMessages($data);
                        
                                if ($saveTemplateRes) {
                                
                                    $response = $this->sendMessageByTwilio($appointList->phone,$createMessageTemplate);
                                    
                                    $sendStatus = true;

                                    if(is_array($response) && $response['status']) {
    
                                        $this->updateNotificationMessages($saveTemplateRes->id,['status' =>1,'error_msg' => $response['msg']]);
                                        
                                    } else {
                                        $this->updateNotificationMessages($saveTemplateRes->id,['error_msg' => $response['msg']]);
                                    }
                                }

                            } catch (\Throwable $th) {
                                //throw $th;
                                echo $th->getMessage()."line".$th->getLine();
                                
                            }
                        }
                        
                    }

                    if ($sendStatus) {
                        // \Log::info('notification has sent successfully to examinee mobile');
                        return redirect()->back()->with('status','Notification has sent successfully');
                    } 
                    // \Log::info('Something went wrong to send notification');
                    return redirect()->back()->with('status','Something went wrong to send notification');   
                }
                return redirect()->back()->with('status','Notication has not saved');
            } 
            return redirect()->back()->with('status','Template has not found');    
        } 
        return redirect()->back()->with('status','No records found, check reason:-(Examinee phone might be null)');
        
    }

    /**
    * This function will be used to create message template.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    protected function createMessageTemplate(string $message,array $data = []) {

        //for replace the day
        $templatemessage = "";
        $templatemessage = str_replace([strtolower('{day}'),strtoupper('{day}'),'{Day}','{dAy}','{daY}'],$data['day'],$message);
        
        //for date
        $templatemessage = str_replace([strtolower('{Date}'),strtoupper('{Date}'),'{Date}','{dAte}','{daTe}','{datE}'],$data['date'],$templatemessage);

        //for time
        $templatemessage = str_replace([strtolower('{Time}'),strtoupper('{Time}'),'{Time}','{tIme}','{tiMe}','{timE}'],$data['time'],$templatemessage);
        
        return $templatemessage;

    }

    /**
    * This function will be used to get appointlist based on service date.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function getColorsByServiceDate(Request $request) {
        
        $checkCaseId = $this->getAppointmentByField(['service_date'=>$request->add_case_id]);
    }

    /**
    * This function will be used to save notification Messages.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    protected function saveNotificationMessages(array $data) {
        
        return NotificationMessages::create([
            'notification_id' => $data['notification_id'],
            'patient_id'=> $data['patient_id'],
            'message'=>$data['message'],
            'created_at'=> Carbon::now(),
        ]);
    }

    /**
    * This function will be used to update notification Messages.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    protected function updateNotificationMessages(int $id,array $data) {
        
        $data['updated_at'] = Carbon::now();
        return NotificationMessages::where('id',$id)->update($data);
    }

    /**
    * This function will be used to send message using twilio.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function sendMessageByTwilio($mob_number,$body) {

        try {

            // return ['status'=>true,'msg'=>'sms has sent successfully'];

            $id = $_ENV['twilio_sid'];
            $token = $_ENV['twilio_auth_token'];
            $url = "https://api.twilio.com/2010-04-01/Accounts/$id/Messages.json";
            // $url = "https://api.twilio.com/2010-04-01/Accounts/$id/SMS/Messages";
            $from = $_ENV['twilio_messagingService_id'];
            $to = "+1".$mob_number; // twilio trial verified number
            $data = array (
                'MessagingServiceSid' => $from,
                'To' => $to,
                'Body' => $body,
            );
            $post = http_build_query($data);
            $x = curl_init($url );
            curl_setopt($x, CURLOPT_POST, true);
            curl_setopt($x, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($x, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($x, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            curl_setopt($x, CURLOPT_USERPWD, "$id:$token");
            curl_setopt($x, CURLOPT_POSTFIELDS, $post);
            $response = curl_exec($x);
            $result = json_decode($response);
            if (isset($result->status) && $result->status == 'accepted') {
                return ['status'=>true,'msg'=>'Message has successfully sent to examinee'];
            } else if(isset($result->code) && isset($result->message)) {
                return ['status'=>false,'msg'=>$result->message];
            } else {
                throw new \Exception('something went to send message');
            }
            curl_close($x);
            
        } catch (\Throwable $th) {
            //throw $th;
            return ['status'=>false,'msg'=>$th->getMessage()];
        }
    }

    /**
    * This function will be used to send message using twilio for testing purpose.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function sendMessageByTwilioTesting() {

        try {

            $id = $_ENV['twilio_sid'];
            $token = $_ENV['twilio_auth_token'];
            $url = "https://api.twilio.com/2010-04-01/Accounts/$id/Messages.json";
            // $url = "https://api.twilio.com/2010-04-01/Accounts/$id/SMS/Messages";
            $from = $_ENV['twilio_messagingService_id'];
            $to = "+916376683122"; // twilio trial verified number
            $body = "Hello user ,i am moonlightexams";
            $data = array (
                'MessagingServiceSid' => $from,
                'To' => $to,
                'Body' => $body,
            );
            $post = http_build_query($data);
            $x = curl_init($url );
            curl_setopt($x, CURLOPT_POST, true);
            curl_setopt($x, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($x, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($x, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            curl_setopt($x, CURLOPT_USERPWD, "$id:$token");
            curl_setopt($x, CURLOPT_POSTFIELDS, $post);
            $response = curl_exec($x);
            $result = json_decode($response);
            if (isset($result->status) && $result->status == 'accepted') {
                // return true;
                echo "Message has successfully sent to examinee";
            } else if(isset($result->code) && isset($result->message)) {
                echo $result->message;
                return false;
            } else {
                throw new \Exception('something went to send message');
            }
            curl_close($x);
            
        } catch (\Throwable $th) {
            //throw $th;
            echo $th->getMessage();
        }
    }

    public function getClinicsByServiceDate(Request $request) {
        
        try {

            $validator = Validator::make($request->all(), [
                'serviceDate' => 'required',
                'colorType' => 'required'
            ]);

            if ($validator->fails()) {
    
                return response()->json(['status'=>false,'data'=>[],'msg'=>$validator->errors()->first()]);
            }

            $clinicsByServiceDate = getClinicByServiceDate($request->serviceDate,$request->colorType);

            if ($clinicsByServiceDate) {
                return response()->json(['status'=>true, 'data'=> $clinicsByServiceDate, 'msg'=>'Clinics found']);
            }

            return response()->json(['status'=>false, 'data'=> [], 'msg'=>'No clinic found']);
            
        } catch (\Throwable $th) {
            return response()->json(['status'=>false, 'data' => [], 'msg' => $th->getMessage()]);
        }
    }

    public function getNotificationTemplate(Request $request)
    {   
        $notificationMsg = NotificationTemplate::where('id', $request->template_id)->first();
        $createMessageTemplate='';
        $date = convertDateIst($request->service_date);
        $dynamicData=[];
        $dynamicData['day'] = date("l",strtotime($date)); 
        $dynamicData['date'] = date("m-d-Y",strtotime($date)); 
        $dynamicData['time'] = "{Time}";
        $createMessageTemplate = $this->createMessageTemplate($notificationMsg,$dynamicData);

        return response()->json(['status'=>true, 'data'=> $createMessageTemplate]);
    }
}
