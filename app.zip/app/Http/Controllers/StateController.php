<?php

namespace App\Http\Controllers;

use App\Models\States;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon; 
use DataTables;
use Validator;

/**
 * This class is used to interact with the State ERE Management Module
 *
 * PHP version 8.0.8
 *
 * @category  Supporting Script
 * @package   State ERE Management Module
 * @author    Chetu
 * @copyright 2021 Chetu
 */

class StateController extends Controller
{
    /**
     * This method is used to show listing of states data
     *
     * @param  Illuminate\Http\Request $request
     */
    public function index(Request $request) {
        
        //call helper for check the permission for user role.
        $action = checkPermission($request->path());

        if ($request->ajax()) {
            
            $data = States::select('*')->orderBy('id','Desc')->get();
        
            return DataTables::of($data)
                    ->addIndexColumn()
                    ->addColumn('action', function($row) use($action){
                        if ($action == 1) {
                            $btn = '<div class="db-action-box"><div class="edit-icon"><p class="editbtn" data-toggle="tooltip" data-placement="top" title="Edit" data-id="'.$row->id.'"><i class="far fa-edit"></i></p></div>';
                        } else {
                            $btn = '<div class="db-action-box"><div class="edit-icon"><p class="access_denied"  data-toggle="tooltip" data-placement="top" title="Edit" ><i class="far fa-edit"></i></p></div></div>'; 
                        }
                        return $btn;
                    })->addColumn('activeInactive', function($row) use ($action){

                        if($action) {
                            if($row->active) {
                                $btn1 = '<div class="activesection"><input type="checkbox" class="inputcheck" id="switch_'.$row->id.'" value="0" data-id="'.$row->id.'" checked /><label title="Deactivate" for="switch_'.$row->id.'">Toggle</label></div>';
                            } else {
                                $btn1 = '<div class="activesection"><input type="checkbox" class="inputcheck" id="switch_'.$row->id.'" value="1" data-id="'.$row->id.'" /><label title="Activate" for="switch_'.$row->id.'">Toggle</label></div>';
                            }
                        } else {
                            if ($row->active) {
                                $btn1 = '<div class="activesection"><input type="checkbox" class="access_denied" id="switch_'.$row->id.'"  checked /><label for="switch_'.$row->id.'">Toggle</label></div>';
                            } else {
                                $btn1 = '<div class="activesection"><input type="checkbox" class="access_denied" id="switch_'.$row->id.'"  /><label for="switch_'.$row->id.'">Toggle</label></div>';
                            }
                        }
                        
                        return $btn1;
                    })->rawColumns(['action','activeInactive'])->make(true);
        }
           
        return view('states.list',['action'=>$action]);
    }

    /**
     * This method is used to add a State
     *
     * @param  Illuminate\Http\Request $request
     */
    public function addState(Request $request) {

        $validator = Validator::make($request->all(), [
            'stateName' => 'required',
            'stateCode' => 'required'
        ]);

        if ($validator->passes()) {
            
            $checkState = States::where(['name'=>$request->stateName])->orWhere(['code'=>$request->stateCode])->first();

            if ($checkState) {
                return response()->json(['status'=>false,'msg'=>'ERE State already exists']);
            }
        
            if ($request->userName != '' && $request->password != '') {
                $password = Crypt::encryptString($request->password);
            } else {
                $password = ''; 
            }

            if ($request->invoiceExtraction != '') {
                $request->invoiceExtraction = str_replace(' ', '', $request->invoiceExtraction);
            }
            
            States::create([
                'name' => $request->stateName, 
                'code' => $request->stateCode,
                'invoice_extraction' => $request->invoiceExtraction,
                'user_name' => $request->userName,
                'user_password' => $password,
                'created_at' => Carbon::now()
            ]);

            return response()->json(['status'=>true,'msg'=>'ERE State created successfully']);
        }

        return response()->json(['status'=>false,'msg'=>$validator->errors()->first()]);

    }

    /**
     * This method is used to edit a State
     *
     * @param  Illuminate\Http\Request $request
     */
    public function editState(Request $request) {
        $stateDetails = States::where('id', $request->id)->first();
        if ($stateDetails) {
            if($stateDetails->user_password != '') {
                $stateDetails->user_password = Crypt::decryptString($stateDetails->user_password);
            }
            return response()->json(['status'=>true, 'data'=>$stateDetails, 'msg'=>'ERE State details found successfully']);
        }
        return response()->json(['status'=>false, 'data'=>[], 'msg'=>'ERE State does not found']);
    }
    
    /**
     * This method is used to update a State Data
     *
     * @param  Illuminate\Http\Request $request
     */
    public function updateState(Request $request) {
        
        $validator = Validator::make($request->all(), [
            'idval'=>'required',
            'stateName' => 'required',
            'stateCode' => 'required'
        ]);

        if ($validator->passes()) {

            $checkState = States::where('id', '!=', $request->idval)
                ->Where(function ($query) use ($request) {
                    $query->where(['name'=>$request->stateName])
                          ->orwhere(['code'=>$request->stateCode]);
                })->first();

            if ($checkState) {
                return response()->json(['status'=>false,'msg'=>'ERE State already exists']);
            }
        
            if ($request->userName != '' && $request->password != '') {
                $password = Crypt::encryptString($request->password);
            } else {
                $password = ''; 
            }

            if ($request->invoiceExtraction != '') {
                $request->invoiceExtraction = str_replace(' ', '', $request->invoiceExtraction);
            }

            $updateState = States::where('id', $request->idval)->update([
                'name' => $request->stateName, 
                'code' => $request->stateCode,
                'invoice_extraction' => $request->invoiceExtraction,
                'user_name' => $request->userName,
                'user_password' => $password,
                'updated_at' => Carbon::now()
            ]);

            if ($updateState) {
                return response()->json(['status'=>true, 'msg'=>'ERE State updated successfully']);
            } else {
                return response()->json(['status'=>false, 'msg'=>'Something went wrong!']);
            } 
            
        }

        return response()->json(['status'=>false, 'msg'=>$validator->errors()->first()]);

    }

    /**
     * This method is used to activate/deactivate State Data
     *
     * @param  Illuminate\Http\Request $request
     */
    public function updateStatus(Request $request){

        $validator = Validator::make($request->all(), [
            'idval'=>'required',
            'status' => 'required'
        ]);
        
        if ($validator->passes()) {
        
            $udpateRes = States::where('id',$request->idval)->update([
                'active' => $request->status,
                'updated_at' => Carbon::now()
            ]);
        
            if ($udpateRes) {
                return response()->json(['status'=>true,'msg'=>'Status changed successfully']);
            } else {
                return response()->json(['status'=>false,'msg'=>'Something went wrong.']);
            }
        }
        
        return response()->json(['status'=>false,'msg'=>$validator->errors()->first()]);
        
    }

    /**
     * This method is used to Delete a State
     *
     * @param  Illuminate\Http\Request $request
     */
    public function deleteState(Request $request){

        $validator = Validator::make($request->all(), [
            'idval'=>'required',
        ]);
        
        if ($validator->passes()) {
        
            $udpateRes = States::where('id',$request->idval)->delete();
        
            if ($udpateRes) {
                return response()->json(['status'=>true,'msg'=>'ERE State has been deleted successfully']);
            } else {
                return response()->json(['status'=>false,'msg'=>'Something went wrong.']);
            }
        }
        
        return response()->json(['status'=>false,'msg'=>$validator->errors()->first()]);
        
    }
}
