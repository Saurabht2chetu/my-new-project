<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Roles;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon; 
use DataTables;
use Validator;
use Storage;
use Mail;


/**
* This class is used to interact with the User Management Module
*
* PHP version 8.0.8
*
* @category  Supporting_Script
* @package   User_Management_Module
* @author    Chetu
* @copyright 2021 Chetu
*/
class UserController extends Controller {

    /**
    * This function will be used to render the user blade page and fetch the required data for list page.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function index(Request $request) {
        //call helper for check the permission for user role.
        $action = checkPermission($request->path());

        $RoleList = Roles::where('id', '!=', $_ENV['SUPERADMIN_ROLE_ID'])
            ->where('id', '!=', $_ENV['HEADQUARTER_ROLE_ID'])
            ->get();
         
        if ($request->ajax()) {

            $data = User::leftjoin('roles', 'roles.id', '=', 'users.role_id')
                ->where('users.role_id', '!=', $_ENV['SUPERADMIN_ROLE_ID'])
                ->where('users.role_id', '!=', $_ENV['HEADQUARTER_ROLE_ID'])
                ->where('users.deleted', '0')
                ->orderByDesc('users.id')
                ->select('users.*', 'roles.name as role_name')
                ->get();
        
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($row) use ($action) {
                    if ($action == 1) {
                        $btn = '<div class="db-action-box"><div class="edit-icon"><p class="editbtn" data-toggle="tooltip" data-placement="top" title="Edit" data-id="'.$row->id.'"><i class="far fa-edit"></i></p></div>';
                        
                        if ($row->email != '') {
                            
                            $btn.= '<div class="edit-icon"><p class="changepass"  title="Change Password" data-id="'.$row->id.'"><i class="fas fa-user-edit"></i></p></div>'; 
                        }

                        if ($row->signature != '') {
                            
                            $btn.= '<div class="edit-icon"><p class="downloadsignature" title="Download Examiner Signature" data-id="'.$row->id.'" data-status="'.$row->signature.'"><i class="fa fa-download" aria-hidden="true"></i></p></div>'; 
                        }

                        $btn.= '<div class="delete-icon"><p class="deletebtn" title="Delete" data-id="'.$row->id.'"><i class="fas fa-times"></i></p></div>'; 
                    } else {
                        $btn = '<div class="db-action-box"><div class="edit-icon"><p class="access_denied" data-toggle="tooltip" data-placement="top" title="Edit" ><i class="far fa-edit"></i></p></div><div class="edit-icon"><p class="access_denied" " title="Change Password" data-id="'.$row->id.'"><i class="fas fa-user-edit"></i></p></div><div class="delete-icon"><p class="access_denied" title="Delete" ><i class="fas fa-times"></i></p></div>'; 
                    }
                    return $btn;
                })->addColumn('firstname', function ($row) {
    
                    $btn = explode(' ', trim($row->name));;

                    return $btn[0];
                })->addColumn('lastname', function ($row) {
    
                    return trim(strstr($row->name, " "));

                })
                ->rawColumns(['action', 'firstname', 'lastname'])
                ->make(true);
        }

        return view('users.list', compact('RoleList', 'action'));
    }

    protected function checkUser(array $datafield = []) {

        if (empty($datafield)) {

            return false;
        }

        try {
            return User::where(['email'=>$datafield['email'], 'role_id'=>$datafield['role_id'],'deleted'=>'0'])->first();
        } catch (\Throwable $th) {
            return false;
        }
      
    } 

    /**
    * This function will be used to add user.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function addUser(Request $request) {

        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'user_role' =>'required',
            'password' => 'required|string|min:8|confirmed',
            'password_confirmation' => 'required'
        ]);

        if ($validator->passes()) {

            if ($request->user_role == $_ENV['SUPERADMIN_ROLE_ID'] || $request->user_role == $_ENV['HEADQUARTER_ROLE_ID']) {
                return response()->json(['status'=>false, 'msg'=>'something went wrong!']);
            }

            try {

                $name = $request->firstName.' '.$request->lastName;  

                $checkeEmail = User::where(['email'=>$request->email, 'role_id'=>$request->user_role])->first();
    
                if ($checkeEmail) {
                    return response()->json(['status'=>false, 'msg'=>'User Email Id already exists']);
                }
    
                /* Below Code commented because we are removing User Id concept
                $checkUserId = User::where(['user_id'=>$request->userId, 'role_id'=>$request->user_role, 'deleted'=>'0'])->first();
    
                if ($checkUserId) {
                    return response()->json(['status'=>false, 'msg'=>'User User Id already exists']);
                }
                */
                if ($request->user_role != $_ENV['SUPERADMIN_ROLE_ID'] && $request->user_role != $_ENV['HEADQUARTER_ROLE_ID']) {

                    $createUser = User::create([
                        'name' => $name, 
                        'email' => $request->email,
                        'user_id' => $request->email,
                        'password' => Hash::make($request['password']),
                        'role_id' => $request->user_role,
                        'created_at' => Carbon::now()
                    ]);
        
                    if ($createUser) {

                        $roleInfo = Roles::where('id', '=', $request->user_role)->first();

                        $userRole = $roleInfo->name;

                        try {
                            Mail::send('emails.welcomeUserEmail', ['name' => $name, 'email' => $request->email, 'password' => $request->password, 'userRole' => $userRole], function($message) use($userRole,$request){
                                $message->to($request->email);
                                $message->subject('Your account has been created with MoonlightExaminations as '.$userRole);
                            });
                        } catch(\Exception $e) {
                            \Log::info($e->getMessage());
                            return back()->with('error', 'Something went wrong!');
                        }

                        return response()->json(['status'=>true, 'msg'=>'User has successfully created']);
                    }
                } 
                return response()->json(['status'=>false, 'msg'=>'something went wrong to add user']);
            } catch (\Throwable $th) {
                return response()->json(['status'=>false, 'msg'=>$th->getMessage()]);
            }
            
        }

        return response()->json(['status'=>false, 'msg'=>$validator->errors()->first()]);
    }
    public function addUserbackup(Request $request) {

        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'user_role' =>'required',
            'password' => 'required|string|min:8|confirmed',
            'password_confirmation' => 'required'
        ]);

        if ($validator->passes()) {

            try {

                $name = $request->firstName.' '.$request->lastName;  

                $checkeEmail = User::where(['email'=>$request->email, 'role_id'=>$request->user_role])->first();
    
                if ($checkeEmail) {
                    return response()->json(['status'=>false, 'msg'=>'User Email Id already exists']);
                }
    
                /* Below Code commented because we are removing User Id concept
                $checkUserId = User::where(['user_id'=>$request->userId, 'role_id'=>$request->user_role, 'deleted'=>'0'])->first();
    
                if ($checkUserId) {
                    return response()->json(['status'=>false, 'msg'=>'User User Id already exists']);
                }
                */
                $createUser = User::create([
                    'name' => $name, 
                    'email' => $request->email,
                    'user_id' => $request->email,
                    'password' => Hash::make($request['password']),
                    'role_id' => $request->user_role,
                    'created_at' => Carbon::now()
                ]);
    
                if ($createUser) {

                    $roleInfo = Roles::where('id', '=', $request->user_role)->first();

                    $userRole = $roleInfo->name;

                    try {
                        Mail::send('emails.welcomeUserEmail', ['name' => $name, 'email' => $request->email, 'password' => $request->password, 'userRole' => $userRole], function($message) use($userRole,$request){
                            $message->to($request->email);
                            $message->subject('Your account has been created with MoonlightExaminations as '.$userRole);
                        });
                    } catch(\Exception $e) {
                        \Log::info($e->getMessage());
                        return back()->with('error', 'Something went wrong!');
                    }

                    return response()->json(['status'=>true, 'msg'=>'User has successfully created']);
                } 
                return response()->json(['status'=>false, 'msg'=>'something went wrong to add user']);
            } catch (\Throwable $th) {
                return response()->json(['status'=>false, 'msg'=>$th->getMessage()]);
            }
            
        }

        return response()->json(['status'=>false, 'msg'=>$validator->errors()->first()]);
    }

    
    /**
    * This function will be used to update the user.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function updateUser(Request $request) {
        
        $response = [];
        $idval = $request->idval;

        if ($idval == '') {
            $response['status'] = false;
            $response['msg'] = 'Id is required';
            return response()->json($response);
        }

        $getEmail = User::where(['id'=>$idval])->first();

        if (!$getEmail) {
            return response()->json(['status'=>false, 'msg'=>'User does not found']);
        }

        try {

            if ($request->user_role == $_ENV['SUPERADMIN_ROLE_ID'] || $request->user_role == $_ENV['HEADQUARTER_ROLE_ID']) {
                return response()->json(['status'=>false, 'msg'=>'something went wrong!']);
            }
            
            if (($getEmail->email == '') && isset($request->email) && ($request->email != '')) {
                $checkeEmail = User::where(['email'=>$request->email, 'role_id'=>$request->user_role])->first();

                if ($checkeEmail) {
                    return response()->json(['status'=>false, 'msg'=>'User Email Id already exists']);
                }
            }

            $updateUser = User::where('id', $idval)->update([
                'name' => $request->firstName." ".$request->lastName,
                'role_id'=>$request->user_role
            ]);

            if (($getEmail->email == '') && isset($request->email) && ($request->email != '')) {
                $updateUser = User::where('id', $idval)->update(['email' => $request->email]);
            }

            if ($updateUser) {
                $response['status'] = true;
                $response['msg'] = 'User has successfully updated';
            } else {
                $response['status'] = false;
                $response['msg'] = 'something went wrong to update user';
            }

            return response()->json($response);
        } catch (\Throwable $th) {
            $response['status'] = false;
            $response['msg'] = $th->getMessage();
            return response()->json($response);
        }
    }

    /**
    * This function will be used to delete the user.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function deleteUser(Request $request) {

        $response = [];
        $idval = $request->idval;

        if ($idval == '') {
            $response['status'] = false;
            $response['msg'] = 'Id is required';
            return response()->json($response);
        }

        try {
            //code...
        
            $UpdateRes = User::where('id', $idval)->update([
                'deleted' =>'1',
            ]);

            if ($UpdateRes) {
                $response['status'] = true;
                $response['msg'] = 'User has successfully deleted';
            } else {
                $response['status'] = false;
                $response['msg'] = 'something went wrong to delete';
            }
            return response()->json($response);
        } catch (\Throwable $th) {
            $response['status'] = false;
            $response['msg'] = $th->getMessage();
            return response()->json($response);
        }
    }

    /**
    * This function will be used to update user password.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function updateUserPassword(Request $request) {
       
        $response = [];
        $validator = Validator::make($request->all(), [
            'idval' => ['required'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            // 'password_confirmation' => 'required'
        ]);

        if ($validator->passes()) {

            $UpdateRes = User::where('id', $request->idval)->update([
                'password' =>Hash::make(trim($request->password)),
                'updated_at'=>Carbon::now()
            ]);

            if ($UpdateRes) {
                $response['status'] = true;
                $response['msg'] = 'User Password has successfully updated';
            } else {
                $response['status'] = false;
                $response['msg'] = 'something went wrong to delete';
            }
        } else {
            $response['status'] = false;
            $response['msg'] = $validator->errors()->first();
        }      
        
        return response()->json($response);
    }

    /**
    * This function will be used to fetch user data for edit/update.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function editUser(Request $request) {
        
        $user = User::where('id', $request->id)->first();
        if ($user) {
            return response()->json(['status'=>true, 'data'=>$user, 'msg'=>'record found successfully']);
        }
        return response()->json(['status'=>false, 'data'=>[], 'msg'=>'User does not found']);
    }

    /**
    * This function will be used to download examiner signature.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function downloadExaminerSignature(Request $request) {

        $validator = Validator::make($request->all(), [
            'user_id' => ['required']
        ]);

        if ($validator->fails()) {

            return redirect()->back()->with('status',$validator->errors()->first());
        }

        $user = User::where('id', $request->user_id)->where('signature','!=',null)->first();

        if ($user) {

            try {
                
                $path = $user->signature; //'examiner_signature/signature_5.pdf';
                
                if( Storage::disk('signatures3')->exists($path)) {
                    
                    $file = Storage::disk('signatures3')->get($path);
                    $mimeType = Storage::disk('signatures3')->getDriver()->getMimetype($path); 
                    $mimeSize = Storage::disk('signatures3')->getDriver()->getSize($path);
                    
                    $fileName = str_replace([" ","_"],"-",$user->name."_".basename($path));

                    $headers = [
                    'Content-Type' => $mimeType, 
                    'Content-Description' => 'File Transfer',
                    "Content-Length" => $mimeSize,
                    'Content-Disposition' => "attachment; filename=".$fileName
                    ];
            
                    return response($file, 200, $headers);
                }

                return redirect()->back()->with('status','file has not found');
            } catch (\Throwable $th) {
                //throw $th;
                return redirect()->back()->with('status',$th->getMessage());
            }
        }

    }

    public function testUrl() {

        $path = 'invoice/invoice-file-136.pdf';

        if (Storage::disk('signatures3')->exists($path)) {

            echo "file found";
        } else {
            echo "file ios  found";
        }
    }

    public function testing() {

        $mergeFileNameArray = [];
        $mergeFileNameArray[] = '/opt/lampp/htdocs/moonlightexaminations/gsfolder/STANLEY-LAGOD-5745-invoice-details.pdf';
        $mergeFileNameArray[] = '/opt/lampp/htdocs/moonlightexaminations/gsfolder/ARLENE-POPE-6132-invoice-details.pdf';
        $mergeFileNameArray[] = '/opt/lampp/htdocs/moonlightexaminations/gsfolder/DAVID-ONEEL-6158-invoice-details.pdf';
            

        $fileNames = implode(" ", $mergeFileNameArray);
        $downloadFileName = 'gs_test.pdf';
        // $saveFile = base_path()."/gsfolder/".$downloadFileName;
        $saveFile = public_path()."/".$downloadFileName;
        $mergerFileRes = $this->mergerPdfFile($fileNames,$saveFile);
        \Log::info('Test Merge File Response-'.$mergerFileRes);

        return response()->download($saveFile, $downloadFileName);
    }

    public function mergerPdfFile($fileArray,$outputFileName) {

        try {
            
            //Create the GhostScript command for extract the particular pages from pdf
            $gsCmd = 'gs -dBATCH -dNOPAUSE -q -sDEVICE=pdfwrite -sOutputFile='.$outputFileName.' '.$fileArray.'';

            \Log::debug('ghostscript merger command'.$gsCmd);

            // return $gsCmd;
            //Run it using PHP's exec function.
            $output = array();
            $return = null;
            $cmd = exec($gsCmd,$output,$return);

            if ($return != 0) {
                \Log::debug('under the failed file merge response');
                return false;
            } else {
                \Log::debug('under the success file merge response');
                return $cmd;
            }

        } catch (\Exception $e) {
            echo "under the merge pdf function-".$e->getMessage();
            return false;
        }
    }
}
