<?php
 
namespace App\Http\Controllers;
 
use Illuminate\Http\Request;
use App\Models\File;
use Webklex\PDFMerger\Facades\PDFMergerFacade as PDFMerger;

class PdfController extends Controller
{
     
    public function merge($filename)
    {

        $oMerger = PDFMerger::init();
        //Pass the page numbers as an array. Here 2 and 4 are passed.
        $oMerger->addPDF(public_path().'/'.$filename, [1,3]);
        //To merge the pages having the page numbers passed in the array.
        $oMerger->merge();
        //To save the pdf. 
        /***** This pdf will be created in the same directory where the orignal PDF is there*****/ 
        $oMerger->save('invoice.pdf');

        echo 'Page extracted successsfully';
        
    }
}
