<?php 
  
namespace App\Http\Controllers; 
  
use App\Http\Controllers\Controller;
use Illuminate\Http\Request; 
use Illuminate\Support\Facades\Auth;
use DB;
use Mail;  
use Hash;
use Carbon\Carbon; 
use App\Services\PayUService\Exception;
use App\Models\Roles;
use App\Models\User;
use Validator;  
use Storage;

/**
* This class is used to interact with the User profile Module
*
* PHP version 8.0.8
*
* @category  Supporting_Script
* @package   ExamineeList_Module
* @author    Chetu
* @copyright 2022 Chetu
*/
class ProfileController extends Controller {    
    
    /**
    * This function will be used to render the change password view.
    *
    * @return object         html page 
    */
    public function showChangePasswordForm() {

        $roles = Roles::find(Auth::user()->role_id);

        return view('profile.changePassword', ['role'=>$roles]);
    }

    /**
    * This function will be used to change user password .
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function submitChangePasswordForm_backup(Request $request) {

        $AuthData = Auth::user();  //Possible exception is User not found or returning null when accessing $request->password

        $request->validate([
            'password' => 'required|string|min:8|regex:/[A-Z]/|regex:/[0-9]/|regex:/[@$!%*#?&]/|confirmed',
            'password_confirmation' => 'required'
        ]);

        try {
            DB::table('users')
            ->where([
            ['email', '=', $AuthData->email],
            ['role_id', '=', $AuthData->role_id],
            ])
            ->update([
                'password' => Hash::make($request->password),  
                'updated_at' => Carbon::now()
            ]);

        
            Mail::send('emails.changePassword', ['name' => $AuthData->name], function($message) use($AuthData){

            $message->to($AuthData->email);
            $message->subject('Password changed successfully');
            });
        } catch(\Exception $e) {
            \Log::info($e->getMessage());
            return back()->with('error', 'Something went wrong with email SMTP details');
        }

        return redirect('/change-password')->with('status', 'Your Password has been updated!');
        
    }

    /**
    * This function will be used to change user password .
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function submitChangePasswordForm(Request $request) {

        //Possible exception is User not found or returning null when accessing $request->password
        $AuthData = Auth::user();
        
        $request->validate([
            'password' => 'required|string|min:8|regex:/[A-Z]/|regex:/[0-9]/|regex:/[@$!%*#?&]/|confirmed',
            'password_confirmation' => 'required',
            'oldPassword' => 'required'
        ]);

        try {

            $checkOldPassword = DB::table('users')->where('id', $AuthData->id)->first();

            if (!$checkOldPassword) {
                return response()->json(['status'=>false,'msg'=>'something went wrong, please try again later!']);
            }
            if (!Hash::check($request->oldPassword, $checkOldPassword->password)) {
                return response()->json(['status'=>false,'msg'=>'Incorrect old password!']);
            }

            Auth::logoutOtherDevices($request->oldPassword);
            DB::table('users')->where([
                ['email', '=', $AuthData->email],
                ['role_id', '=', $AuthData->role_id],
            ])->update([
                'password' => Hash::make($request->password),  
                'updated_at' => Carbon::now()
            ]);
            // Mail::send('emails.changePassword', ['name' => $AuthData->name], function($message) use($AuthData) {

            //     $message->to($AuthData->email);
            //     $message->subject('Password changed successfully');
            // });

           //  Auth::logoutOtherDevices($request->oldPassword);

        } catch(\Exception $e) {
            \Log::info($e->getMessage());
            return response()->json(['status'=>false,'msg'=>'Something went wrong with email SMTP details']);
        }

        return response()->json(['status'=>true,'msg'=>'Your Password has been updated!']);
    }
    
    /**
    * This function will be used to render the upload signature view for examiner.
    *
    * @return response         html page 
    */
    public function examinerSignature() {

        $userList = User::where('id' ,Auth::user()->id)->where('signature', '!=',null)->first();

        $path = '';
        if ($userList) {

            $path = Storage::disk('signatures3')->url($userList->signature);
        }

        return view('profile.signature', ['path'=>$path]);
    }

    /**
    * This function will be used to upload examiner signature.
    *
    * @param  object $request  request data 
    * @return object         Json response from the server containing Tasks
    * @throws Exception      Any issues encountered
    */
    public function uploadSignature(Request $request) {
        
        // $validator = Validator::make($request->all(), [
        //     'signature' => 'required|mimes:jpg,jpeg,png,bmp,pdf,doc,docx|max:15000',
        //     'authorize' => 'required'
        // ]);
        
        // if ($validator->fails()) {

        //     return response()->json(['status'=>false,'msg'=>$validator->errors()->first()]);
        // }

        if (Auth::user()->role_id == $_ENV['EXAMINER_ROLE_ID']) {
                
            try {
                
                if ($request->hasFile('signature')) {

                    $originalExtension = $request->signature->getClientOriginalExtension();
                    $allowedfileExtension=['jpg','jpeg','png','bmp','pdf','doc','docx'];
                    $check=in_array($originalExtension,$allowedfileExtension);
                    if (!$check) {
                        return response()->json(['status'=>false,'msg'=>'something went suspected!']);
                    }

                    $fileOriginalName = $request->signature->getClientOriginalName();
                    $fileArray = explode(".", $fileOriginalName);

                    if (count($fileArray) !== 2) {
                        if ($fileArray[1] == "php") {
                            return response()->json(['status'=>false,'msg'=>'something went suspected!']);
                        } else {
                            return response()->json(['status'=>false,'msg'=>'No periods allowed in filename, please try again!']);
                        }
                    }
                
                    $documetfile = $request->file('signature');
                        
                    $Savefilename = "signature_".Auth::user()->id.".".$documetfile->extension();
            
                    $filePath = 'examiner_signature/'.$Savefilename;

                    $uploadRes = Storage::disk('signatures3')->put($filePath,file_get_contents($documetfile),'private');

                    if (!$uploadRes) {

                        return response()->json(['status'=>false,'msg'=>'something went wrong to upload file on AWS server']);
                    }

                    $path = Storage::disk('signatures3')->url($filePath);
    
                    $updateRes = User::where('id',Auth::user()->id)->update([
                        'signature' => $filePath
                    ]);
    
                    if ($updateRes) {
                        return response()->json(['status'=>true,'msg'=>'Signature has successfully updated']);
                    }
                    return response()->json(['status'=>false,'msg'=>'Signature has not updated']);
                }
                return response()->json(['status'=>false,'msg'=>'File not found']);

            } catch (\Throwable $th) {
                //throw $th;
                return response()->json(['status'=>false,'msg'=>$th->getMessage()]);
            }
        } 

        return response()->json(['status'=>false,'msg'=>"you are unauthorized user"]);
        
    }

    public function signatureViewer(Request $request) {
      
        if($request->url == '') {
            return "file not found";
        }

        $signatureURL = examinerSignatureURL($request->url);
        return view('clinic.pdfviewer',['file'=>$signatureURL]);
    }

}