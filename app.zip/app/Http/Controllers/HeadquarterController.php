<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon; 
use DataTables;
use Validator;

/**
 * This class is used to interact with the Headquarter Personnel Module
 *
 * PHP version 8.0.8
 *
 * @category  Supporting Script
 * @package   Headquarter Personnel Module
 * @author    Chetu
 * @copyright 2021 Chetu
 */

class HeadquarterController extends Controller
{
    /**
     * This method is used to show listing of Headquarter Personnel data
     *
     * @param  Illuminate\Http\Request $request
     */
    public function index(Request $request) {

        //call helper for check the permission for user role.
        $action = checkPermission($request->path());
         
        if ($request->ajax()) {
            $data = User::select('*')->where(['role_id' => $_ENV['HEADQUARTER_ROLE_ID'],'deleted'=>'0'])->orderByDesc('id')->get();

            
        
            return Datatables::of($data)
                    ->addIndexColumn()
                    ->addColumn('action', function($row) use($action){
            if($action == 1){
                $btn = '<div class="db-action-box"><div class="edit-icon"><p class="editbtn" data-toggle="tooltip" data-placement="top" title="Edit" data-id="'.$row->id.'"><i class="far fa-edit"></i></p></div><div class="delete-icon"><p class="deletebtn" title="Delete" data-id="'.$row->id.'"><i class="fas fa-times"></i></p></div>';
            } else {
                $btn = '<div class="db-action-box"><div class="edit-icon"><p class="access_denied"  data-toggle="tooltip" data-placement="top" title="Edit" ><i class="far fa-edit"></i></p></div><div class="delete-icon"><p class="access_denied" title="Delete" ><i class="fas fa-times"></i></p></div>'; 
            }
                    return $btn;
                    })->addColumn('firstname', function($row){
     
                        $btn = explode(' ',trim($row->name));;

                        return $btn[0];
                    })->addColumn('lastname', function($row){
     
                        return trim(strstr($row->name," "));

                    })
                    ->rawColumns(['action','firstname','lastname'])
                    ->make(true);
        }

        $headquarters = User::where(['role_id' => $_ENV['HEADQUARTER_ROLE_ID'],'deleted'=>'0'])->orderByDesc('id')->get();   //Headquarters are all Users whose role_id=2

        return view('headquarters.list', compact('headquarters','action'));
    }

    /**
     * This method is used to add a Headquarter Personnel
     *
     * @param  Illuminate\Http\Request $request
     */
    public function addHeadquarter(Request $request) {

        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required|string|min:8|regex:/[A-Z]/|regex:/[0-9]/|regex:/[@$!%*#?&]/|confirmed',
            'password_confirmation' => 'required'
        ]);

        if ($validator->passes()) {

            $name = $request->firstName.' '.$request->lastName;  
            
            $checkeEmail = User::where(['email'=>$request->email, 'role_id'=>$_ENV['HEADQUARTER_ROLE_ID']])->first();

            if ($checkeEmail) {
                return response()->json(['status'=>false, 'msg'=>'Headquarter Personnel Email Id already exists']);
            }
            /* Below Code commented because we are removing User Id concept
            $checkeuserId = User::where(['user_id'=>$request->userId, 'role_id'=>$_ENV['HEADQUARTER_ROLE_ID'], 'deleted'=>'0'])->first();

            if ($checkeuserId) {
                return response()->json(['status'=>false, 'msg'=>'Headquarter Personnel User Id already exists']);
            }
            */
            User::create([
                'name' => $name, 
                'email' => $request->email,
                'user_id' => $request->email,
                'password' => Hash::make($request['password']),
                'role_id' => $_ENV['HEADQUARTER_ROLE_ID'],
                'created_at' => Carbon::now()
            ]);

            return response()->json(['status'=>true, 'msg'=>'Headquarter Personnel created successfully']);
        }

        return response()->json(['status'=>false, 'msg'=>$validator->errors()->first()]);
    }

    /**
     * This method is used to update a Headquarter Personnel
     *
     * @param  Illuminate\Http\Request $request
     */
    public function updateHeadquarterUser(Request $request) {

        $response = [];
        $idval = $request->idval;

        if ($idval == '') {
            $response['status'] = false;
            $response['msg'] = 'Id is required';
            return response()->json($response);
        }

        /* Below Code commented because we are removing User Id concept

        $checkeEmail = User::where(['email'=>$request->email,'role_id'=>$_ENV['HEADQUARTER_ROLE_ID'],'deleted'=>'0'])->where('id','!=',$idval)->first();

        if ($checkeEmail) {
            return response()->json(['status'=>false,'msg'=>'Headquarter Personnel Email Id already exists']);
        }

        $checkeuserId = User::where(['user_id'=>$request->userId,'role_id'=>$_ENV['HEADQUARTER_ROLE_ID'],'deleted'=>'0'])->where('id','!=',$idval)->first();

        if ($checkeuserId) {
            return response()->json(['status'=>false,'msg'=>'Headquarter Personnel User Id already exists']);
        }
        */

        $UpdateRes = User::where('id',$idval)->update([
            'name' => $request->firstName." ".$request->lastName,
        ]);
        
        if ($UpdateRes) {
            $response['status'] = true;
            $response['msg'] = 'Headquarter Personnel updated successfully';
        } else {
            $response['status'] = false;
            $response['msg'] = 'something went wrong to update';
        }

        return response()->json($response);
    }

    /**
     * This method is used to delete a Headquarter Personnel
     *
     * @param  Illuminate\Http\Request $request
     */
    public function deleteHeadquarterUser(Request $request) {

        $response = [];
        $idval = $request->idval;

        if ($idval == '') {
            $response['status'] = false;
            $response['msg'] = 'Id is required';
            return response()->json($response);
        }

        $UpdateRes = User::where('id',$idval)->update([
            'deleted' =>'1',
        ]);

        if ($UpdateRes) {
            $response['status'] = true;
            $response['msg'] = 'Headquarter Personnel deleted successfully';
        } else {
            $response['status'] = false;
            $response['msg'] = 'something went wrong to delete';
        }

        return response()->json($response);
    }

    /**
     * This method is used to edit a Headquarter Personnel
     *
     * @param  Illuminate\Http\Request $request
     */
    public function editHeadquarter(Request $request) {
        
        $user = User::where('id',$request->id)->first();
        if ($user) {
            return response()->json(['status'=>true,'data'=>$user,'msg'=>'record found successfully']);
        }
        return response()->json(['status'=>false,'data'=>[],'msg'=>'User does not found']);
    }
}