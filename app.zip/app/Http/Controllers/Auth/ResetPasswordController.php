<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\ResetsPasswords;
use Illuminate\Http\Request;

use DB; 
use Carbon\Carbon; 
use App\Models\User;
use Hash;
use Illuminate\Support\Str;

class ResetPasswordController extends Controller {
    
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset requests
    | and uses a simple trait to include this behavior. You're free to
    | explore this trait and override any methods you wish to tweak.
    |
    */

    use ResetsPasswords;

    public function showResetForm(Request $request)
    {
        $token = $request->route()->parameter('token');

        return view('layouts.login.resetpassword')->with(
            ['token' => $token, 'email' => $request->email]
        );
    }

    protected function rules()
    {
        return [
            'token' => 'required',
            'email' => 'required|email',
            'password' => ['required|min:8', 'confirmed', Rules\Password::defaults()],
        ];
    }

    /**
      * This method will be used to submit password reset form
      *
      * @param Illuminate\Http\Request $request
      */
    public function submitResetPasswordForm(Request $request)
      {
          $request->validate([
              'token' => 'required',
              'email' => 'required|email|exists:users',
              'password' => 'required|min:8|confirmed',
              'password_confirmation' => 'required'
          ]);
  
          $updatePassword = DB::table('password_resets')
                              ->where([
                                'email' => $request->email 
                                // 'token' => $request->token
                              ])
                              ->first();
                                
          if(!$updatePassword && !Hash::check($request->token, $updatePassword->token)){
              return back()->withInput()->with('error', 'Invalid token!');
              
          }
  
          $user = User::where('email', $request->email)
                      ->update(['password' => Hash::make($request->password)]);
 
          DB::table('password_resets')->where(['email'=> $request->email])->delete();
  
          return redirect('/')->with('message', 'Your password has been changed!');
      }


    /**
     * Where to redirect users after resetting their password.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;
}
