<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Cookie;

class LoginController extends Controller {
    
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */
    use AuthenticatesUsers;

    /*
    | Where to redirect users after login.
    |
    | @var string
    */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
    * Create a new controller instance.
    *
    * @return void
    */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    public function showLoginForm() {
        return view('layouts.login.login');
    }

    /**
    * This method is used for login functionality
    *
    * @param  Illuminate\Http\Request $request
    */
    public function login(Request $request) {

        $email = $request->input('email');
        $password =  $request->input('password');

        // Validating email or user id and password field
        $validator = Validator::make($request->all(), [
            'email' => ['required'],
            'password' => ['required'],
        ]);

        $rememberOption = $request->has('remember') ? TRUE : FALSE;
        
        if($validator->fails()) {
            return redirect('/')->withErrors($validator)->withInput();
        }

        $checkmuliptleusers = $this->matchEmail($email,$password);

        if (count($checkmuliptleusers) > 1) {

            $arr = [];
            foreach ($checkmuliptleusers as $list) {
                $arr[] = $list->role_id;
            }

            $getroles = DB::table('roles')->whereIn('id', $arr)->get();

            return view('layouts.login.login_role',['role_arr'=>$getroles,'email'=>$email,'password'=>$password]);
        }

        $attempt_arr_email = ['email' => $email, 'password'=>$password, 'deleted' =>'0'];
        // $attempt_arr_user = ['user_id' => $email, 'password'=>$password, 'deleted' =>'0'];
         
        if (Auth::attempt($attempt_arr_email)) {
            $this->saveLogActivity('Logged In');
            if ($rememberOption) {
                $cookie = \Cookie::queue(Cookie::make('username',$email,86400*30));
                $cookie = \Cookie::queue(Cookie::make('user_pass',$password,86400*30));
                
            } else {
                if (\Cookie::get('username') !== false && \Cookie::get('user_pass') !== false) {
                    \Cookie::queue(\Cookie::forget('username'));
                    \Cookie::queue(\Cookie::forget('user_pass'));
                }
            }

            if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID'] ) {

                return redirect('/dashboard')->withSuccess('Signed in');

            } else {
                return redirect('/clinic-list')->withSuccess('Signed in');
            }
           
        }
    
        return redirect("/")->withErrors(['err'=>'invalid credential'])->withInput();
    }
    
    /**
    * This method is used for login functionality
    *
    * @param string $email    Email or user Id of the user
    * @param string $password Password of the user
    */
    public function matchEmail(string $email = '', string $password = '') {

        $users = DB::table('users')
                    ->where('deleted', '=', '0')
                    ->Where(function ($query) use ($email) {
                        $query->where(['email'=>$email])
                            ->orwhere(['user_id'=>$email]);
                    }
                )->get();

        $arr = [];
        foreach ($users as $value) {
            if (Hash::check($password, $value->password, [])) {
                if($email == $value->email || $email == $value->user_id) {
                    $arr[] = $value;
                }
            }
        }
        return $arr;
    }

    public function check_user_role($email) {

        $users = User::where(['email'=>$email])->get();
        return $users;
    }

    //this function is used to user login functionality
    public function loginCheckRole(Request $request) {
        
        $email = $request->input('email');
        $password =  $request->input('password');
        $validator = Validator::make($request->all(), [
            'email' => ['required','max:255'],
            'password' => ['required', 'string', 'min:8'],
        ]);

        if($validator->fails()) {

            return redirect("/")->withErrors($validator)->withInput();
        }

        $attempt_arr_email = ['email' => $email, 'password'=>$password, 'deleted' =>'0'];
        $attempt_arr_user = ['user_id' => $email, 'password'=>$password, 'deleted' =>'0'];

        if ($request->input('user_role') != null) {
            $attempt_arr_email['role_id'] = $request->input('user_role');
            $attempt_arr_user['role_id'] = $request->input('user_role');
        }

        if (Auth::attempt($attempt_arr_email) || Auth::attempt($attempt_arr_user)) {
            $this->saveLogActivity('Logged In');
            // Authentication passed...
            return redirect('/dashboard')->withSuccess('Signed in');
        }

        return redirect("/")->withErrors(['err'=>'invalid credential'])->withInput();
    }

    public function login_to_dashboard(Request $request)
    {
        return view('dashboard');

    }

    public function logout(Request $request)
    {
        $this->saveLogActivity('Log Out');
        $this->guard()->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        if ($response = $this->loggedOut($request)) {
            return $response;
        }

        return $request->wantsJson() ? new JsonResponse([], 204) : redirect('/');
    }
    
    public function saveLogActivity($activity)
    {
        DB::table('log_activities')->insert([
            'user_id'=>Auth::user()->id,
            'activity'=>$activity,
            'ip'=>$_SERVER['REMOTE_ADDR'],
            'user_agent'=>$_SERVER['HTTP_USER_AGENT'],
            'created_at'=>Carbon::now()
        ]);
    }

}