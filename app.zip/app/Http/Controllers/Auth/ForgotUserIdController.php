<?php 
  
namespace App\Http\Controllers\Auth;
  
use App\Http\Controllers\Controller;
use Illuminate\Http\Request; 
use DB; 
use Carbon\Carbon; 
use App\Models\User; 
use Mail; 
use Hash;
use Illuminate\Support\Str;
  
class ForgotUserIdController extends Controller
{
      /**
       * This method will be used to show forgot UserId form
       *
       * @return response()
       */
      public function showForgotUserIdForm()
      {
         return view('layouts.login.forgotuserid');
      }
  
      /**
       * This method will be used to submit forgot UserId form
       *
       * @return response()
       */
      public function submitForgotUserIdForm(Request $request)
      {

        $request->validate([
            'email' => 'required|email|exists:users',
        ],
        [
            'email.exists' => 'User does not exist!',
        ]);

        $userData = User::where(['email'=>$request->email,'deleted'=>'0'])->first();

        if (!$userData) {
            return back()->with('error', 'User does not exist!');
        }

        try {

            Mail::send('emails.forgotUserId', ['user_id' => $userData->user_id,'name' => $userData->name], function($message) use($request){
                $message->to($request->email);
                $message->subject('Forgot User Id');
            });
        } catch(\Exception $e) {
            \Log::info($e->getMessage());
            return back()->with('error', 'Something went wrong!');
        }
            
          return back()->with('status', 'We have e-mailed your User Id!');
      }
}