<?php 
  
namespace App\Http\Controllers\Auth; 
  
use App\Http\Controllers\Controller;
use Illuminate\Http\Request; 
use DB; 
use Carbon\Carbon; 
use App\Models\User; 
use Mail; 
use Hash;
use Illuminate\Support\Str;
  
class ForgotPasswordController extends Controller
{
      /**
       * This method will be used to show forgot password form
       *
       * @return response()
       */
      public function showForgotPasswordForm()
      {
         return view('layouts.login.forgotpassword');
      }
  
      /**
       * This method will be used to submit forgot password form
       *
       * @param Illuminate\Http\Request $request
       */
      public function submitForgotPasswordForm(Request $request)
      {
            $request->validate([
                'email' => 'required'
            ]);
            
            // Search user either by user_id or email

            $user = DB::table('users')
                ->where('deleted', '=', '0')
                ->Where(function ($query) use ($request) {
                    $query->where(['email'=>$request->email])
                        ->orwhere(['user_id'=>$request->email]);
                })->first();

            if ($user === null) {
                return redirect('/auth/forgot-password')->with('status', 'We have e-mailed your password reset link!, If you do not receive shortly, please contact Administrator!');
            } else {
                try {
                    // Generate random token
                    $token = Str::random(64);

                    $userEmail = $user->email;

                    $tokenExistance = DB::table('password_resets')
                                ->where('email', $userEmail)
                                ->get();

                    if (count($tokenExistance) > 0) {
                        DB::table('password_resets')
                        ->where('email', $userEmail)
                        ->update([
                            'token' => $token, 
                            'created_at' => Carbon::now()
                        ]);
                    } else {
                        DB::table('password_resets')->insert([
                        'email' => $userEmail,
                        'token' => $token, 
                        'created_at' => Carbon::now()
                        ]);
                    }
                
                    Mail::send('emails.forgotPassword', ['token' => $token,'name' => $user->name], function($message) use($userEmail){

                        $message->to($userEmail);
                        $message->subject('Password Reset Link');
                    });
                } catch(\Exception $e) {
                    \Log::info($e->getMessage());
                    return back()->with('status', 'We have e-mailed your password reset link!, If you do not receive shortly, please contact Administrator!');
                }
            }
  
          return back()->with('status', 'We have e-mailed your password reset link!, If you do not receive shortly, please contact Administrator!');
      }


      /**
       * This method will be used to show password reset form
       *
       * @return response()
       */
      public function showResetPasswordForm($token) {
          
            $updatePassword = DB::table('password_resets')
            ->where([
            'token' => $token
            ])->first();
            
            $email = $updatePassword == false ? "" : $updatePassword->email;

        return view('layouts.login.resetpassword', ['token' => $token, "email"=> $email]);
      }
  

      /**
       * This method will be used to submit password reset form
       *
       * @param Illuminate\Http\Request $request
       */
        public function submitResetPasswordForm(Request $request) {
            
            try {

                $request->validate([
                    'email' => 'required|email|exists:users',
                    'password' => 'required|string|min:8|max:15|confirmed',
                    'password_confirmation' => 'required'
                ]);
        
                $updatePassword = DB::table('password_resets')
                                    ->where([
                                      'email' => $request->email, 
                                      'token' => $request->token
                                    ])
                                    ->first();
        
                if (!$updatePassword) {
                    return back()->withInput()->with('error', 'Invalid token!');
                }
        
                $user = User::where('email', $request->email)
                              ->update([
                                'password' => Hash::make($request->password),  
                                'updated_at' => Carbon::now()
                              ]);
       
                DB::table('password_resets')->where(['email'=> $request->email])->delete();
        
                return redirect('/')->with('status', 'Your password has been changed!');

            } catch (\Throwable $th) {
                //throw $th;
                return back()->withInput()->with('error', $th->getMessage());
            }
          
      }
}