<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use DataTables;
use App\Models\Appointment;
use App\Models\ScrapModel;

/**
 * This class is used to interact with the Dashboard Matrix Module
 *
 * PHP version 8.0.8
 *
 * @category  Supporting_Script
 * @package   Dashboard_Module
 * @author    Chetu
 * @copyright 2022 Chetu
 */

class DashboardController extends Controller
{
    /**
     * This method will be used to show the dashboard and pass required data
     *
     * @param  Illuminate\Http\Request $request
     */
    public function index(Request $request) {
        $clinicTypes = DB::table('clinic_types')->get();
       
        if ($request->ajax()) {
            
            if (isset($request->clinic_type) && $request->clinic_type != '') {
                $appointmentData = Appointment::leftjoin('users','users.id','=','appointments.user_id')
                                ->leftjoin('patients','patients.id','=','appointments.patient_id')
                                ->leftjoin('locations','locations.id','=','appointments.location_id')
                                ->join('states','states.id','=','locations.state_id')
                                ->where('appointments.deleted','=','0')
                                ->where('appointments.service_date','>=',convertDateIST($request->from_date))
                                ->where('appointments.service_date','<=',convertDateIST($request->to_date))
                                ->whereIn('locations.clinic_type_id',$request->clinic_type)
                                ->groupBy('appointments.service_date')
                                ->groupBy('appointments.location_id')
                                ->orderBy('appointments.service_date','DESC')
                                ->select('appointments.*','users.name as user_name','locations.name as location_name','locations.clinic_type_id as clinic_type','states.name as state_name')
                                ->get();
            } else {
                $appointmentData = Appointment::leftjoin('users','users.id','=','appointments.user_id')
                            ->leftjoin('patients','patients.id','=','appointments.patient_id')
                            ->leftjoin('locations','locations.id','=','appointments.location_id')
                            ->join('states','states.id','=','locations.state_id')
                            ->where('appointments.deleted','=','0')
                            ->where('appointments.service_date','>=',convertDateIST($request->from_date))
                            ->where('appointments.service_date','<=',convertDateIST($request->to_date))
                            ->groupBy('appointments.service_date')
                            ->groupBy('appointments.location_id')
                            ->orderBy('appointments.service_date','DESC')
                            ->select('appointments.*','users.name as user_name','locations.name as location_name','locations.clinic_type_id as clinic_type','states.name as state_name')
                            ->get();
            }
            
            return  Datatables::of($appointmentData)
                        ->addIndexColumn()
                        ->addColumn('service_date', function($row) {

                            return convertDate($row->service_date);
                            
                        })->addColumn('scheduled', function($row) {

                            return $this->getScheduleCount($row->service_date,$row->location_id);
                            
                        })->addColumn('clinic_type', function($row) {
                            
                            $clinicInfo = $this->getClinicType($row->clinic_type);
                            
                            if (count($clinicInfo) > 0)  {

                                return $clinicInfo[0]->name;
                            } else { 
                                return "";
                            }
                            
                        })->rawColumns(['service_date','scheduled'])->make(true);           
        }

    	return view('dashboard', compact('clinicTypes'));
    }

    /**
     * This method will be used to get Clinic Type by Id
     *
     * @param int $clinicId Clinic Type Id of the Clinic
     */
    public function getClinicType(int $clinicId = 0) {
        
        if (!empty($clinicId)) {
            $scrapModel = new ScrapModel();

            return $scrapModel->select_query('clinic_types', ['id'=>$clinicId]);
        }
        return [];
    }

     /**
     * This method will be used to get Scheduled Count
     *
     * @param  string $date       Clinic service date
     * @param  int    $locationId Location Id of the Clinic
     * @return array              Examiner List User name and userId
     */
    public function getScheduleCount(string $date = '', int $locationId = 0) {
        if (!empty($date) && !empty($locationId)) {
            $totalSchedule = Appointment::where('status', '!=', 2)->where(['service_date'=>$date,  'location_id' => $locationId,'deleted'=>0])->where('patient_id', '!=', 0)->count();

            return $totalSchedule;
        }
        return 0;
    }

    /**
    * This function will be used to export dashboard report data
    *
    * @param  object $request request data 
    * @return object          Downloads the data in excel
    * @throws Exception       Any issues encountered
    */
    public function exportDashboardReport(Request $request) { 
       
        // file name for download
        $fileName = "volume_count_" . $request->fromDate . '_' .$request->toDate. ".xls";
        // Headers for download
        ob_end_clean();
        header("Content-Type: application/vnd.ms-excel");
        header("Content-Disposition: attachment; filename=\"$fileName\""); 
        header("Pragma: no-cache");
        header("Expires: 0");
        
        $getClinicTypeIds = $request->clinicType[0];
        $clinicTypeIds = explode(",", $getClinicTypeIds);
        
        // Columns Heading
        $columns = ['Service Date', 'Clinic Name', 'Scheduled', 'Clinic Type'];

        // appointment Data according to from and to dates and clinic type combination
        if (isset($request->clinicType) && ($request->clinicType[0] != '')) {
            $appointmentData = Appointment::leftjoin('users','users.id','=','appointments.user_id')
                            ->leftjoin('patients','patients.id','=','appointments.patient_id')
                            ->leftjoin('locations','locations.id','=','appointments.location_id')
                            ->join('states','states.id','=','locations.state_id')
                            ->where('appointments.deleted','=','0')
                            ->where('appointments.service_date','>=',convertDateIST($request->fromDate))
                            ->where('appointments.service_date','<=',convertDateIST($request->toDate))
                            ->whereIn('locations.clinic_type_id',$clinicTypeIds)
                            ->groupBy('appointments.service_date')
                            ->groupBy('appointments.location_id')
                            ->orderBy('appointments.service_date','DESC')
                            ->select('appointments.*','users.name as user_name','locations.name as location_name','locations.clinic_type_id as clinic_type')
                            ->get();
        } else {
            $appointmentData = Appointment::leftjoin('users','users.id','=','appointments.user_id')
                                ->leftjoin('patients','patients.id','=','appointments.patient_id')
                                ->leftjoin('locations','locations.id','=','appointments.location_id')
                                ->join('states','states.id','=','locations.state_id')
                                ->where('appointments.deleted','=','0')
                                ->where('appointments.service_date','>=',convertDateIST($request->fromDate))
                                ->where('appointments.service_date','<=',convertDateIST($request->toDate))
                                ->groupBy('appointments.service_date')
                                ->groupBy('appointments.location_id')
                                ->orderBy('appointments.service_date','DESC')
                                ->select('appointments.*','users.name as user_name','locations.name as location_name','locations.clinic_type_id as clinic_type')
                                ->get();
        }

        $flag = false;

        if (count($appointmentData) > 0) {

            foreach($appointmentData as $row) {

                if(!$flag) {
                    echo implode("\t", $columns) . "\n"; 
                    $flag = true; 
                }

                $clinicInfo = $this->getClinicType($row->clinic_type);

                if (count($clinicInfo) > 0)  {
                    $clinicType = $clinicInfo[0]->name;
                } else {
                    $clinicType = '';
                }

                $scheduleCount = $this->getScheduleCount($row->service_date,$row->location_id);

                echo implode("\t", [$row->service_date,$row->location_name,$scheduleCount,$clinicType]) . "\n"; 
            }
        }
    }

    public function forbidden() {
        
    	return view('forbidden');
    }

}
