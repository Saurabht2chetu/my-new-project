<?php 
  
namespace App\Http\Controllers; 
  
use App\Http\Controllers\Controller;
use Illuminate\Http\Request; 
use Illuminate\Support\Facades\Auth;
use DB; 
use Carbon\Carbon; 
use App\Models\Roles;
use App\Models\Menus;
use App\Models\RolePermission;

/**
 * This class is used to interact with the Role and Permissions Module
 *
 * PHP version 8.0.8
 *
 * @category  Supporting Script
 * @package   Role and Permissions Module
 * @author    Chetu
 * @copyright 2021 Chetu
 */

class RoleController extends Controller
{
    /**
     * This method will be used to show role and permission list page 
     *
     * @return response()
     */
      public function index() {
        
        $roles = Roles::where('id', '!=' , $_ENV['SUPERADMIN_ROLE_ID'])->get();

        $menus = Menus::all();
      
        $role = Roles::find(Auth::user()->role_id);
        return view('roles.list', compact('role','roles','menus'));
      }

    /**
     * This method is used to add Role Permission
     *
     * @param  Illuminate\Http\Request $request
     */
      public function addRole(Request $request)
      {

        $request->validate([
          'chooseRole' => 'required'
        ]);

        $menuArr = isset($request->menu) ? $request->menu : [];
        $menuPermission = $request->menu_;

        DB::table('role_permissions')->where('role_id',$request->chooseRole)->delete();
        
        $saveArray = [];
        for($x=0; $x<count($menuArr); $x++) {   
          
          $saveArray[] = [
            'role_id' => $request->chooseRole, 
            'menu_id' => $menuArr[$x], 
            'is_writable' =>$menuPermission[$menuArr[$x]][0], 
            'created_at' => Carbon::now()
  
          ];
        }

        RolePermission::insert($saveArray);

        return redirect()->route('role-permissions')->with(['status'=>'Permission has been assigned!','roletype'=>$request->chooseRole]);

      }
      
      
    /**
     * This method will be used to fetch list of save permission
     *
     * @return response()
     */
      public function getPermissionList(Request $req) {
        
        if($req->role_id != '') {

          $role = $req->role_id;
          $ListResponse = menus::leftjoin('role_permissions', function($join) use ($role) {
            $join->on('menus.id', '=', 'role_permissions.menu_id'); // i want to join the users table with 
            $join->where('role_permissions.role_id','=',$role);
          })->orderBY('menus.seq_no','ASC')->select('menus.*','role_permissions.is_writable')->get();

          if(count($ListResponse) > 0) {
            return response()->json(['status'=>true,'data'=>$ListResponse,'msg'=>'list found success']); 
          }
          return response()->json(['status'=>false,'data'=>[],'msg'=>'Something went wrong to find record']); 
            
        }
        
      }
}