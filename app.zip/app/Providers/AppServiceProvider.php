<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Validator;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        // \URL::forceScheme('https');
        Validator::extend('phone_len_validate', function($attribute, $value, $parameters, $validator) {
            $phoneNo = str_replace(["|","-","&"],'',$value);
            if(strlen($phoneNo) == 10){
                return true;
            } 
            return false;
        });
    }
}
