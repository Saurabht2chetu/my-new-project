<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ClinicHistory extends Model
{
    use HasFactory;

    protected $table = 'clinic_history';

    protected $fillable = [
        'appointment_id',
        'service_date',
        'service_time',
        'patient_id',
        'user_id',
        'location_id',
        'invoice_url',
        'cepacket_url',
        'combined_url',
        'type_of_exam',
        'request_status',
        'special_instruction',
        'case_id',
        'status',
        'active',
        'deleted',
        'examiner_id',
        'assistant_id',
        'updated_by',
        'created_at',
        'updated_at',
        'invoice_update',
        'record_update'
    ];
}