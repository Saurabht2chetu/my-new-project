<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Patient extends Model
{
    use HasFactory;

    protected $table = 'patients';

    /**
    * The attributes that are mass assignable.
    *
    * @var string[]    
    */
    protected $fillable = [
        'first_name',
        'last_name',
        'phone',
        'dob',
        'active',
        'deleted',
        'created_at',
        'updated_at'
    ];
}
