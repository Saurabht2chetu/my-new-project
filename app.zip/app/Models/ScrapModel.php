<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;


/**
* This class is used to DB operation.
*
* PHP version 7.4.23
*
* @category  Supporting Script
* @package   Webscrap Integration 
* @author    Chetu
* @copyright 2021 Moonlight Examination.
*/
class ScrapModel extends Model
{
    use HasFactory;

    /**
    * This function is used to select data from required tables.
    *
    * @param  string $tablename     table name for fetch the data 
    * @param  array $condition      condition array with key or value pair
    * @return object                return array object
    * @throws Exception             Any issues encountered
    */
    public function select_query($tablename,$condition=array()) {
        
        $datas = DB::table($tablename);

        if(count($condition) > 0) {
            $datas->where($condition);
        }

        return $datas->get();       
    }

    /**
    * This function is used to insert record into DB.
    *
    * @param  string $tablename     table name for insert  
    * @param  array $data           data array with key or value pair
    * @return int                   return last inserted id
    * @throws Exception             Any issues encountered
    */ 
    public function insert_query($tablename,$data=array()) {

        //insertGetId
        // print_r([$tablename,$data]);
        // die;
        return DB::table($tablename)->insertGetId($data);
    }

    /**
    * This function is used to update the record.
    *
    * @param  string $tablename     table name for insert  
    * @param  array $data           data array with key or value pair
    * @param  array $conditions     condition array with key or value pair
    * @return boolean               return true or false
    * @throws Exception             Any issues encountered
    */  
    public function update_query($tablename,$data=array(),$conditions=array()) {
        
        //insertGetId
        return DB::table($tablename)->where($conditions)->update($data);
    }

    /**
    * This function is used to fetch all states credentials.
    *
    * @return array                 return array object
    * @throws Exception             Any issues encountered
    */
    public function getStateCrendentails() {
        
        return  DB::table('states')
                    ->where('user_name','!=',null)
                    ->where('user_password','!=',null)
                    ->where('user_name','!=','')
                    ->where('user_password','!=','')
                    ->where('active','1')
                    ->orderBy('id','DESC')->get();
    }

}
