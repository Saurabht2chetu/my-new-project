<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ClinicDataHistory extends Model
{
    use HasFactory;
	
	 protected $table = 'clinic_data_history';
    /**
    * The attributes that are mass assignable.
    *
    * @var string[]
    */
    protected $fillable = [
        'service_date',
        'location_id',
        'team_member',
        'contact_type',
        'chart_type',
        'x_ray_vendor',
        'from_time',
        'to_time',
        'admin_write_in',
        'assistant_write_in',
        'training',
        'email',
        'invite',
        'created_at',
        'updated_at',
        'xray',
    ];
}
