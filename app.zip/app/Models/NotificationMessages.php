<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NotificationMessages extends Model
{
    use HasFactory;

    protected $table = 'notification_messages';
    /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'notification_id',
        'patient_id',
        'message',
        'error_msg',
        'status',
        'created_at',
        'updated_at',
    ];
}
