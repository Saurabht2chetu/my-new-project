<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Menus;

class RolePermission extends Model
{
    use HasFactory;

    protected $table = 'role_permissions';

    protected $fillable = ['role_id','menu_id','is_writable','seq_no','created_at','updated_at'];

    public function getMenusName() {
        
        return $this->belongsTo(Menus::class,'menu_id','id');
    }
}