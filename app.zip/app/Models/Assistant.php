<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Assistant extends Model
{
    use HasFactory;

    protected $table = 'clinic_assistant';
    
     /**
     * The attributes that are mass assignable.
     *
     * @var string[]
     */
    protected $fillable = [
        'service_date',
        'location_id',
        'assistant_id',
        'deleted',
        'created_at',
        'updated_at'
    ];

}
