<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PatientHistory extends Model
{
    use HasFactory;
    protected $table = 'patient_history';
    protected $fillable = [
        'first_name',
        'last_name',
        'phone',
        'dob',
        'active',
        'deleted',
        'created_at',
        'updated_at'
    ];
}
