<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use DB;

class Appointment extends Model
{
    use HasFactory;

    protected $table = 'appointments';

    protected $fillable = [
        'service_date',
        'service_time',
        'patient_id',
        'user_id',
        'location_id',
        'invoice_url',
        'cepacket_url',
        'combined_url',
        'type_of_exam',
        'request_status',
        'special_instruction',
        'case_id',
        'status',
        'active',
        'deleted',
        'created_at',
        'updated_at',
        'invoice_update',
        'record_update'
    ];

    public function getAppoinmentData() {

        DB::table('appointments')
            ->leftjoin('users','users.id','=','appointments.user_id')
            ->leftjoin('patients','patients.id','=','appointments.patient_id ')
            ->leftjoin('locations','locations.id','=','appointments.location_id')
            ->leftjoin('locations','locations.id','=','appointments.location_id')
            ->select('appointments.*','users.name as user_name','locations.name as location_name')
            ->get();
    }
   
}
