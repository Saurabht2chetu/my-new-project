<?php

return [
    'someKey' => 'some text',
];