@extends('layouts.adminlayout')
@section('title','Locations - Moonlight Examinations')
<?php //$action = 1; ?>
@section('content')

<div class="container-fluid">
    <div class="db-top4-box-wrapper">
        <div class="mt-3 hm-dis">
            <p class="db-heading"><a href="{{ route('dashboard') }}">Dashboard</a> / Locations</p>
            @if($action == 1)
                <button class="btn-main" data-toggle="modal" data-target="#locationAddModal"><i
                    class="fas fa-plus"></i> Add</button>
            @endif
        </div>
        @if (session('status'))
            <div class="alert alert-success" role="alert">
                {{ session('status') }}
            </div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger" role="alert">
                {{ session('error') }}
            </div>
        @endif

        <!-- Add Modal Form Starts -->
        <div class="modal fade md-round" id="locationAddModal" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content mc-clinic">

                    <div class="p-3">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="login-form">
                            <div class="text-center mb-4">
                                <h4>Add Location</h4>
                            </div>
                            <form action="" method="POST" id="addLocationForm">
                                <div class="form-group cli-grp">
                                    <label for="inputEmail4">State <span class="text-danger">*</span></label>
                                    <select class="form-control state-dd" name="stateName" id="state-dd" placeholder="">
                                        <option value=""> - Select -</option>
                                        <?php 
                                            foreach ($states as $state) {
                                                echo '<option value="'.$state->id.'">'.$state->name.'</option>';
                                            } 
                                        ?>
                                    </select>
                                </div>
                                <input type="hidden" name="cityName" value="0">
                                <!-- <div class="form-group cli-grp">
                                    <label for="inputEmail4">City <span class="text-danger">*</span></label>
                                    <select class="form-control city-dd" name="cityName" id="city-dd" placeholder="">
                                        <option value=""> - Select - </option>
                                        
                                    </select>
                                </div> -->

                                <div class="form-group cli-grp otherCitysection" id="otherCitysection" >
                                    
                                </div>


                                <div class="form-group cli-grp">
                                    <label for="inputEmail4">Location Name <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <input type="text" name="locationName" class="form-control frm-input-2" placeholder="Location" maxlength="250" required>
                                    </div>
                                </div>
                                <div class="form-group cli-grp">
                                    <label for="inputEmail4">Clinic Type <span class="text-danger">*</span></label>
                                    <select class="form-control" name="clinicType" id="clinicType" placeholder="">
                                        <option value=""> - Select -</option>
                                        <?php 
                                            foreach ($clinicTypes as $clinicType) {
                                                echo '<option value="'.$clinicType->id.'">'.$clinicType->name.'</option>';
                                            } 
                                        ?>
                                    </select>
                                </div>
                                <!-- <div class="form-group cli-grp">
                                    <label for="inputEmail4">Zip Code</label>
                                    <div class="formicon-parent">
                                        <input type="text" maxlength="5" minlength="5" name="zipCode" class="form-control frm-input-2"
                                            placeholder="Zip Code" required>
                                    </div>
                                </div> -->

                                <div class="form-group cli-grp">
                                    <label for="exampleInputEmail1">Actual Address </label>
                                    <div class="formicon-parent">
                                        <textarea name="actualAddress" class="form-control" id="exampleFormControlTextarea1" rows="3"
                                            placeholder="Actual Address"></textarea>
                                    </div>
                                </div>
                                <div class="form-group submit-btn">
                                    <div class="formicon-parent">
                                        <button type="submit"
                                            class="btn btn-block login-btn-01 login-btn-02">SUBMIT</button><span><i
                                                class="fas fa-arrow-right login-icon-right arro"></i></span>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Add Modal Form End -->

        <!-- edit Modal Form Starts -->
        <div class="modal fade md-round" id="editModal" tabindex="-1" role="dialog"
            aria-labelledby="editModalTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">

                    <div class="p-3">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="login-form">
                            <div class="text-center mb-4">
                                <h4>Edit Location</h4>
                            </div>
                            <form id="editForm" method="post">
                                @csrf
                                <input type="hidden" name="idval" id="idval" value="">
                                <!-- <div class="form-group cli-grp">
                                    <label for="inputEmail4">State</label>
                                    <select class="form-control state-dd" name="stateName"  placeholder="">
                                        <option value=""> - Select State - </option>
                                        <?php 
                                        /*
                                            foreach ($states as $state) {
                                                echo '<option value="'.$state->id.'">'.$state->name.'</option>';
                                            }
                                            */
                                        ?>
                                    </select>
                                </div>
                                 <div class="form-group cli-grp">
                                    <label for="inputEmail4">City</label>
                                    <select class="form-control city-dd" name="cityName" id="city-dd" placeholder="">
                                        <option value=""> - Select City - </option>
                                        
                                    </select>
                                </div> -->
                                <div class="form-group cli-grp otherCitysection" name="otherCity" id="otherCitysection">                                    
                                </div>

                                <div class="form-group cli-grp">
                                    <label for="inputEmail4">Location Name <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <input type="text" name="locationName" id="locationName" class="form-control frm-input-2" placeholder="Location" maxlength="250" required>
                                    </div>
                                </div>
                                <div class="form-group cli-grp">
                                    <label for="inputEmail4">Clinic Type <span class="text-danger">*</span></label>
                                    <select class="form-control" name="clinicType" id="editClinicType" placeholder="">
                                        <option value=""> - Select -</option>
                                        <?php 
                                            foreach ($clinicTypes as $clinicType) {
                                                echo '<option value="'.$clinicType->id.'">'.$clinicType->name.'</option>';
                                            } 
                                        ?>
                                    </select>
                                </div>
                                <!-- <div class="form-group cli-grp">
                                    <label for="inputEmail4">Zip Code</label>
                                    <div class="formicon-parent">
                                        <input type="text" maxlength="5" minlength="5" name="zipCode" id="zipCode" class="form-control frm-input-2"
                                            placeholder="Zip Code" required>
                                    </div>
                                </div> -->
                                <div class="form-group cli-grp">
                                    <label for="exampleInputEmail1">Actual Address </label>
                                    <div class="formicon-parent">
                                        <textarea name="actualAddress" id="actualAddress" class="form-control" id="exampleFormControlTextarea1" rows="3"
                                            placeholder="Actual Address"></textarea>
                                    </div>
                                </div>
                                <div class="form-group cli-grp">
                                    <label for="exampleInputEmail1">Scraped Address</label>
                                    <div class="formicon-parent">
                                        <textarea name="address" id="address" class="form-control" id="exampleFormControlTextarea1" rows="3"
                                            placeholder="Scraped Address" disabled></textarea>
                                    </div>
                                </div>


                                <!--  -->
                                <div class="form-group">
                                    <div class="formicon-parent">
                                        <button type="submit"
                                            class="btn btn-block login-btn-01">SUBMIT</button><span><i
                                                class="fas fa-arrow-right login-icon-right arr"></i></span>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- edit Modal Form End -->

        <div class="dashboard-table1">
            <!-- <div class="">
            </div>
            <div class="row mb-3">
                <div class="col-md-4">
                    
                </div>
                <div class="col-md-4 empty"></div>
                <div class="col-md-4">
                    <div class="show-data-list show-data-list-1">
                        <div class="form-group row">
                            <div class="col-md-12 sear-rel">
                                <select class="form-control " id="" placeholder="">
                                    <option>Select State</option>
                                    <option>Alabama</option>
                                    <option>Alabama</option>
                                    <option>Alabama</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
            <div class="row">
                <div class="col-md-12">
                    <table id="" class="stripe location-table" style="width:100%">
                        <thead>
                            <tr>
                                <th>Location Name</th>
                                <th>Actual Address</th>
                                <th>State</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
<script>
    $(function () {

        //this is Location for apply the validation on add Location form
        $("#addLocationForm").validate({

            rules: {
                stateName:{
                    required:true,
                },
                cityName:{
                    required:true,
                },
                locationName:{
                    required:true,
                    maxlength:250
                },                    
                clinicType: {
                    required:true,
                }

            },

            messages: {
                stateName:{
                    required:"State is required",
                },
                cityName:{
                    required:"City is required",
                }, 
                locationName: {
                    required:"Location Name is required",
                    maxlength:"Enter Character length between 1 - 250"
                },
                clinicType: {
                    required:"Clinic Type is required",
                }

            },

            errorPlacement: function(label, element) {

                label.addClass('mt-2 text-danger');

                label.insertAfter(element);

            },

            highlight: function(element, errorClass) {

                $(element).parent().addClass('has-danger');

                $(element).addClass('form-control-danger');

            },

            unhighlight: function(element, errorClass, validClass) {

                $(element).parents().removeClass('has-danger');

                    $(element).removeClass('form-control-danger');

                $(element).parents('.form-group').addClass('has-success');

            }
        });
        //<=---------------------END validation ------------------------------->

        //this is used for apply the validation on Edit Location form
        $("#editForm").validate({

            rules: {            
                locationName: {
                    required:true,
                    maxlength:250
                },
                clinicType: {
                    required:true,
                }
            },

            messages: {
                locationName:{
                    required:"Location name is required",
                    maxlength:"Enter Character length between 1 - 250"
                },               
                clinicType:{
                    required:"Clinic Type is required",
                }
            },

            errorPlacement: function(label, element) {

                label.addClass('mt-2 text-danger');

                label.insertAfter(element);

            },

            highlight: function(element, errorClass) {

                $(element).parent().addClass('has-danger');

                $(element).addClass('form-control-danger');

            },

            unhighlight: function(element, errorClass, validClass) {

                $(element).parents().removeClass('has-danger');

                    $(element).removeClass('form-control-danger');

                $(element).parents('.form-group').addClass('has-success');

            }

        });
        //<=---------------------END validation ------------------------------->



        var resultTable = $('.location-table').DataTable({
            processing: true,
            serverSide: false,
            order: [],
            "language": {
                "processing": "<img style='width:80px; height:80px;' src='{{url('/assets/images/loaderspinner.gif')}}' >"
            },
            ajax: "{{ route('locations') }}",
            columns: [
                {data: 'name', name: 'name'},
                {data: 'actual_address', name: 'actual_address'},
                {data: 'state_name', name: 'state_name'},
                {data: 'action', name: 'action', orderable: false, searchable: false},
            ]
        });
   

        // ---------------- start add Location --------------------------
        $(document).on('submit','#addLocationForm',function(e){
            e.preventDefault(); 
            if(!$("#addLocationForm").valid()){
                alert('Something went wrong at time of fill the form');
                return;
            }
            
            $.ajax({
                url: "{{ route('location.add') }}",
                type: "post",
                data: $(this).serialize() +'&_token='+"{{ csrf_token() }}",
                beforeSend:function() {
                    
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    
                    });
                },
                success:function(data){
                    swal.close();
                    if (data.status == true) {

                        $('#locationAddModal').modal('hide');
                        resultTable.ajax.reload();
                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success",
                        });

                    } else if (data.status == false) {
                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error",
                        });
                    } else {
                        window.location.reload(true);
                    }
                },
                error:function (jqXHR, textStatus, errorThrown) {

                    swal({
                        icon: "error",
                        title:'Oops!',
                        text: 'something went wrong! response status code - '+jqXHR.status,
                        // buttons: false,
                        closeOnClickOutside:false
                        
                    });
                    window.location.reload(true);

                },
            });
        });
        // ---------------- End add Location --------------------------

        $(document).on('submit','#editForm',function(e) {
    
                e.preventDefault();
                if(!$("#editForm").valid()) {
                    alert('Something went wrong at time of fill the form');
                    return;
                } 
                $.ajax({
                    url: "{{ route('location.update') }}",
                    type: "post",
                    data: $(this).serialize() +'&_token='+"{{ csrf_token() }}",
                    beforeSend:function() {
                        swal({
                            icon: "{{ url('/assets/images/loader.gif') }}",
                            text: 'Please Wait!',
                            buttons: false,
                            closeOnClickOutside:false
                        
                        });
                    },
                    success:function(data){
                        swal.close();
                        if (data.status == true) {

                            $('#editModal').modal('hide');

                            swal({
                                title: "Great!",
                                text: data.msg,
                                icon: "success",
                            }).then(function(event){
                                if(event) {
                                    resultTable.ajax.reload();
                                }
                            });

                        } else if (data.status == false) {
                            swal({
                                title: "Oops!",
                                text: data.msg,
                                icon: "error",
                            });
                        } else {
                            window.location.reload(true);
                        }
                    },
                    error:function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            console.log('500 status');
                        } else {
                            console.log('something went wrong!');
                        }
                        window.location.reload(true);
                    },
                });
        });

        $(document).on('click','.editbtn', function() {
                
                var id = $(this).attr('data-id');
                $.ajax({
                    url: "{{route('location.get')}}",
                    type: "GET",
                    dataType:'json',
                    data: {id:id,_token:"{{csrf_token()}}"},

                    success:function(output){
                        
                        if (output.status == true) {
                            var data = output.data;
                            $('#idval').val(data.id);
                            $('.state-dd option').each(function(){
                                if(this.value == output.data.state_id) {
                                    $(this).attr('selected',true);
                                }
                            });
                            addcities(output.data.state_id,output.data.city_id);
                            $('#locationName').val(data.name);
                            $('#address').val(data.address);
                            $('#actualAddress').val(data.actual_address);
                            $('#editClinicType').val(data.clinic_type_id).trigger('change');
                            $('#editModal').modal('show');
                        } else if (output.status == false) {
                            swal({
                                title: "Oops!",
                                text: output.msg,
                                icon: "error",
                            });
                        } else {
                            window.location.reload(true);
                        }
                        
                    },
                    error:function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            console.log('500 status');
                        } else {
                            console.log('something went wrong!');
                        }
                        window.location.reload(true);
                    },
                });
        });

        //this is Location for delete a Location
        $(document).on('click','.deletebtn',function(event){

            let id = $(this).attr('data-id');

            swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this location",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                closeOnClickOutside:false
            }).then((willDelete) => {
                if (willDelete) {
                    
                    $.ajax({
                        url: "{{route('location.delete')}}",
                        type: "POST",
                        data: {idval:id,_token:"{{ csrf_token() }}"},
                        beforeSend:function() {
                            swal({
                                icon: "{{ url('/assets/images/loader.gif') }}",
                                text: 'Please Wait...',
                            
                            });
                        },
                        success:function(data){
                            
                            swal.close();
                            if (data.status == true) {
                                resultTable.ajax.reload();
                                swal({
                                    title: "Great!",
                                    text: data.msg,
                                    icon: "success",
                                });

                            } else if (data.status == false) {
                                swal({
                                    title: "Oops!",
                                    text: data.msg,
                                    icon: "error",
                                });
                            } else {
                                window.location.reload(true);
                            }
                        },
                        error:function (jqXHR, textStatus, errorThrown) {
                            if (jqXHR.status == 500) {
                                console.log('500 status');
                            } else {
                                console.log('something went wrong!');
                            }
                            window.location.reload(true);
                        },
                    });

                } else {}
            });
        });
        //--------------END delet Location functionality----------------------

        // State Wise City
        $('.state-dd').on('change', function () {
            
            var idState = this.value;
            console.log('citycheck',$(".city-dd").val());
        
            addcities(idState,null);
            
        });

        function addcities(state_id,edit_city) {

            $(".city-dd").html('');
            $.ajax({
                url: "{{url('fetch-city')}}",
                type: "POST",
                data: {
                    state_id: state_id,
                    _token: '{{csrf_token()}}'
                },
                dataType: 'json',
                success: function (result) {
                    let text = '<option value=""> - Select City - </option>';
                    
                    $.each(result.states, function (key, value) {

                        text+='<option value="' + value.id + '">' + value.name + '</option>';    
                       
                    });
                    text+='<option value="others">Others</option>';
                    $(".city-dd").append(text);

                    if(edit_city != null) {

                        $(".city-dd").val(edit_city).trigger('change');
                    }
                }
            });

        } 

        // Hide And Show Other City Text box

        $(".city-dd").change(function () {
            
            if ($(this).val() == "others") {
                $(".otherCitysection").html('<label for="inputEmail4">Other Name</label><div class="formicon-parent"><input type="text" name="other_city" class="form-control frm-input-2" placeholder="Other City" required></div>');
            } else {
                $(".otherCitysection").html('');
            }
        });

    });

    $(document).on('click','.access_denied',function() {
        swal({
            icon: "error",
            title:'Oops!',
            text: 'You do not have permission to perform this action',
            // buttons: false,
            closeOnClickOutside:false
            
        });
    });
        //--------------- END --------------------- 
</script>


@endsection