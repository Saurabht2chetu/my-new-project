@extends('layouts.adminlayout')
@section('title','Upload Examiner signature - Moonlight Examinations')
@section('content')

<div class="container">
    <div class="row d-flex justify-content-center">
        <div class="col-md-8">
            
            <div class="card shadow p-4 bg-light custom-styling">
                <h2 class="title-change-pwd">Upload Signature</h2>
                <div class="login-form my-4">
                    @if(isset($path) && $path != '')
                    <a href="{{ route('signatureViewer',['url' => $path]) }}" target="_blank">View Signature</a>
                    @endif
                    <form id="uploadSignatureForm" method="POST" enctype="multipart/form-data">
                        <label for="password">Choose File <span class="star">*</span></label>
                        <div class="formicon-parent">
                            <input type="file"  class="form-control frm-input-1" name="signature" id="signature"  required>
                        </div>
                        <br>
                        <div class="form-group margin-1 ml-3">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="check" name="authorize" required>
                                <label class="form-check-label mt-2" for="inlineCheckbox1" style="font-weight: bold;
    font-style: italic;
    font-size: 16px;
">I authorize Moonlight Examinations, LLC to attach this uploaded signature to my completed exam reports.</label>
                            </div>
                        </div>
                        <div class="form-group mb-1">
                            <div class="formicon-parent text-center">
                                <button type="submit" class="btn-main">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>

    // To get Actual address based on location
    $(document).on('submit','#uploadSignatureForm', function (e) {

        e.preventDefault();
        let formdata = new FormData($('#uploadSignatureForm')[0]);
        formdata.append('_token',"{{ csrf_token() }}");

        $.ajax({
            url: "{{ route('post.uploadSignature')}}",
            type: "POST",
            enctype:"multipart/form-data",
            data:formdata,
            cache : false,
            processData: false,
            contentType: false,
            beforeSend:function() {
                swal({
                    icon: "{{ url('/assets/images/loader.gif') }}",
                    text: 'Please Wait...',
                    buttons:false,
                    closeOnClickOutside: false
                });
            },
            success:function(output) {
                
                swal.close();

                if (output.status) {
                    swal({
                        title: "Great!",
                        text: output.msg,
                        icon: "success",
                        closeOnClickOutside: false
                    });
                    $('#uploadSignatureForm')[0].reset();
                } else {
                    swal({
                        title: "Oops!",
                        text: output.msg,
                        icon: "error",
                        closeOnClickOutside: false
                    });
                }
                
            },
            error:function (jqXHR, textStatus, errorThrown) {
                if (jqXHR.status == 500) {
                    console.log('500 status');
                } else {
                    console.log('something went wrong!');
                }
            },
        });

    });

</script>
@endsection