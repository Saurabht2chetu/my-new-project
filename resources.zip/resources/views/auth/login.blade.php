<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
   <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    <!-- FONT  -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
    <div class="container-fluid login-wrapper">
        <div class="container">
            <div class="row justify-content-center align-items-center">
                <!-- <div class="col-lg-4 col-md-3"></div> -->
                <!-- <div class="col-lg-6 col-md-6"> -->
                    <!-- Login Section Starts -->
                    <div class="login-box col-lg-6 col-md-8 col-sm-10 col-12">
                        <div class="logo text-center">
                            <img src="{{ asset('assets/images/logo.png') }}" alt="" class="img-fluid">
                        </div>
                        <div class="login-form">

                            @error('err')
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <strong>{{ $message }}</strong> 
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            @enderror
                            <form action="{{ route('login') }}" method="POST">
                                 @csrf
                                <div class="form-group margin-1">
                                    <label for="exampleInputEmail1">Email or User Id <span class="star">*</span></label>
                                    <div class="formicon-parent">
                                        <span><i class="fas fa-user input-icon-left"></i></span>
                                        <input type="text" class="form-control frm-input-1" placeholder="Enter Your User Id" value="{{ old('email') }}" autofocus name="email" required>

                                        @error('email')
                                        
                                            <span class="invalid-feedback" role="alert">
                                                <strong>{{ $message }}</strong>
                                            </span>
                                        @enderror
                                    </div>

                                </div>
                                <div class="form-group margin-1">
                                    <label for="exampleInputEmail1">Password <span class="star">*</span></label>
                                    <div class="formicon-parent">
                                        <span><i class="fas fa-lock input-icon-left"></i></span>
                                        <input type="password" class="form-control frm-input-1" placeholder="Password" name="password" required autocomplete="current-password">
                                        <span><i class="far fa-eye-slash input-icon-right aw"></i></span>
                                    </div>

                                    @error('password')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror

                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-6 col-6">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox"  name="remember" id="gridCheck" {{ old('remember') ? 'checked' : '' }}>
                                            <label class="form-check-label font-14" for="gridCheck">
                                              Remember me
                                            </label>
                                          </div>
                                    </div>
                                   
                                  </div>
                                    <div class="form-group margin-1">
                                      <div class="formicon-parent">
                                       <button type="submit" class="btn btn-block login-btn-01">LOGIN</button><span><i class="fas fa-arrow-right login-icon-right arr"></i></span>
                                      </div>
                                    </div>
                                    <div class="for-pass">
                                        <div class="form-row">
                                        <div class="form-group col-md-6 col-6">
                                            <p class="text-left font-14"><a href="forget-password.html" class="link-01">Forgot Password ?</a></p>
                                        </div>
                                        <div class="form-group col-md-6 col-6">
                                            <p class="text-right font-14"><a href="/forget-password.html" class="link-01">Forgot User Id ?</a></p>
                                        </div>
                                        </div>
                                    </div>
                            </form>
                        </div>
                    </div>
                    <!-- Login Section Ends -->
                </div>
                <!-- <div class="col-lg-4 col-md-3"></div> -->
            </div>
        </div>
    </div>





<!-- Bootstrap Js -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <!-- Bootstrap Js Ends -->
</body>
</html>