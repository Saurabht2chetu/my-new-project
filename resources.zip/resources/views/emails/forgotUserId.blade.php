<!DOCTYPE html>
<html>
    <body style="background: #f6f6f6;margin: 0; padding: 0;">
      <table width="600" border="0" cellpadding="0" cellspacing="0" style="width: 600px; margin: 0 auto;">
         <tbody>
            <tr>
               <td align="center" style="background:#fff; padding: 20px 0px 20px 0px;"><img src="{{ asset('assets/images/logo.png') }}"></td>
            </tr>
            <!-- <tr>
               <td><img width="600" src="https://eservices.ju.edu.jo/juresetpassword/hanadi/ban2.jpg"></td>
            </tr> -->
            <tr>
               <td>
                  <table width="600" border="0" cellpadding="0" cellspacing="0" style="width: 600px; margin: 0 auto; background: #fdfdfd;">
                     <tr>
                        <td style="height:20px"></td>
                     </tr>
                     <tr>
                        <td style="font-size: 30px; font-family: arial; font-weight: bold; text-align: center;">Dear <span style="color: #e2b910;">{{$name}}</span></td>
                     </tr>
                     <tr>
                        <td style="font-size: 16px;font-family: arial;font-weight: normal;text-align: center;color: #3e3e3e;padding-top: 5px!important;
                           font-style: italic;">As you requested to get your User Id. Here is the details of your User Id.</td>
                     </tr>
                    
                     <tr>
                        <td style="height:30px"></td>
                     </tr>
                     <tr>
                        <td>
                            <table width="600" border="0" cellpadding="0" cellspacing="0" style="width: 300px; margin: 0 auto; background: #ffffff;">
                                <tr>
                                    <td style="font-family: arial;border: 1px solid #dedede;padding: 10px;background: #e2b910;color: #fff;font-size: 14px;font-weight: normal;
                                "><b>User Id</b></td>
                                    <td style="font-family: arial;border-left:0px; border: 1px solid #dedede;padding: 10px;background: #ffffff;color: #000;font-size: 14px;font-weight: normal;
                                    ">{{$user_id}}</td>
                                </tr>
                            </table>
                        </td>
                     </tr>
                     <tr>
                        <td style="height:30px"></td>
                     </tr>
                  </table>
               </td>
            </tr>
         </tbody>
         <tfoot style="background: #01103a; height: 50px;">
            <tr>
               <td align="center" style="color: #fff;font-family: arial;">© moonlight</td>
            </tr>
         </tfoot>
      </table>
   </body>
</html>