<!DOCTYPE html>
<html>
    <body style="background: #f6f6f6;margin: 0; padding: 0;">
      <table width="600" border="0" cellpadding="0" cellspacing="0" style="width: 600px; margin: 0 auto;">
         <tbody>
            <tr>
               <td align="center" style="background:#fff; padding: 20px 0px 20px 0px;"><img src="{{ asset('assets/images/logo.png') }}"></td>
            </tr>
           
            <tr>
               <td>
                  <table width="600" border="0" cellpadding="0" cellspacing="0" style="width: 600px; margin: 0 auto; background: #fdfdfd;">
                     <tr>
                        <td style="height:20px"></td>
                     </tr>
                     <tr>
                        <td style="font-size: 30px; font-family: arial; font-weight: bold; text-align: center;">Dear <span style="color: #e2b910;">{{$name}}</span></td>
                     </tr>
                     <tr>
                        <td style="height:30px"></td>
                     </tr>
                     <tr>
                        <td style="font-size: 16px;font-family: arial;font-weight: normal;text-align: center;color: #3e3e3e;padding-top: 5px!important;
                           font-style: italic;">You have successfully changed your password.</td>
                     </tr>
                    
                     <tr>
                        <td style="height:30px"></td>
                     </tr>
                  </table>
               </td>
            </tr>
         </tbody>
         <tfoot style="background: #01103a; height: 50px;">
            <tr>
               <td align="center" style="color: #fff;font-family: arial;">© moonlight</td>
            </tr>
         </tfoot>
      </table>
   </body>
</html>