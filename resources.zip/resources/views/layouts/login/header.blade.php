<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
<!-- FontAwesome -->
<!-- <link rel="stylesheet" href="{{ asset('assets/css/fontawesome.css') }}" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous"> -->


<!-- FontAwesome -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    <!-- FONT  -->

<!-- FONT  -->
<link href="{{ asset('assets/css/fonts.googleapis.css') }}" rel="stylesheet">
<!-- Bootstrap -->
<link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}">
<link rel="icon" href="{{ asset('assets/images/favicon.png') }}">

<script src="{{ asset('assets/js/jquery.min.js') }}"></script>
<script src="{{ asset('assets/js/validate.min.js') }}"></script>
<!-- <script src="{{ asset('assets/js/sweetalert.min.js') }}"></script> -->