@extends('layouts.loginlayout')
@section('title','Login - Moonlight Examinations')

@section('content')
<div class="login-form">
<style>
    .invalid-feedback{
        display:block!important;
    }
    /*for adding footer logo infornt of forget password  */

    .seal_logo img{
       width: 80px;
       margin: -15px 0 0 0;
    }

    @media (max-width:576px){
         .seal_logo img{
           width: 50px;
           margin: 0 0 0 0;
        }
    }

    /* end */
</style>
    @error('err')
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>{{ $message }}</strong> 
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div>
    @enderror
    @if(session('status'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>{{ session('status') }}</strong> 
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div>
    @endif
    <form action="{{ route('login') }}" method="POST">
       @csrf
       
       <div class="form-group margin-1">
        <label for="exampleInputEmail1">Email Id <span class="star">*</span></label>
        <div class="formicon-parent">
            <span><i class="fas fa-user input-icon-left"></i></span>
            <input type="email" class="form-control frm-input-1" maxlength="40" placeholder="Enter Your Email Id" value="<?php if(old('email')) {echo old('email');}else { if(\Cookie::get('username') !== false && \Cookie::get('username') != '') { echo \Cookie::get('username'); }}?>"  autofocus name="email" required>

            @error('email')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
            @enderror
           
        </div>

    </div>
    <div class="form-group margin-1">
        <label for="exampleInputEmail1">Password <span class="star">*</span></label>
        <div class="formicon-parent">
            <span><i class="fas fa-lock input-icon-left"></i></span>
            <input type="password" maxlength="40" class="form-control frm-input-1" value="<?php if(\Cookie::get('user_pass') !== false && \Cookie::get('user_pass') != '') {echo \Cookie::get('user_pass'); } ?>" placeholder="&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;&#9679;" name="password" id="loginPassword" required autocomplete="current-password">
            <!-- <span><i class="far fa-eye-slash input-icon-right aw"></i></span> -->
            <span class="input-group-btn" id="eyeSlash">
            <i class="fa fa-eye-slash input-icon-right aw" onclick="visibility()" aria-hidden="true"></i>
            </span>
            <span class="input-group-btn" id="eyeShow" style="display: none;">
            <i class="fa fa-eye input-icon-right aw" onclick="visibility()" aria-hidden="true"></i>
            </span>
        </div>

        @error('password')
        <span class="invalid-feedback" role="alert">
            <strong>{{ $message }}</strong>
        </span>
        @enderror

    </div>
    <div class="form-row">
        <div class="form-group col-md-6 col-6">
            <div class="form-check">
                <input class="form-check-input" type="checkbox"  name="remember" id="gridCheck" {{ old('remember') ? 'checked' : '' }} <?php if(\Cookie::get('user_pass') !== false && \Cookie::get('user_pass') != '') { echo "checked";} ?> >
                <label class="form-check-label font-14" for="gridCheck">
                  Remember me
              </label>
          </div>
      </div>

  </div>
  <div class="form-group margin-1">
      <div class="formicon-parent">
         <button type="submit" class="btn btn-block login-btn-01">LOGIN</button><span><i class="fas fa-arrow-right login-icon-right arr"></i></span>
     </div>
 </div>
 <div class="for-pass">
    <div class="form-row">
        <!-- <div class="form-group col-md-6 col-6">
            <p class="text-left font-14"><a href="{{ url('auth/forgot-userid')}}" class="link-01">Forgot User Id?</a></p>
        </div> -->
        <div class="form-group col-md-6 col-6 seal_logo mb-0">
          <a href="{{ url('/')}}">
            <img src="{{ asset('assets/images/seal_logo.webp') }}">
           </a>
        </div>
        <div class="form-group col-md-6 col-6 mb-0">
            <p class="text-right font-14"><a href="{{ url('auth/forgot-password')}}" class="link-01">Forgot Password?</a></p>
        </div>
    </div>
</div>
</form>
</div>
@endsection

<script type="text/javascript">
function visibility() {
  var x = document.getElementById('loginPassword');
  if (x.type === 'password') {
        x.type = "text";
        $('#eyeShow').show();
        $('#eyeSlash').hide();
  } else {
        x.type = "password";
        $('#eyeShow').hide();
        $('#eyeSlash').show();
  }
}
</script>