<?php
use App\Models\Roles;

$roleInfo = Roles::find(Auth::user()->role_id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>@yield('title')</title>

    @include('layouts.header-script')

</head>
<body>
    <div class="db-wrapper">

        @include('layouts.sidebar')

        <!-- Side Nav Ends -->

        <!-- Header Starts -->
        <header>
            <div class="db-sidenav-ticon" id="dbtoggleicon">
                <i class="fas fa-ellipsis-v"></i>
            </div>
            <div class="db-header-wrapper">
                <div class="db-header">
                    <div class="db-header-logo">
                        <img src="{{ asset('assets/images/logo.png') }}" alt="" class="img-fluid">
                    </div>
                </div>
                <div class="db-user">
                    @guest
                    @else
                    <div class="db-user-text">
                    <p class="db-user-name">Hi  {{ Auth::user()->name }} <span class="db-name">({{ $roleInfo->name }})</span></p>
                    <p style="font-size:12px;text-align:center;">({{ Auth::user()->email }})</p>
                       

                       
                    </div>
                    <div class="db-user-image dropdown">
                        <a href="" id="dropdownMenuButton"  data-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false">
                            <!-- <img src="{{ asset('assets/images/placeholder.jpg') }}" alt="" class="img-fluid"> -->
                            <span class="imageCircle">
                                @foreach(explode(' ', Auth::user()->name) as $fields)
                                    <span class="imageText">{{ substr($fields, 0, 1)}}</span>
                                @endforeach
                            </span>
                            <span class="dd-user dd-icon ml-2"><i class="fas fa-chevron-down"></i></span>
                            
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                               
                                <a class="dropdown-item" href="{{route('change.password.get')}}">Change Password</a>
                                @if (Auth::user()->role_id == $_ENV['EXAMINER_ROLE_ID']) 
                                <a class="dropdown-item" href="{{ route('view.examinerSignature') }}">Upload Signature</a>
                                @endif
                                <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">Logout</a> 
                                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                    @csrf
                                </form>
                            </div>
                        </a>
                    </div>
                    @endguest
                </div>
            </div>
        </header>


        <div id="main">

            @yield('content')
        </div>
    </div>

    @include('layouts.footer')

</body>
</html>