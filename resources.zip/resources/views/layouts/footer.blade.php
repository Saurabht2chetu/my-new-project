<!-- Bootstrap Js Starts -->
<!-- <script src="{{ asset('assets/js/jquery-3.2.1.slim.min.js') }}"></script> -->
<script src="{{ asset('assets/js/popper.min.js') }}"></script>
<script src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
<!-- Bootstrap Js Ends -->

<!--jquery data table -->
<script src="{{ asset('assets/js/jquery.dataTables.min.js') }}"></script>

<!-- barchart -->
<script type="text/javascript" src="{{ asset('assets/js/jsapi-loader.js') }}"></script>

<!-- Main Js from File -->
<script src="{{ asset('assets/js/main.js') }}"></script>

<script>
    $('.modal').attr('data-keyboard','false');
    $('.modal').attr('data-backdrop','static');
</script>
