@extends('layouts.adminlayout')
@section('title','State ERE Management - Moonlight Examinations')

@section('content')
<style>
    .swal-icon--custom img {
        width:50px!important;
        height:50px!important;
    }
    .swal-modal .swal-text {
        text-align: center;
    }
    .swal-footer {
        text-align: center!important;
    }
    .input-icon-right {
        cursor: pointer;
    }
    .activesection input[type="checkbox"] {
        visibility: hidden;
    }
    .activesection label {
        cursor: pointer;
        text-indent: -9999px;
        width: 40px;
        height: 20px;
        background: grey;
        display: block;
        border-radius: 100px;
        position: relative;
    }
    .activesection label:after {
        content: '';
        position: absolute;
        top: 3px;
        left: 2px;
        width: 15px;
        height: 15px;
        background: #fff;
        border-radius: 90px;
        transition: all 0.3s;
    }
    .activesection input:checked + label {
        background: #ffc107;
    }
    .activesection input:checked + label:after {
        left: calc(100% - 5px);
        transform: translateX(-100%);
    }
    .activesection label:active:after {
        width: 130px;
    }

</style> 
<div class="container-fluid">
    <div class="db-top4-box-wrapper">
        <div class="mt-3 hm-dis">
            <p class="db-heading"><a href="{{ route('dashboard') }}">Dashboard</a> / State ERE Management</p>
           @if($action)
            <button class="btn-main" data-toggle="modal" data-target="#stateAddModal"><i
                    class="fas fa-plus"></i> Add</button>
            @endif
        </div>
        @if (session('status'))
            <div class="alert alert-success" role="alert">
                {{ session('status') }}
            </div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger" role="alert">
                {{ session('error') }}
            </div>
        @endif

        <!-- Add Modal Form starts -->
        <div class="modal fade md-round" id="stateAddModal" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="p-3">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="login-form">
                            <div class="text-center mb-4">
                                <h4>Add ERE State</h4>
                            </div>
                            <form method="POST" id="addStateForm">
                                <div class="form-group">
                                <label for="add_stateName">State Name <span class="text-danger">*</span> </label>
                                    <div class="formicon-parent">
                                       
                                        <span><i class="fas fa-user input-icon-left"></i></span>
                                        <input type="text" maxlength="50" name="stateName" class="form-control frm-input-1" placeholder="State Name" id="add_stateName" required>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="add_stateCode">State Abbreviation <span class="text-danger">*</span> </label>
                                        <div class="formicon-parent">
                                            <span><i class="fas fa-user input-icon-left"></i></span>
                                            <input type="text" maxlength="10" name="stateCode" class="form-control frm-input-1" id="add_stateCode" placeholder="State Abbreviation" required>
                                        </div>
                                    </div>
                                    <!-- <div class="form-group col-md-6">
                                        <div class="formicon-parent">
                                            <span><i class="fas fa-user input-icon-left"></i></span>
                                            <input type="text" name="standard" class="form-control frm-input-1" placeholder="State Standard">
                                        </div>
                                    </div> -->
                                </div>
                                <div class="form-group">
                                    <label for="add_invoiceExtraction">invoice Extraction Rules </label>
                                    <div class="formicon-parent">
                                        <span><i class="fas fa-user input-icon-left"></i></span>
                                        <input type="text" name="invoiceExtraction" class="form-control frm-input-1" id="add_invoiceExtraction" placeholder="invoice Extraction Rules">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="add_userName">ERE User Name</label>
                                    <div class="formicon-parent">
                                        <span><i class="fas fa-id-card input-icon-left"></i></span>
                                        <input type="text" maxlength="40" class="form-control frm-input-1"
                                            placeholder="ERE User Name" id="add_userName" name="userName" autocomplete="off" >
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="passwordField">ERE Password</label>
                                    <div class="formicon-parent">
                                        <span><i class="fas fa-key input-icon-left"></i></span>
                                        <input type="password" maxlength="40" name="password" class="form-control frm-input-1" placeholder="ERE Password" id="passwordField">
                                        <span><i class="far fa-eye-slash input-icon-right aw" onclick="return visibility('passwordField',this);"></i></span>
                                    </div>
                                    @error('password')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                               
                                <div class="form-group">
                                    <div class="formicon-parent">
                                        <button type="submit"
                                            class="btn btn-block login-btn-01">SUBMIT</button><span><i
                                                class="fas fa-arrow-right login-icon-right arr"></i></span>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Add Modal Form End -->

        <!-- Edit Modal Form starts -->
        <div class="modal fade md-round" id="stateEditModal" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="p-3">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="login-form">
                            <div class="text-center mb-4">
                                <h4>Edit ERE State</h4>
                            </div>
                            <form method="POST" id="editStateForm">
                            @csrf
                            <input type="hidden" name="idval" id="idval" value="">
                                <div class="form-group">
                                <label for="exampleInputEmail1">State Name <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <span><i class="fas fa-user input-icon-left"></i></span>
                                        <input type="text"  maxlength="50" name="stateName" id="stateName" class="form-control frm-input-1" placeholder="State Name" required>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                    <label for="exampleInputEmail1">Abbreviation <span class="text-danger">*</span></label>
                                        <div class="formicon-parent">   
                                            <span><i class="fas fa-user input-icon-left"></i></span>
                                            <input type="text" maxlength="10" name="stateCode" id="stateCode" class="form-control frm-input-1" placeholder="State Abbreviation" required>
                                        </div>
                                    </div>
                                    <!-- <div class="form-group col-md-6">
                                    <label for="exampleInputEmail1">Standard</label>
                                        <div class="formicon-parent">
                                            <span><i class="fas fa-user input-icon-left"></i></span>
                                            <input type="text" name="standard" id="standard" class="form-control frm-input-1" placeholder="State Standard">
                                        </div>
                                    </div> -->
                                </div>
                                <div class="form-group">
                                <label for="exampleInputEmail1">Invoice Extraction Rules</label>
                                    <div class="formicon-parent">
                                        <span><i class="fas fa-user input-icon-left"></i></span>
                                        <input type="text" name="invoiceExtraction" id="invoiceExtraction" class="form-control frm-input-1" placeholder="invoice Extraction Rules">
                                    </div>
                                </div>
                                <div class="form-group">
                                <label for="exampleInputEmail1">ERE User Name</label>
                                    <div class="formicon-parent">
                                        <span><i class="fas fa-id-card input-icon-left"></i></span>
                                        <input type="text" maxlength="40" class="form-control frm-input-1"
                                            placeholder="ERE User Name" name="userName" id="userName" autocomplete="off" >
                                    </div>
                                </div>
                                <div class="form-group">
                                <label for="exampleInputEmail1">ERE Password</label>
                                    <div class="formicon-parent">
                                        <span><i class="fas fa-key input-icon-left"></i></span>
                                        <input type="password" maxlength="40" name="password" class="form-control frm-input-1" placeholder="ERE Password" id="editPasswordField">
                                        <span><i class="far fa-eye-slash input-icon-right aw" onclick="return visibility('editPasswordField',this);"></i></span>
                                    </div>
                                    @error('password')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                               
                                <div class="form-group">
                                    <div class="formicon-parent">
                                        <button type="submit"
                                            class="btn btn-block login-btn-01">UPDATE</button><span><i
                                                class="fas fa-arrow-right login-icon-right arr"></i></span>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Edit Modal Form End -->


    </div>
    <div class="dashboard-table1">
        <div class="row">
            <div class="col-md-12">
                <table id="" class="stripe state-table" style="width:100%">
                    <thead>
                        <tr>
                            <th width="3%">Status</th>
                            <th>Name</th>
                            <th>Abbreviation</th>
                            <th>Invoice Rule</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    $(function () {
        // Fetch all states data
        var resultTable = $('.state-table').DataTable({
                processing: true,
                serverSide: false,
                order: [],
                "language": {
                    "processing": "<img style='width:80px; height:80px;' src='{{url('/assets/images/loaderspinner.gif')}}' >"
                },
                ajax: "{{ route('state-ere-management') }}",
                columns: [
                    {data: 'activeInactive', name: 'activeInactive', orderable: false, searchable: false},
                    {data: 'name', name: 'name'},
                    {data: 'code', name: 'code'},
                    {data: 'invoice_extraction', name: 'invoice_extraction', orderable: true, searchable: true},
                    {data: 'action', name: 'action', orderable: false, searchable: false},
                ]
            });
        
        //custom validation method for ERE user name
        jQuery.validator.addMethod("userNameValidate", function(value, element) {
            
            if(value != '') {
                return value.length > 40 ? false : true; 
            }
            return true; 
        }, "Enter between 1-40 character");

        //custom validation method for ERE user password
        jQuery.validator.addMethod("userpasswordValidate", function(value, element) {
            
            if(value != '') {
                return value.length > 40 ? false : true; 
            }
            return true; 
        }, "Enter between 1-40 character");

        //custom validation method for ERE user password
        jQuery.validator.addMethod("extractionRule", function(value, element) {
           
            if (value != '') {
                console.log({value, element})
               
                let len = value.length-1;
                if (value.indexOf(',') == 0 || value.lastIndexOf(',') == len) {
                
                    return false;
                } else if (element.dataset.charcode == undefined) {
                    return true;
                } else if (parseInt(element.dataset.charcode) > 48 && parseInt(element.dataset.charcode) <= 57) {
                    return true;
                }              
            }
            return true; 
        }, "Enter valid invoice extration rules,example-(1,2,3)");

        //
        jQuery.validator.addMethod("lettersonly", function(value, element) {
            return this.optional(element) || /^[a-z\s]+$/i.test(value);
        }, "Only alphabetical characters");
        
        $('input[name="invoiceExtraction"]').on('keypress',function(e) {
                e.target.dataset.charcode = e.charCode;
                if(e.which == 32) {
                    e.preventDefault();
                }
               
               
        });
        // Add validation on state form fields
        $("#addStateForm").validate({

            rules: {
                stateName:{
                    required:true,
                    maxlength:50,
                    lettersonly:true
                },
                stateCode:{
                    required:true,
                    maxlength:10,
                    lettersonly:true
                },
                userName: {
                    userNameValidate:true
                },
                password:{
                    userpasswordValidate:true
                },
                invoiceExtraction:{
                    extractionRule:true
                }
            },

            messages: {
                stateName:{
                    required:"State Name is required",
                    maxlength:"Enter State Name between 1-50 character"
                },
                stateCode:{
                    required:"State Abbreviation is required",
                    maxlength:"Enter State Abbreviation between 1-10 character"
                }
            },

            errorPlacement: function(label, element) {

                label.addClass('mt-2 text-danger');
                label.insertAfter(element);
            },

            highlight: function(element, errorClass) {

                $(element).parent().addClass('has-danger');
                $(element).addClass('form-control-danger');
            },

            unhighlight: function(element, errorClass, validClass) {

                $(element).parents().removeClass('has-danger');
                $(element).removeClass('form-control-danger');
                $(element).parents('.form-group').addClass('has-success');
            }

        });
        // END validation

        // Add validation on state form fields
        $("#editStateForm").validate({

            rules: {
                stateName:{
                    required:true,
                    maxlength:50,
                    lettersonly:true
                },
                stateCode:{
                    required:true,
                    maxlength:20,
                    lettersonly:true
                },
                userName: {
                    userNameValidate:true
                },
                password:{
                    userpasswordValidate:true
                },
                invoiceExtraction:{
                    extractionRule:true
                }
                
            },
            messages: {
                stateName:{
                    required:"State Name is required",
                    maxlength:"Enter State Name between 1-50 character"
                },
                stateCode:{
                    required:"State Abbreviation is required",
                    maxlength:"Enter State Abbreviation between 1-20 character"
                }
            },
            errorPlacement: function(label, element) {
                label.addClass('mt-2 text-danger');
                label.insertAfter(element);
            },
            highlight: function(element, errorClass) {
                $(element).parent().addClass('has-danger');
                $(element).addClass('form-control-danger');
            },

            unhighlight: function(element, errorClass, validClass) {
                $(element).parents().removeClass('has-danger');
                $(element).removeClass('form-control-danger');
                $(element).parents('.form-group').addClass('has-success');
            }
            });
            // END Edit State Validation

        // To Add State
        $(document).on('submit', '#addStateForm', function(e){
            e.preventDefault();
            if (!$('#addStateForm').valid()) {
                alert('Something went wrong at time of filling the form');
                return;
            }

            $.ajax({
                url:"{{ url('add-state') }}",
                type:'POST',
                data:$(this).serialize() + '&_token='+"{{ csrf_token() }}",
                beforeSend:function() {
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    
                    });
                },
                success:function(data){
                    swal.close();
                    if (data.status == true) {

                        $('#stateAddModal').modal('hide');
                        resultTable.ajax.reload();
                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success",
                        });

                    } else if (data.status == false) {
                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error",
                        });
                    } else {
                        window.location.reload(true);
                    }
                },
                error:function (jqXHR, textStatus, errorThrown) {
                    swal({
                        icon: "error",
                        title:'Oops!',
                        text: 'soemthing went wrong, Response Status Code - '+jqXHR.status,
                        closeOnClickOutside:false
                    });
                    window.location.reload(true);
                },
            });


        });

        // To get state data by State Id
        $(document).on('click','.editbtn', function(){
            
            var id = $(this).attr('data-id');

            $.ajax({
                url:"{{ route('fetchState') }}",
                type:'GET',
                data: {id:id,_token:"{{csrf_token()}}"},
                dataType:'json',
                success:function(output){
                    if (output.status == true) {
                        var data = output.data;
                        $('#stateName').val(data.name);
                        $('#stateCode').val(data.code);
                        $('#standard').val(data.standard);
                        $('#invoiceExtraction').val(data.invoice_extraction);
                        $('#userName').val(data.user_name);
                        $('#editPasswordField').val(data.user_password);
                        $('#idval').val(data.id);
                        $('#stateEditModal').modal('show');
                    } else if (output.status == false) {
                        swal({
                            title: "Oops!",
                            text: output.msg,
                            icon: "error",
                        });
                    } else {
                        window.location.reload(true);
                    }
                },
                error:function (jqXHR, textStatus, errorThrown) {
                    if (jqXHR.status == 500) {
                        console.log('500 status');
                    } else {
                        console.log('something went wrong!');
                    }
                    window.location.reload(true);
                },
            });
        });

        // To update state data by State Id
        $(document).on('submit', '#editStateForm', function(e) {
            e.preventDefault();
            if(!$("#editStateForm").valid()) {
                alert('Something went wrong at time of fill the form');
                return;
            }

            $.ajax({
                url:"{{ route('updateState') }}",
                type:'POST',
                data:$(this).serialize() + '&_token='+"{{ csrf_token() }}",
                beforeSend:function() {
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    });
                },
                success:function(data){
                    swal.close();
                    if (data.status == true) {

                        $('#stateEditModal').modal('hide');
                        resultTable.ajax.reload();
                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success",
                        });

                    } else if (data.status == false) {
                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error",
                        });
                    } else {
                        window.location.reload(true);
                    }
                },
            });
        });

        // To update state data by State Id
        $(document).on('click', '.activesection .inputcheck', function(e){
            e.preventDefault();
            let id = $(this).attr('data-id');
            swal({
                title: "Are you sure?",
                text: "You want to change the status of this ERE State",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                closeOnClickOutside:false
            }).then((changeStatus) => {
                if (changeStatus) {

                    $.ajax({
                        url:"{{ route('update.status') }}",
                        type:'POST',
                        data: {idval:id,status:$(this).val(),_token:"{{ csrf_token() }}"},
                        beforeSend:function() {
                            swal({
                                icon: "{{ url('/assets/images/loader.gif') }}",
                                text: 'Please Wait!',
                                buttons: false,
                                closeOnClickOutside:false
                            });
                        },
                        success:function(data){
                            swal.close();
                            resultTable.ajax.reload();
                            if (data.status == true) {
                            
                                swal({
                                    title: "Great!",
                                    text: data.msg,
                                    icon: "success",
                                });

                            } else if (data.status == false) {
                                swal({
                                    title: "Oops!",
                                    text: data.msg,
                                    icon: "error",
                                });
                            } else {
                                window.location.reload(true);
                            }
                        },
                        error:function (jqXHR, textStatus, errorThrown) {
                            if (jqXHR.status == 500) {
                                console.log('500 status');
                            } else {
                                console.log('something went wrong!');
                            }
                            window.location.reload(true);
                        },
                    });
                } else {

                }
            });
        });

          //this is used to delete the particular state
        $(document).on('click','.deletebtn',function(event){

            let id = $(this).attr('data-id');

            swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this state",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                closeOnClickOutside:false
            }).then((willDelete) => {
                if (willDelete) {
                    
                    $.ajax({
                        url: "{{route('delete.state')}}",
                        type: "POST",
                        data: {idval:id,_token:"{{ csrf_token() }}"},
                        beforeSend:function() {
                            swal({
                                icon: "{{ url('/assets/images/loader.gif') }}",
                                text: 'Please Wait!',
                            
                            });
                        },
                        success:function(data){
                            
                            swal.close();
                            if(data.status) {
                                resultTable.ajax.reload();
                                swal({
                                    title: "Great!",
                                    text: data.msg,
                                    icon: "success",
                                });

                                } else {
                                swal({
                                    title: "Oops!",
                                    text: data.msg,
                                    icon: "error",
                                });
                            }
                        },
                        error:function (jqXHR, textStatus, errorThrown) {
                            if (jqXHR.status == 500) {
                                console.log('500 status');
                            } else {
                                console.log('something went wrong!');
                            }
                        },
                    });

                } else {
                    
                }
            });
        });
            //--------------END delet user functionality----------------------
    });


        function visibility(id,event) {
            
            var x = document.getElementById(id);
            if (x.type === 'password') {
                    x.type = "text";
                    $(event).removeClass('fa-eye-slash');
                    $(event).addClass('fa-eye');
            } else {
                    x.type = "password";
                    $(event).removeClass('fa-eye');
                    $(event).addClass('fa-eye-slash');
            }
        }

      
        $(document).on('click','.access_denied',function() {

            swal({
                icon: "error",
                title:'Oops!',
                text: 'You do not have permission to perform this action',
                // buttons: false,
                closeOnClickOutside:false
                
            });
            return false;
        });
       
</script>
@endsection