<?php
// Composer autoloader
require_once __DIR__ . "/../vendor/autoload.php";

// PHP mailer library
use PHPMailer\PHPMailer\PHPMailer;

// Base files
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$msgBody = '<!DOCTYPE html>
        <body>
            <table cellpadding="0" cellspacing="0" border="0" style="margin:0 auto; width:600px; background-color: #f6f6f6; padding: 10px;">
                <tr>
                    <td colspan="2" style="text-align: center;"><img src=""></td>
                </tr>
                <tr>
                    <td colspan="2" style="font-weight: bold;padding: 10px 10px;font-family: arial;">Here are the login credentials : </td>
                </tr>
                <tr>
                    <td style="font-size: 14px;font-weight: bold;padding: 10px 10px;font-family: arial;">User Name</td>
                    <td style="font-size: 14px;font-weight: normal;padding: 10px 10px;font-family: arial;">userNameVariable</td>
                </tr>
                <tr>
                    <td style="font-size: 14px;font-weight: bold;padding: 10px 10px;font-family: arial;">User ID</td>
                    <td style="font-size: 14px;font-weight: normal;padding: 10px 10px;font-family: arial;">userIdvariable</td>
                </tr>
                <tr>
                    <td style="font-size: 14px;font-weight: bold;padding: 10px 10px;font-family: arial;">Password</td>
                    <td style="font-size: 14px;font-weight: normal;padding: 10px 10px;font-family: arial;">123456789</td>
                </tr>

            </table>
        </body>
        </html>';

try {    
    $mail = new PHPMailer(true);
    $mail->isSMTP(); // using SMTP protocol
    $mail->Host       = $_ENV['HOST_NAME']; // SMTP host as gmail
    $mail->SMTPAuth   = $_ENV['SMTP_AUTH']; // enable smtp authentication
    $mail->Username   = $_ENV['USER_NAME']; // sender gmail host
    $mail->Password   = $_ENV['SMTP_PASSWORD']; // sender gmail host password
    $mail->SMTPSecure = $_ENV['SMTP_SECURE']; // for encrypted connection
    $mail->Port       = $_ENV['SMTP_PORT']; // port for SMTP
    $mail->setFrom($_ENV['USER_NAME'], $_ENV['SENDER_NAME']); // sender's email and name
    $mail->addAddress('yogeshs5@chetu.com', "Receiver"); // receiver's email and name
    $mail->Subject = 'Account created on MoonlightExaminations';
    $mail->Body    = $msgBody;
    $mail->IsHTML(true);

    $mail->send();
    echo 'Message has been sent';

} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    die;
}
?>