@extends('layouts.adminlayout')
@section('title','Examinee Management - Moonlight Examinations')

@section('content')
<style>

    table.dataTable tbody th, table.dataTable tbody td {
        white-space: nowrap;
    }
    #stickycontent .table td, .table th,#callcontent .table td, .table th {
        padding: 0.75rem;
        vertical-align: middle!important;
        text-align: left !important;
    }

    .swal-icon--custom img {
        width:50px!important;
        height:50px!important;
    }
  
    table.stripe tr td:nth-child(4) span{
        display: block;
        width:200px;
        word-wrap: break-word;
        white-space: normal;
    }
    table.stripe tr td:nth-child(4) {
        word-wrap: break-word;
        white-space: normal;
        width:200px;
        min-width: 200px;
    }

</style>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />

<div class="container-fluid">
    
    <div class="db-top4-box-wrapper">
        <div class="my-3 hm-dis">
            <p class="db-heading m-0">@if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID'])
                <a href="{{ route('dashboard') }}">Dashboard / </a> @endif
                <a class="db-heading" href="{{ route('clinic-list'); }}">Clinic List</a>
            </p>

           
            
         
        </div>
       
        <div class="dashboard-table1">
            <div class="p-form">
            <h4> Current Changes</h4>
            <div class="table-responsive current_section">

              
                <table id="" class="table table-bordered" style="width:100%">
            
                    <thead>
                        <tr>
                        <th>Examinee Name</th>
                        <th>Phone</th>
                        <th>DOB</th>
                        
                       
                        
                     
                        </tr>
                    </thead>
                    <tbody>
                  
                      <tr>
                      <td>{{$currentPatientRecord->first_name}}</td>
                      <td>{{$currentPatientRecord->phone}}</td>
                      <td>{{$currentPatientRecord->dob}}</td>

                   
                      </tr>
                   
                    </tbody>
                  
                </table>
                </div>

           <h4> History Records</h4>
            <table id="" class="table" style="width:100%">
            
                    <thead>
                        <tr>
                       
                       
                        <th>Examinee Name</th>
                            
                            <th>DOB</th>
                            <th>Phone</th>
                            <th>Updated By</th>
                         
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($patientRecord as $list)
                   
                      <tr>
                    
                      <td>{{$list->first_name}}</td>
                   
                      <td>{{ $list->dob }}</td>
                      
                      <td>{{ $list->phone }}</td>
                      <td>{{ $list->name }}</td>
                   
                      <!-- <td>{{ $list->updated_by }}</td> -->
                         
                   
                    </tr>
                    @endforeach 
                    
                  
                    </tbody>
                  
                </table>
                

            </div>
        </div>

      

    
    </div>
   
    
</div>

    <!-- cdn link of select2 jquery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.1/moment.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.0/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.13.0/jquery-ui.js"></script>

    <script src="{{ asset('assets/js/jquery-input-mask-phone-number.js') }}" ></script>

    
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>

<script type="text/javascript" src="https://cdn.ckeditor.com/4.5.11/standard/ckeditor.js"></script>

@endsection