@extends('layouts.adminlayout')
@section('title','Examinee Management - Moonlight Examinations')

@section('content')
<style>

    table.dataTable tbody th, table.dataTable tbody td {
        white-space: nowrap;
    }
    #stickycontent .table td, .table th,#callcontent .table td, .table th {
        padding: 0.75rem;
        vertical-align: middle!important;
        text-align: left !important;
    }

    .swal-icon--custom img {
        width:50px!important;
        height:50px!important;
    }
  
    table.stripe tr td:nth-child(4) span{
        display: block;
        width:200px;
        word-wrap: break-word;
        white-space: normal;
    }
    table.stripe tr td:nth-child(4) {
        word-wrap: break-word;
        white-space: normal;
        width:200px;
        min-width: 200px;
    }

</style>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />

<div class="container-fluid">
    
    <div class="db-top4-box-wrapper">
        <div class="my-3 hm-dis">
            <p class="db-heading m-0">@if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID'])
                <a href="{{ route('dashboard') }}">Dashboard / </a> @endif
                <a class="db-heading" href="{{ route('clinic-list'); }}">Clinic List</a>
            </p>

           
            
         
        </div>
        <div class="dashboard-table1">
            <div class="p-form">
           <strong> History Records</strong>
            <table id="" class="table" style="width:100%">
            
                    <thead>
                        <tr>
                        <th>Broken kept</th>
                        <th>Examinee Name</th>
                        <th>Updated By</th>
                            <th>Appt. Time</th>
                            
                            <th>Special Request</th>
                            <?php if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID']) { ?>
                            <!-- <th>Request Status</th> -->
                            <?php } ?>
                            <th>Case Id </th>
                            <th>DOB</th>
                            <th>Phone</th>
                         
                                <th>Exam Type </th>
                               
                                <th>Invoice</th>
                                <th>Records</th>
                            <th>Updated Time</th>
                     
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($historyRecord as $list)
                      <tr>
                      <td>{{$list->status}}</td>
                      <td>{{$list->first_name}}</td>
                      <td>{{$list->user_name}}</td>
                      <td>{{$list->service_time}}</td>
                      <td> {!! $list->special_instruction !!}</td>
                      <td>{{ $list->case_id }}</td>
                      <td>{{ $list->patient_dob }}</td>
                      
                      <td>{{ $list->patient_phone }}</td>
                      <td>{{ $list->type_of_exam }}</td>
                     
                      <td>
                        <!-- <a href="{{ route('pdfviewer',['url' => $list->invoice_url]) }}" target="_blank">view</a><br> -->
                        
                        @if($list->invoice_update != 0) 
                        
                        {{ __('Invoice is updated') }}
                          @endif
                          
                      </td>  
                    
                   <td> 
                  
                   @if($list->record_update != '0')  
                   {{ __('Record is updated') }}
                  
                    @endif
                    
                    </td>
                    <td>{{ $list->created_at }}</td>
                    </tr>
                    @endforeach 
                    </tbody>
                  
                </table>
                <strong> Current Changes</strong>
            <table id="" class="table" style="width:100%">
            
                    <thead>
                        <tr>
                        <th>Broken kept</th>
                        <th>Examinee Name</th>
                       
                            <th>Appt. Time</th>
                            
                            <th>Special Request</th>
                            <?php if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID']) { ?>
                            <!-- <th>Request Status</th> -->
                            <?php } ?>
                            <th>Case Id </th>
                            <th>DOB</th>
                            <th>Phone</th>
                         
                                <th>Exam Type </th>
                               
                                <th>Invoice</th>
                                <th>Records</th>
                            <th>Updated Time</th>
                     
                        </tr>
                    </thead>
                    <tbody>
                    @foreach($currentRecord as $currentlist)
                      <tr>
                      <td>{{$currentlist->status}}</td>
                      <td>{{$currentlist->patient_name}}</td>
                     
                      <td>{{$currentlist->service_time}}</td>
                      <td>{!! $currentlist->special_instruction !!}</td>
                      <td>{{ $currentlist->case_id }}</td>
                      <td>{{ $currentlist->dob }}</td>
                      <td>{{ $currentlist->patient_phone }}</td>
                      <td>{{ $currentlist->type_of_exam}}</td>
                      <td>
                      
                        @if($currentlist->invoice_update != 0) 
                        {{ __('Invoice is updated') }}
                          @endif
                      </td>
                      <td>
                       
                        @if($currentlist->record_update != '0')  
    <td>Record is updated.</td>
    @endif
                      </td>
                     
                      <td>{{ $currentlist->created_at }}</td>
                      </tr>
                    @endforeach 
                    </tbody>
                  
                </table>

            </div>
        </div>

      

    
    </div>
   
    
</div>

    <!-- cdn link of select2 jquery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.1/moment.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.0/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.13.0/jquery-ui.js"></script>

    <script src="{{ asset('assets/js/jquery-input-mask-phone-number.js') }}" ></script>

    
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>

<script type="text/javascript" src="https://cdn.ckeditor.com/4.5.11/standard/ckeditor.js"></script>

@endsection