@extends('layouts.adminlayout')
@section('title','Examinee Management - Moonlight Examinations')

@section('content')
<style>

    table.dataTable tbody th, table.dataTable tbody td {
        white-space: nowrap;
    }
    #stickycontent .table td, .table th,#callcontent .table td, .table th {
        padding: 0.75rem;
        vertical-align: middle!important;
        text-align: center !important;
    }

    .swal-icon--custom img {
        width:50px!important;
        height:50px!important;
    }
    .swal-modal .swal-text {
        text-align: center;
    }
    .swal-footer {
        text-align: center!important;
    }
    .input-icon-right {
        cursor: pointer;
    }
    .activesection input[type="checkbox"] {
        visibility: hidden;
    }
    .activesection label {
        cursor: pointer;
        text-indent: -9999px;
        width: 40px;
        height: 20px;
        background: grey;
        display: block;
        border-radius: 100px;
        position: relative;
    }
    .activesection label:after {
        content: '';
        position: absolute;
        top: 3px;
        left: 2px;
        width: 15px;
        height: 15px;
        background: #fff;
        border-radius: 90px;
        transition: all 0.3s;
    }
    .activesection input:checked + label {
        background: #ffc107;
    }
    .activesection input:checked + label:after {
        left: calc(100% - 5px);
        transform: translateX(-100%);
    }
    .activesection label:active:after {
        width: 130px;
    }

    .select2-container {
        width: 100%!important;
        /* font-size: 1rem;
        line-height: 1.5;
        color: #495057;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid #ced4da;
        border-radius: 10px!important; */
        transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;

    }

    .select2-results__option {
        padding-right: 20px;
        vertical-align: middle;
    }
    .select2-results__options[aria-multiselectable=true] .select2-results__option:before {
        content: "";
        display: inline-block;
        position: relative;
        height: 20px;
        width: 20px;
        border: 2px solid #e9e9e9;
        border-radius: 4px;
        background-color: #fff;
        margin-right: 20px;
        vertical-align: middle;
    }
    .select2-results__options[aria-multiselectable=true] .select2-results__option--selected:before {
        font-family:fontAwesome;
        content: "\f00c";
        color: #fff;
        background-color: #e1c331;
        border: 0;
        display: inline-block;
        padding-left: 3px;
        font-size: 14px;
    }
    .select2-results__options[aria-multiselectable=true] .select2-container--default .select2-results__option[aria-selected=true] {
        background-color: #fff;
    }
    .select2-results__options[aria-multiselectable=true] .select2-container--default .select2-results__option--highlighted[aria-selected] {
        background-color: #eaeaeb;
        color: #272727;
    }
    .select2-results__options[aria-multiselectable=true] .select2-container--default .select2-selection--multiple {
        margin-bottom: 10px;
    }
    .select2-results__options[aria-multiselectable=true] .select2-container--default.select2-container--open.select2-container--below .select2-selection--multiple {
        border-radius: 4px;
    }
    .select2-results__options[aria-multiselectable=true] .select2-container--default.select2-container--focus .select2-selection--multiple {
        border-color: #f77750;
        border-width: 2px;
    }
    .select2-results__options[aria-multiselectable=true] .select2-container--default .select2-selection--multiple {
        border-width: 2px;
    }
    .select2-container--open .select2-dropdown--below {
        
        border-radius: 6px;
        box-shadow: 0 0 10px rgba(0,0,0,0.5);

    }
    .select2-selection .select2-selection--multiple:after {
        content: '';
    }
    /* select with icons badges single*/
    .select-icon .select2-selection__placeholder .badge {
        display: none;
    }
    .select-icon .placeholder {
    /* 	display: none; */
    }
    .select-icon .select2-results__option:before,
    .select-icon .select2-results__option[aria-selected=true]:before {
        display: none !important;
        /* content: "" !important; */
    }
    .select-icon .select2-search--dropdown {
        display: none;
    }
    .select2-container {
        width:100%!important;
    }.
    .select2-selection .select2-selection--multiple {

        min-height: 55px!important;   
        border-radius: 10px;
        border: 1px solid #ced4da;
        transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
    }

    .select2-container--default .select2-selection--single .select2-selection__rendered {
        line-height: 45px !important;
    }

    .select2-container .select2-selection--single {
        height: 45px !important;
    }

    .select2-container--default .select2-selection--single .select2-selection__arrow {
        height: 45px !important;
    }

    .dataTables_wrapper .dataTables_processing {
        position: fixed !important;
        top: 0!important;
        left: 0!important;
        bottom: 0!important;
        display: flex;
        right: 0!important;
        justify-content: center!important;
        align-items: center!important;
        /* vertical-align: middle!important; */
        /* z-index: 99999!important; */
        width: 100%!important;
        height: 100%!important;
        margin-left: 0!important;
        margin-top: 0!important;
        /* padding-top: 20px!important; */
        /* text-align: center!important; */
        font-size: 1.2em!important;
        background: #0000002e!important;
    
    }

    .dataTables_wrapper .dataTables_processing img {
        position: relative;
        top: 50%;

    }
    table.stripe tr td:nth-child(4) span{
        display: block;
        width:200px;
        word-wrap: break-word;
        white-space: normal;
    }
    table.stripe tr td:nth-child(4) {
        word-wrap: break-word;
        white-space: normal;
        width:200px;
        min-width: 200px;
    }

</style>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />

<div class="container-fluid">
    
    <div class="db-top4-box-wrapper">
        <div class="my-3 hm-dis">
            <p class="db-heading m-0">@if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID'])
                <a href="{{ route('dashboard') }}">Dashboard / </a> @endif
                <a class="db-heading" href="{{ route('clinic-list'); }}">Clinic List</a> / Examinee List
            </p>

            @if($onCallStatement)
                <div class="alert alert-danger m-0">
                    <strong><i class="rotate-icon fa fa-phone" aria-hidden="true"></i> On Call Phone Number Is - {{ $onCallStatement }}</strong>
                </div>
            @endif
            
            @if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID'])
            <button class="btn-main Examinee-btn m-0" data-toggle="modal" data-target="#addExamineeModal"><i class="fas fa-plus"></i> Add Examinee</button>
            @endif
        </div>
        <div class="dashboard-table1">
            <div class="p-form">
                @if(session()->has('status'))
                    <div class="alert alert-success">
                        <strong>{{ session()->get('status') }}</strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    
                @endif
                <form action="{{ route('add.clinic_data') }}" method="post">
                    @csrf
                    <div class="form-row">
                        <div class="form-group col-lg-3 col-md-6 f-mar-rt">
                            <label for="showed_schedule">Scheduled / Showed</label>
                            <input type="text" class="form-control" id="showed_schedule" readonly>
                        </div>
                        <div class="form-group col-lg-3 col-md-6 f-mar-rt">
                            <label for="clinic_service_date">Service Date </label>
                            <input type="hidden" class="form-control" id="clinic_service_date" name="service_date" value="{{ $date }}" readonly>
                            <input type="text" class="form-control" id="clinic_service_date_show" name="show_service_date" placeholder="09/28/2021" value="{{ convertDate($date) }}" readonly>
                        </div>
                        <div class="form-group col-lg-3 col-md-6 f-mar-rt">
                            <label for="locatiion_id">Location Name</label>
                            <input type="hidden" name="location_id" value="{{ $locationData->id }}">
                            <input type="text" class="form-control" id="clinic_locatiion_id" name="locatiion_id" placeholder="1928 ROCK SPRINGS DR" value="{{ $locationData->name }}" readonly>
                        </div>
                        <div class="form-group col-lg-3 col-md-6 f-mar-rt">
                            <label for="clinicName"> Clinic Name</label><br>
                            <textarea class="form-control p-2" name="clinicName" id="clinicName" readonly>{{ $locationData->actual_address }}</textarea>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-lg-3 col-md-6 f-mar-rt">
                            <label for="examminer_list">Examiner Name</label><br>
                            <textarea class="form-control p-2" name="examminer_list" id="examminer_list" readonly>{{ $examiner_list }}</textarea>
                            
                        </div>
                        <div class="form-group col-lg-3 col-md-6 f-mar-rt">
                            <label for="assistant_list">Clinic Assistant Name </label><br>
                            <textarea class="form-control p-2" name="assistant_list" id="" readonly>{{ $assistant_list }}</textarea>
                        </div>
                        <div class="form-group col-lg-3 col-md-6 f-mar-rt">
                            <label for="clinic_team_member">Team Member</label>
                            <input type="text" class="form-control" id="clinic_team_member" name="team_member" maxlength="100" placeholder="Team Member" value="<?php echo isset($clinicDataList->team_member) ? $clinicDataList->team_member : ''; ?>" <?php echo Auth::user()->role_id == $_ENV['EXAMINER_ROLE_ID'] || Auth::user()->role_id == $_ENV['ASSISTANT_ROLE_ID'] ? "readonly" : ""; ?> >
                        </div>
                       
                        <div class="form-group col-lg-3 col-md-6 f-mar-rt">
                            <label for="clinic_contact_type">Contact Type</label>
                            <select class="form-control" id="clinic_contact_type" name="contact_type" <?php echo Auth::user()->role_id == $_ENV['EXAMINER_ROLE_ID'] || Auth::user()->role_id == $_ENV['ASSISTANT_ROLE_ID'] ? "disabled" : ""; ?>>
                                <option value="Text" <?php echo isset($clinicDataList->contact_type) && $clinicDataList->contact_type  ==  'Text' ? 'selected' : ''; ?> >Text</option>
                                <option value="Call" <?php echo isset($clinicDataList->contact_type) && $clinicDataList->contact_type  ==  'Call' ? 'selected' : ''; ?> >Call</option>
                                <option value="Both" <?php echo isset($clinicDataList->contact_type) && $clinicDataList->contact_type  ==  'Both' ? 'selected' : ''; ?> >Both</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-lg-3 col-md-6 f-mar-rt">
                            <?php if (isset($clinicDataList->chart_type) && filter_var($clinicDataList->chart_type, FILTER_VALIDATE_URL)) { ?>
                                <label for="clinic_chart_type">Charting - <a href="{{ $clinicDataList->chart_type }}" target="_blank"> Link </a></label>
                            <?php } else { ?>
                                <label for="clinic_chart_type">Charting - Link </label>
                            <?php } ?>
                            <textarea class="form-control" id="clinic_chart_type" name="chart_type" rows="3" placeholder="Enter Link" <?php echo Auth::user()->role_id == $_ENV['ASSISTANT_ROLE_ID'] || Auth::user()->role_id == $_ENV['EXAMINER_ROLE_ID'] ? "readonly" : "";  ?> ><?php echo isset($clinicDataList->chart_type) ? $clinicDataList->chart_type : ''; ?></textarea>
                        </div>
                        <div class="form-group col-lg-3 col-md-6 f-mar-rt">
                            <label for="clinic_x_ray_vendor">X-ray Vendor</label>
                            <input type="text" class="form-control" id="clinic_x_ray_vendor" name="x_ray_vendor" maxlength="100" placeholder="X-ray Vendor"  value="<?php echo isset($clinicDataList->x_ray_vendor) ? $clinicDataList->x_ray_vendor : ''; ?>" <?php echo Auth::user()->role_id == $_ENV['EXAMINER_ROLE_ID'] || Auth::user()->role_id == $_ENV['ASSISTANT_ROLE_ID'] ? "readonly" : ""; ?>>
                        </div>
                        <div class="form-group col-lg-3 col-md-6 f-mar-rt">
                            <label for="clinic_from_date">Start Time</label>
                            <input type="text" class="form-control" id="clinic_from_date" name="from_date" placeholder="11:00 AM" value="<?php echo isset($clinicDataList->from_time) ? $clinicDataList->from_time : ''; ?>" <?php echo Auth::user()->role_id == $_ENV['EXAMINER_ROLE_ID'] || Auth::user()->role_id == $_ENV['ASSISTANT_ROLE_ID'] ? "readonly" : ""; ?>>
                            
                        </div>
                        <div class="form-group col-lg-3 col-md-6 f-mar-rt">
                            <label for="clinic_to_date">End Time</label>
                            <input type="text" class="form-control" id="clinic_to_date" name="to_date" placeholder="11:30 AM" value="<?php echo isset($clinicDataList->to_time) ? $clinicDataList->to_time : ''; ?>" <?php echo Auth::user()->role_id == $_ENV['EXAMINER_ROLE_ID'] || Auth::user()->role_id == $_ENV['ASSISTANT_ROLE_ID'] ? "readonly" : ""; ?>>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-lg-6 col-md-6 f-mar-rt">
                            <label for="clinic_admin_write_in">Moonlight Headquarter Comment</label><br>
                            
                            <textarea class="form-control" id="clinic_admin_write_in" name="clinic_admin_write_in" rows="3" placeholder="Enter Your Text" <?php echo Auth::user()->role_id == $_ENV['ASSISTANT_ROLE_ID'] || Auth::user()->role_id == $_ENV['EXAMINER_ROLE_ID'] ? "readonly" : "";  ?> <?php echo Auth::user()->role_id == $_ENV['EXAMINER_ROLE_ID'] || Auth::user()->role_id == $_ENV['ASSISTANT_ROLE_ID'] ? "readonly" : ""; ?> ><?php echo isset($clinicDataList->admin_write_in) ? $clinicDataList->admin_write_in : ''; ?></textarea>
                        </div>
                        <div class="form-group col-lg-6 col-md-6">
                            <div class="check-b">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" name="training" id="clinic_traning" <?php echo isset($clinicDataList->training) && $clinicDataList->training == '1' ? 'checked' : ''; ?> <?php echo Auth::user()->role_id == $_ENV['EXAMINER_ROLE_ID'] || Auth::user()->role_id == $_ENV['ASSISTANT_ROLE_ID'] ? "disabled" : ""; ?> >
                                    <label class="form-check-label" for="clinic_traning"  >Training</label>
                                </div>
                                <div class="form-check f-check">
                                    <input type="checkbox" class="form-check-input" id="clinic_email" name="email" <?php echo isset($clinicDataList->email) && $clinicDataList->email == '1' ? 'checked' : ''; ?> <?php echo Auth::user()->role_id == $_ENV['EXAMINER_ROLE_ID'] || Auth::user()->role_id == $_ENV['ASSISTANT_ROLE_ID'] ? "disabled" : ""; ?> >
                                    <label class="form-check-label" for="clinic_email">Email Sent</label>
                                </div>
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="clinic_invite" name="invite" <?php echo isset($clinicDataList->invite) && $clinicDataList->invite == '1' ? 'checked' : ''; ?> <?php echo Auth::user()->role_id == $_ENV['EXAMINER_ROLE_ID'] || Auth::user()->role_id == $_ENV['ASSISTANT_ROLE_ID'] ? "disabled" : ""; ?> >
                                    <label class="form-check-label" for="clinic_invite">Charting Access</label>
                                </div>
                                <div class="form-check f-check">
                                    <input type="checkbox" class="form-check-input" id="clinic_xray" name="xray" <?php echo isset($clinicDataList->xray) && $clinicDataList->xray == '1' ? 'checked' : ''; ?> <?php echo Auth::user()->role_id == $_ENV['EXAMINER_ROLE_ID'] || Auth::user()->role_id == $_ENV['ASSISTANT_ROLE_ID'] ? "disabled" : ""; ?> >
                                    <label class="form-check-label" for="clinic_xray">XRAY Sent</label>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                     <div class="form-row">
                        <div class="form-group col-lg-6 col-md-6 f-mar-rt">
                            <label for="clinic_assistant_write_in">Clinic Staff Comment</label>
                            <textarea class="form-control" id="clinic_assistant_write_in" name="clinic_assistant_write_in" rows="3" placeholder="Enter Your Text" ><?php echo isset($clinicDataList->assistant_write_in) ? $clinicDataList->assistant_write_in : ''; ?></textarea>
                        </div>
                        <div class="form-group col-lg-3 col-md-12">
                    
                            <div class="Ex-btn">
                                <button type="submit" class="btn-main">Save</button>
                                <!-- <button class="rgt-arrow">Cancel</button> -->
                            </div>
                        </div>
                </form>
            </div>
        </div>

        <!--------- Add Examinee modal form ------------------------------------------->
        <div class="modal fade md-round" id="addExamineeModal" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="p-3">
                        <button type="button" data-dismiss="modal" class="close" >
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="login-form">
                            <div class="text-center mb-4">
                                <h4>Add Examinee</h4>
                            </div>
                            <form id="addExamineeForm" enctype="multipart/form-data">
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="add_first_name">First Name <span class="text-danger">*</span></label>
                                        <div class="formicon-parent">
                                            <span><i class="fas fa-user input-icon-left"></i></span>
                                            <input type="text" name="add_first_name" id="add_first_name" class="form-control frm-input-1" maxlength="20" placeholder="First Name" required>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="add_last_name">Last Name <span class="text-danger">*</span></label>
                                        <div class="formicon-parent">
                                            <span><i class="fas fa-user input-icon-left"></i></span>
                                            <input type="text" name="add_last_name" id="add_last_name"  class="form-control frm-input-1" maxlength="20" placeholder="Last Name" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="add_dob">DOB </label>
                                        <div class="formicon-parent">
                                            <span><i class="fas fa-calendar-alt input-icon-left"></i></span>
                                            <input type="text" name="dob" id="add_dob" class="form-control frm-input-1" placeholder="DOB" style="background: transparent;" >
                                        </div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="add_phone">Phone </label>
                                        <div class="formicon-parent">
                                            <input type="text" class="form-control frm-input-1" value="+1" readonly style=" width: 15%;padding-left: 8px!important;padding-right: 0px!important;border-radius: 0!important;border-top-left-radius: 10px!important;border-bottom-left-radius: 10px !important;font-weight: 600;display: inline;" >
                                            <input type="text" name="add_phone" id="add_phone"  class="form-control frm-input-1"  style="width: 85%;margin-left: -6px;border-radius: 0!important;border-top-right-radius: 10px!important;border-bottom-right-radius: 10px !important;display: inline;padding-left: 10px!important;" placeholder="Examinee Phone"  autocomplete="off">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="add_service_date">Service Date <span class="text-danger">*</span></label>
                                        <div class="formicon-parent">
                                            <span><i class="fas fa-calendar-alt input-icon-left"></i></span>
                                            <input type="hidden" name="service_date" id="add_service_date" class="form-control frm-input-1" value="{{$date}}" placeholder="Appt. Date" readonly required>
                                            <input type="text" name="service_date_show" id="add_service_date_show" class="form-control frm-input-1" value="{{convertDate($date)}}" placeholder="Appt. Date" readonly required>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="add_service_time">Service Time </label>
                                        <div class="formicon-parent">
                                            <input type="text" class="form-control frm-input-1" name="service_time" id="add_service_time" placeholder="service time" value="">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="add_case_id">Case Id </label>
                                        <div class="formicon-parent">
                                            <span><i class="fas fa-user input-icon-left"></i></span>
                                            <input type="text" name="add_case_id" id="add_case_id" class="form-control frm-input-1" maxlength="20" placeholder="Case ID">
                                        </div>
                                    </div>
                                    <div class="form-group col-md-6" style="display:none">
                                        <label for="add_special_request">Special Request </label>
                                        <div class="formicon-parent">
                                            <span><i class="fas fa-user-md input-icon-left"></i></span>
                                            <input type="text" name="add_special_request" id="add_special_request" maxlength="300" class="form-control frm-input-1" placeholder="Spec. Request">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="add_location">Clinic Name <span class="text-danger">*</span></label>
                                        <div class="formicon-parent">
                                            <span>
                                                <i class="fas fa-clinic-medical input-icon-left"></i>
                                            </span>
                                            <input type="hidden" name="location" id="add_location" class="form-control frm-input-1" value="{{ $location_id }}" >

                                            <textarea class="form-control frm-input-1 pl-5 p-2 w-100" name="location_name" id="add_location" readonly required> {{ $locationData->name }} </textarea>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-12">
                                    <label for="add_exam_type">Exam Type </label>
                                    <div class="formicon-parent">
                                            <!-- <select class="form-control frm-input-1" id="add_exam_type" name="exam_type[]" multiple required>

                                                <?php
                                                    // foreach ($seviceList as $key => $list) {
                                                    //   echo "<option value='".$list->id."'>".$list->name."</option>";
                                                    // }
                                                ?>
                                            </select>   -->
                                            <textarea class="form-control frm-input-1 p-2 w-100" placeholder="Exam Type" id="add_exam_type" name="exam_type"></textarea>

                                            <!-- <input type="text" class="form-control frm-input-1" placeholder="Exam Type" id="add_exam_type" name="exam_type" required> -->
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <div class="formicon-parent">
                                            <label for="inputAddress2" >Invoice </label>
                                            <input type="file" name="invoice" id="add_invoice" class="form-control gray pad-10">
                                        </div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <div class="formicon-parent">
                                            <label for="inputAddress2" >Records </label>
                                            <input type="file" name="cepacket" id="add_cepacket" class="form-control gray pad-10">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="Ex-pop-1 text-center">
                                        <button class="lft-arrow">Save</button>
                                        <button class="rgt-arrow" data-dismiss="modal" aria-label="Close">Cancel</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!----------------------------------modal--------------------form---------------------------end---------------->

        <!----------- update Examinee modal form ------------------------------------>
        <div class="modal fade md-round" id="editExamineeModal" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="p-3">
                        <button type="button" data-dismiss="modal" class="close" >
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="login-form">
                            <div class="text-center mb-4">
                                <h4>Edit Examinee</h4>
                            </div>
                            <form id="editExamineeForm" enctype="multipart/form-data">
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="edit_first_name">First Name <span class="text-danger">*</span></label>
                                        <div class="formicon-parent">
                                            <span><i class="fas fa-user input-icon-left"></i></span>
                                            <input type="hidden" name="appointment_id" id="edit_appointment_id" value="">
                                            <input type="text" name="first_name" id="edit_first_name" class="form-control frm-input-1" maxlength="20" placeholder="First Name" required>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="edit_last_name">Last Name <span class="text-danger">*</span></label>
                                        <div class="formicon-parent">
                                            <span><i class="fas fa-user input-icon-left"></i></span>
                                            <input type="text" name="last_name" id="edit_last_name"  class="form-control frm-input-1" maxlength="20" placeholder="Last Name" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="edit_dob">DOB </label>
                                        <div class="formicon-parent">
                                            <span><i class="fas fa-calendar-alt input-icon-left"></i></span>
                                            <input type="text" name="dob" id="edit_dob" class="form-control frm-input-1" placeholder="DOB"  style="background: transparent!important;">
                                        </div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="edit_phone">Phone </label>
                                        <div class="formicon-parent">
                                            <!-- <span><i class="fas fa-phone-alt input-icon-left"></i></span> -->
                                            <input type="text" class="form-control frm-input-1" value="+1" readonly style=" width: 15%;padding-left: 8px!important;padding-right: 0px!important;border-radius: 0!important;border-top-left-radius: 10px!important;border-bottom-left-radius: 10px !important;font-weight: 600;display: inline;" >
                                            <input type="text" name="phone" id="edit_phone"  class="form-control frm-input-1" style="width: 85%;margin-left: -6px;border-radius: 0!important;border-top-right-radius: 10px!important;border-bottom-right-radius: 10px !important;display: inline;padding-left: 10px!important;"  placeholder="Examinee Phone"  autocomplete="off">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="edit_service_date">Service Date <span class="text-danger">*</span></label>
                                        <div class="formicon-parent">
                                            <input type="hidden" name="service_date" value="{{ $date }}">
                                            <span><i class="fas fa-calendar-alt input-icon-left"></i></span>
                                            <input type="text" name="edit_service_date" id="edit_service_date" class="form-control frm-input-1" value="{{$date}}" placeholder="Appt. Date" style="background: transparent!important;" readonly required>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label for="edit_service_time">Service Time </label>
                                        <div class="formicon-parent">
                                            <!-- <input type="text" name="service_time" id="add_service_time"  class="form-control frm-input-1" placeholder="Appt. Time" required> -->
                                            <input type="text" class="form-control frm-input-1" name="service_time" id="edit_service_time" placeholder="12:56" value="">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                         <label for="edit_case_id">Case Id </label>
                                        <div class="formicon-parent">
                                            <span><i class="fas fa-user input-icon-left"></i></span>
                                            <input type="text" name="case_id" id="edit_case_id" class="form-control frm-input-1" maxlength="20" placeholder="Case ID">
                                        </div>
                                    </div>
                                    <div class="form-group col-md-6" style="display:none">
                                        <label for="edit_special_request">Special Request</label>
                                        <div class="formicon-parent">
                                            <span><i class="fas fa-user-md input-icon-left"></i></span>
                                            <input type="text" name="special_request" id="edit_special_request" maxlength="300" class="form-control frm-input-1" placeholder="Spec. Request" >
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-12">
                                        <label for="edit_location">Clinic Name <span class="text-danger">*</span></label>
                                        <div class="formicon-parent">
                                            <!-- <span>
                                                <i class="fas fa-clinic-medical input-icon-left"></i>
                                            </span> -->
                                            <input type="hidden" name="edit_location" id="edit_location" class="form-control frm-input-1" value="{{ $location_id }}" >
                                           
                                            <select style="height:auto !important;" class="form-control frm-input-1" id="edit_location_name" name="location"  >
                                            @if (count($locationList) > 0) 
                                                @foreach($locationList as $list)
                                                    <option value="{{ $list->id }}" >{{ $list->name }}</option>
                                                @endforeach
                                            @endif
                                            </select>
                                            <!-- <textarea class="form-control frm-input-1 pl-5 p-2 w-100" name="location_name" id="edit_location_name" readonly required> {{ $locationData->name }} </textarea> -->
                                        </div>
                                    </div>
                                    <div class="form-group col-md-12">
                                        <label for="edit_exam_type">Exam Type</label>
                                        <div class="formicon-parent">
                                            <input type="text" class="form-control frm-input-1" placeholder="Exam Type" id="edit_exam_type" name="edit_type_of_exam">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col-md-6">   
                                        <div class="formicon-parent">
                                            <label for="inputAddress2" class="gray">Invoice</label>
                                            <input type="file" name="invoice" id="edit_invoice" class="form-control gray pad-10">
                                        </div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <div class="formicon-parent">
                                            <label for="inputAddress2" class="gray">Records</label>
                                            <input type="file" name="cepacket" id="edit_cepacket" class="form-control gray pad-10" >
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="Ex-pop-1 text-center">
                                        <button class="lft-arrow">Update</button>
                                        <button class="rgt-arrow" data-dismiss="modal" aria-label="Close">Cancel</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!----------------------------------modal--------------------form---------------------------end---------------->
        
        <!------------------------------ update modal for case id ------------------------------------->
        <div class="modal fade bd-example-modal-md" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" id="updateCaseIdModal" >
            <div class="modal-dialog modal-md modal-dialog-centered">
                <div class="modal-content sticky">
                    <div class="" >
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="text-center">
                        <h5>Update CaseId</h5>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12 p-4">
                            <form id="updateCaseIdForm">

                                <div class="form-group" style="display:none;">
                                    <label for="case_id">Current Case Id</label>
                                    <input type="text" class="form-control" name="current_case_id" id="current_case_id" value="" readonly>
                                </div>
                                <div class="form-group">
                                    <label for="case_id">New Case Id</label>
                                    <input type="hidden" name="appointment_id" id="appointment_id" value="">
                                    <input type="text" class="form-control" name="case_id" id="case_id" value="" required>
                                </div>
                                <div class="text-center py-2">
                                    <button class="lft-arrow sti-1">Save</button>
                                    <button class="rgt-arrow sti-1" data-dismiss="modal" aria-label="Close">Cancel</button>
                                </div>
                            </form>
                        </div>  
                    </div>
                   
                </div>
            </div>
        </div>
        <!----------------------------- END  modal --------------------------------------------->

        <!------ update modal for special request ------->
        <div class="modal fade bd-example-modal-md" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" id="updateSpecialRequestModal" >
            <div class="modal-dialog modal-md modal-dialog-centered">
                <div class="modal-content sticky">
                    <div class="" >
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="text-center">
                        <h5>Special Request</h5>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12 p-4">
                            <form id="updateSpecialRequestForm">
                                <div class="form-group">
                                    <input type="hidden" name="special_request_appt_id" id="special_request_appt_id" value="">
                                    <textarea class="form-control p-2" name="current_special_request" id="current_special_request" maxlength="300" style="height: 150px;"></textarea>
                                </div>
                                <div class="text-center py-2">
                                    <button class="lft-arrow sti-1">Update</button>
                                    <button class="rgt-arrow sti-1" data-dismiss="modal" aria-label="Close">Cancel</button>
                                </div>
                            </form>
                        </div>  
                    </div>
                   
                </div>
            </div>
        </div>
        <!------ End of update modal for special request ------->

        <!------ update modal for phone number ------->
        <div class="modal fade bd-example-modal-md" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" id="updatePhoneNumberModal" >
            <div class="modal-dialog modal-md modal-dialog-centered">
                <div class="modal-content sticky">
                    <div class="">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="text-center">
                        <h5>Phone Number</h5>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12 p-4">
                            <form id="updatePhoneNumberForm">
                                <div class="form-group">
                                    <input type="hidden" name="phone_patient_id" id="phone_patient_id" value="">
                                    <input type="text" name="current_phone_number" id="current_phone_number" class="form-control frm-input-1" placeholder="Examinee Phone" autocomplete="off">

                                </div>
                                <div class="text-center py-2">
                                    <button class="lft-arrow sti-1">Update</button>
                                    <button class="rgt-arrow sti-1" data-dismiss="modal" aria-label="Close">Cancel</button>
                                </div>
                            </form>
                        </div>  
                    </div>
                   
                </div>
            </div>
        </div>
        <!------ End of update modal for phone number ------->

        <!-- call note modal -->
        <div class="modal fade bd-example-modal-md" id="callNoteModal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-md modal-dialog-centered">
                <div class="modal-content sticky">
                    <div class="">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="text-center">
                        <h5>Add Call Note</h5>
                    </div>
                    <form id="addCallNoteForm">
                        <div class="form-group">
                            <input type="hidden" name="appointment_id" id="call_appointment_id" value="">
                            <textarea class="form-control" id="call_note" name="call_note" rows="5"
                                placeholder="Write Here...."></textarea>
                        </div>
                        <div class="text-center py-2">
                            <button class="lft-arrow sti-1">Save</button>
                            <button class="rgt-arrow sti-1" data-dismiss="modal" aria-label="Close">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- -------------------- change broken status  modal ------------------>
        <div class="modal fade bd-example-modal-md" id="brokenCommentModal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-md modal-dialog-centered">
                <div class="modal-content sticky">
                    <div class="">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="text-center">
                        <h5>Are you sure?</h5>
                        <p>you want to change status into broken</p>
                    </div>
                    <form id="brokenCommentForm">
                        <div class="form-group">
                            <input type="hidden" name="appointment_id" id="broken_appointment_id" value="">
                            <input type="hidden" name="status" id="broken_status" value="1">
                            <textarea class="form-control" id="broken_comment" name="broken_comment" rows="5" placeholder="Write Here comment...."></textarea>
                        </div>
                        <div class="text-center py-2">
                            <button class="lft-arrow sti-1">Submit</button>
                            <button class="rgt-arrow sti-1" data-dismiss="modal" aria-label="Close">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!------------------------------ END Modal ---------------------->

        <!--------------------- change broken status modal ---------------------->
        <div class="modal fade bd-example-modal-md" id="cancelCommentModal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-md modal-dialog-centered">
                <div class="modal-content sticky">
                    <div class="">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="text-center">
                        <h5>Are you sure?</h5>
                        <p>you want to change status into cancel</p>
                    </div>
                    <form id="cancelCommentForm">
                        <div class="form-group">
                            <input type="hidden" name="appointment_id" id="cancel_appointment_id" value="">
                            <input type="hidden" name="status" id="cancel_status" value="2">
                            <textarea class="form-control" id="broken_comment" name="broken_comment" rows="5" placeholder="Write Here comment...."></textarea>
                        </div>
                        <div class="text-center py-2">
                            <button class="lft-arrow sti-1">Submit</button>
                            <button class="rgt-arrow sti-1" data-dismiss="modal" aria-label="Close">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!------------------------ END broken status modal ---------------------->

        <!------------------------ view sticky note modal ------------------------------->
        <div class="modal fade bd-example-modal-md" id="viewstickynotesModal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content sticky">
                    <div class="">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="text-center">
                        <h5>Sticky Notes</h5>
                    </div>
                    <div class="container" id="stickycontent"></div>
                </div>
            </div>
        </div>
        
        <!------------------------ view sticky note modal ------------------------------------>
        <div class="modal fade bd-example-modal-md" id="viewcallnotesModal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content sticky">
                    <div class="">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="text-center">
                        <h5>Call Notes</h5>
                    </div>
                    <div class="modal-body">
                        <div class="container p-3" id="callcontent"></div>
                    </div>
                </div>
            </div>
        </div>

        <!------------------------ sticky Note modal ----------------------------------------->
        <div class="modal fade bd-example-modal-md" id="stickyNoteModal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-md modal-dialog-centered">
                <div class="modal-content sticky">
                    <div class="">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="text-center">
                        <h5>Add Sticky Note</h5>
                    </div>
                    <form id="addStickyNoteForm">
                        <div class="form-group">
                            <input type="hidden" name="appointment_id" id="sticky_appointment_id" value="">
                            <textarea class="form-control" id="sticky_note" name="sticky_note" rows="5"
                                placeholder="Write Here...."></textarea>
                        </div>
                        <div class="text-center py-2">
                            <button class="lft-arrow sti-1">Save</button>
                            <button class="rgt-arrow sti-1" data-dismiss="modal" aria-label="Close">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>

    <div class="dashboard-table1">
        @if(Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID'])
            <form action="{{ route('post.exportDetails')}}">
                @csrf
                <input type="hidden" name="service_date" value="{{$date}}">
                <input type="hidden" name="location" value="{{$location_id}}">
                <button type="submit" class="btn-main" style="float:right;">Export</button>
            </form>
        @endif
        <div class="mb-3">
        <h4>Examinee List&nbsp;-&nbsp;{{ $locationData->name }}</h4>           
        </div>
        <div class="row">
            <div class="col-md-12">
                <table id="" class="stripe patient-table patienttable2" style="width:100%">
                    <thead>
                        <tr>
                            <th>Broken kept</th>
                            <th>Appt. Time</th>
                            <th>Examinee Name</th>
                            <th>Special Request</th>
                            <?php if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID']) { ?>
                            <th>Request Status</th>
                            <?php } ?>
                            <th>Case Id </th>
                            <th>DOB</th>
                            <th>Phone</th>
                            <?php if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID']) { ?>
                                <th>Call Note </th>
                                <th>Sticky Note</th>
                                <th>Invoice</th>
                                <th>Records</th>
                                <th>Action</th>
                            <?php } else { ?>
                            	<th>Records</th>
                            <?php } ?>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>

    <!---------------------- upload document section  ----------------->
    <div class="dashboard-table1">
        <div class="mb-3">
            <h4>Document Upload</h4>          
        </div>
        @if(count($clinicDocuments) > 0 )

            <form action="{{ route('post.downloadClinicDocuments') }}" method="post" id="clinic_document_form"> 
                @csrf
                <input type="hidden" name="service_date" id="document_service_date" value="{{$date}}">
                <input type="hidden" name="location" id="document_location_id" value="{{$location_id}}">
                <p><button type="submit" class="btn btn-secondary btn-sm" >View Documents</button></p>
            </form>
            
        @endif
        <div class="p-form">
            <form id="clinicDocumentForm" action="{{ route('post.uploadDocument') }}" method="post" enctype="multipart/form-data">
            @csrf
                <div class="form-row">
                    <div class="form-group col-md-6 f-mar-rt">
                        <input type="hidden" name="service_date" value="{{$date}}">
                        <input type="hidden" name="location_id" value="{{$location_id}}">
                        <label for="clinic_file">Choose file</label>
                        <input type="file" class="form-control" name="clinic_file" id="clinic_file" required>
                    </div>
                    <div class="form-group d-flex align-items-end col-lg-4 col-md-6 f-mar-rt">
                        <div class="ex-btn-botm  Ex-btn">
                            <button class="btn-main">Upload</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!--- END upload content section ---------------------------------------------->

  	@if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID'])
    <div class="dashboard-table1">
        <div class="p-form">
            <form action="{{ route('post.saveClinicCalculations') }}" method="post">
                @csrf
                <div class="form-row">
                    <div class="form-group col-lg-3 col-md-6 f-mar-rt">
                        <input type="hidden" name="service_date" value="{{$date}}">
                        <input type="hidden" name="location_id" value="{{$location_id}}">
                        <label for="submitted_by">Submitted By</label>
                        <input type="hidden" class="form-control" id="submitted_by" name="submitted_by" placeholder="" value="<?php $userName = getuserNameById(Auth::user()->id); echo $userName ? $userName->id: ''; ?>" required>
                        <input type="text" class="form-control" id="submitted_by_name" name="submitted_by" maxlength="30" placeholder="" value="<?php echo isset($checkCalculationList) && isset($checkCalculationList[0]->submitted_by) ? $checkCalculationList[0]->submitted_by : ''; ?>" required >
                    </div>
                    <?php
                    
                    ?>
                    <div class="form-group col-lg-3 col-md-6 f-mar-rt">
                        <label for="submitted_date">Submitted Date</label>
                        <input type="text" class="form-control" style="background:transparent!important;" id="submitted_date"
                            placeholder="mm-dd-yy" name="submitted_date" value="<?php echo isset($checkCalculationList) && isset($checkCalculationList[0]->submitted_date) ?  convertDate($checkCalculationList[0]->submitted_date) : ''; ?>" required>
                    </div>
                    <div class="form-group col-lg-3 col-md-6 f-mar-rt">
                        <label for="examiner_pay">Examiner Pay ($)</label>
                        <input type="Text" maxlength="10" class="form-control" id="examiner_pay" name="examiner_pay" placeholder="" value="<?php echo isset($checkCalculationList) && isset($checkCalculationList[0]->examiner_pay) ? $checkCalculationList[0]->examiner_pay : ''; ?>" required>
                    </div>
                    <div class="form-group col-lg-3 col-md-6 f-mar-rt">
                        <label for="revenue">Revenue ($)</label>
                        <input type="text" class="form-control" maxlength="10" id="revenue" name="revenue" placeholder="" value="<?php echo isset($checkCalculationList) && isset($checkCalculationList[0]->revenue) ? $checkCalculationList[0]->revenue : ''; ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-lg-3 col-md-6 f-mar-rt">
                    </div>
                    <div class="form-group col-lg-3 col-md-6">
                    </div>
                    <div class="form-group col-md-12">
                        <div class="ex-btn-botm  Ex-btn">
                            <button type="submit" class="btn-main">Save</button>
                        </div>
                    </div>
            </form>
        </div>
    </div>
    @endif
    
</div>

    <!-- cdn link of select2 jquery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.1/moment.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.0/themes/base/jquery-ui.css">
    <script src="https://code.jquery.com/ui/1.13.0/jquery-ui.js"></script>

    <script src="{{ asset('assets/js/jquery-input-mask-phone-number.js') }}" ></script>

    
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript" src="https://cdn.ckeditor.com/4.5.11/standard/ckeditor.js"></script>
<script>


    function getNotesData(id,url,method,container,modal) {

        let data;

        $.ajax({
            url:url,
            type:method,
            data:{_token:"{{ csrf_token() }}",appointment_id:id},
            beforeSend:function() {
                
                swal({
                    icon: "{{ url('/assets/images/loader.gif') }}",
                    text: 'Please Wait!',
                    buttons: false,
                    closeOnClickOutside:false
                });

            },
            success:function(data) {

                swal.close();

                if (data.status == true) {

                    $('#'+container).html(data.data);
                    modal.modal('show');

                } else if (data.status == false) {

                    swal({
                        title: "Oops!",
                        text: data.msg,
                        icon: "error"
                    });
                } else {
                    location.reload();
                }
               
            },
            error:function (jqXHR,textStatus,errorThrown) {

                swal({
                    icon: "error",
                    title:'Oops!',
                    text: 'something went wrong, Response Status Code - '+jqXHR.status,
                    closeOnClickOutside:false
                });
                location.reload();
            },
        });
        
       
    }

    function getSechduleCount() {

        let data;

        $.ajax({
            url:"{{ route('get.sechduelCount') }}",
            type:'GET',
            data:{_token:"{{ csrf_token() }}",date:"{{ $date }}",location:"{{$location_id}}"},
            beforeSend:function() {
                
                // swal({
                //     icon: "{{ url('/assets/images/loader.gif') }}",
                //     text: 'Please Wait!',
                //     buttons: false,
                //     closeOnClickOutside:false
                // });

            },
            success:function(data) {

                // swal.close();
                console.log('shoed', data);
                if (data.status) {

                    $('#showed_schedule').val(data.totalSechdule+"/"+data.totalShowed);

                } else {

                    swal({
                        title: "Oops!",
                        text: data.msg,
                        icon: "error"
                    });
                }
            
            },
            error:function (jqXHR,textStatus,errorThrown) {

                swal({
                    icon: "error",
                    title:'Oops!',
                    text: 'something went wrong, Response Status Code - '+jqXHR.status,
                    closeOnClickOutside:false
                });
                location.reload();
            },
        });

    }

    function changestatusintobroken(id) {

        $.ajax({
            url: "{{ route('update.appointmentStatus') }}",
            type: "POST",
            data: {appointment_id:id,status:1,_token:"{{ csrf_token() }}"},
            beforeSend:function() {
                swal({
                    icon: "{{ url('/assets/images/loader.gif') }}",
                    text: 'Please Wait...',
                
                });
            },
            success:function(data) {
                
                swal.close();
                if (data.status == true) {

                    swal({
                        title: "Great!",
                        text: data.msg,
                        icon: "success",
                    });

                    resultTable.ajax.reload();
                    getSechduleCount();                                

                } else if (data.status == false) {
                    swal({
                        title: "Oops!",
                        text: data.msg,
                        icon: "error",
                    });
                } else {
                    location.reload();
                }
            },
            error:function (jqXHR, textStatus, errorThrown) {
                if (jqXHR.status == 500) {
                    console.log('500 status');
                } else {
                    console.log('something went wrong!');
                }
                location.reload();
            },
        });

    }

    function getTimeObject(time) {

        var d = new Date(),
            s = time,
            parts = s.match(/(\d+)\:(\d+) (\w+)/),
            hours = /am/i.test(parts[3]) ? parseInt(parts[1], 10) : parseInt(parts[1], 10) + 12,
            minutes = parseInt(parts[2], 10);

        d.setHours(hours);
        d.setMinutes(minutes);

        // return d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit',hour12: true });
        return d;

    }

    $(function() {

        $('#edit_location_name').select2();

        var firstOpen = true;
        var time;

        $('#clinic_from_date,#clinic_to_date,#add_service_time,#edit_service_time').datetimepicker({
            format: 'hh:mm A',
            icons: {
                up: 'fa fa-angle-up',
                down: 'fa fa-angle-down'
            }
        });

        getSechduleCount();

        $('#add_phone,#edit_phone,#current_phone_number').usPhoneFormat();

        // view call note functionality 
        $(document).on('click','.viewcallNotebtn',function(e) {
            e.preventDefault();

            getNotesData($(this).attr('data-appointment'),"{{ route('get.call_note') }}",'POST','callcontent',$('#viewcallnotesModal'))
        });
        //--------------END-------------------------------------

        //view sticky note functionality 
        $(document).on('click','.viewstickyNotebtn',function(e) {
            e.preventDefault();
            getNotesData($(this).attr('data-appointment'),"{{ route('get.sticky_note') }}",'POST','stickycontent',$('#viewstickynotesModal'))
        });
        //---------- END ----------------------------------------- 

        
        //datatabe implementation
        var resultTable = $('.patient-table').DataTable({
            processing: true,
            serverSide: false,
            responsive:true,
            scrollX:true,
            // "scrollY": "300px",
            "scrollCollapse": true,
            order: [],
            "language": {
                "processing": "<img style='width:80px; height:80px;' src='{{url('/assets/images/loaderspinner.gif')}}' >"
            },
            ajax:{
                    url:"{{ route('getPatientList') }}",
                    type:'GET',
                    data:function(data) {
                        data.date='{{ $date}}',
                        data.location_id='{{$location_id}}'
                    }
                },
            columns: [
                {data: 'status', name: 'status', orderable: false},
                {data: 'service_time', name: 'service_time', orderable: false},
                {data: 'patient_name', name: 'patient_name'},
                {data: 'special_request', name: 'special_request',orderable: false, searchable: false},
                <?php if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID']) { ?>
                {data: 'request_status', name: 'request_status'},
                <?php } ?>
                {data: 'case_id', name: 'case_id',orderable: false, searchable: true},
                {data: 'dob', name: 'dob',orderable: false, searchable: true},
                {data: 'patient_phone', name: 'patient_phone',orderable: false, searchable: true},
                <?php if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID']) { ?>
                    {data: 'call_note', name: 'call_note',orderable: false, searchable: false},
                    {data: 'sticky_note', name: 'sticky_note',orderable: false, searchable: false},
                    {data: 'invoice', name: 'invoice',orderable: false, searchable: false},
                    {data: 'cepacket', name: 'cepacket',orderable: false, searchable: false},
                    {data: 'action', name: 'action', orderable: false, searchable: false},
                <?php } else {?>
                	{data: 'cepacket', name: 'cepacket',orderable: false, searchable: false},
                <?php } ?>
            ]
            
        });
        //----------- END ------------------------------- 
        
        //
        $(document).on('click','.caseidbtn',function(e) {
            
            $('#appointment_id').val($(this).attr('data-appointment'));
            $('#current_case_id').val($(this).attr('data-case_id'));
            if($(this).attr('data-case_id') != '') {
                $('#current_case_id').parent().show();
            }
            $('#updateCaseIdModal').modal('show');
        });

        // Add or update special request from single click
        $(document).on('click','.specialrequestbtn',function(e) {
            
            $('#special_request_appt_id').val($(this).attr('data-appointment'));
            $('#current_special_request').val($(this).attr('data-special_request'));
            if($(this).attr('data-special_request') != '') {
                $('#current_special_request').parent().show();
            }
            CKEDITOR.instances['current_special_request'].setData($(this).attr('data-special_request'));
            $('#updateSpecialRequestModal').modal('show');
        });

        // Add or update phone number from single click
        $(document).on('click','.phonebtn',function(e) {
            
            $('#phone_patient_id').val($(this).attr('data-patient-id'));
            $('#current_phone_number').val($(this).attr('data-phone_number'));
            if($(this).attr('data-phone_number') != '') {
                $('#current_phone_number').parent().show();
            }
            $('#updatePhoneNumberModal').modal('show');
        });

        // add call note
        $(document).on('click','.addcallnote',function(e) {
            e.preventDefault();
            $('#call_appointment_id').val($(this).attr('data-appointment'));
            $('#callNoteModal').modal('show');
        });

        // add sticky note functionality 
        $(document).on('click','.addstickynote',function(e) {
            e.preventDefault();
            $('#sticky_appointment_id').val($(this).attr('data-appointment'));
            $('#stickyNoteModal').modal('show');
        });
        //------------------ END ----------------------


        // To update the case id
        $(document).on('submit', '#updateCaseIdForm', function(e) {

            e.preventDefault();

            $.ajax({
                url:"{{ route('update.case_id') }}",
                type:'POST',
                data:$(this).serialize() + '&_token='+"{{ csrf_token() }}",
                beforeSend:function() {
                    
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    });

                },
                success:function(data) {

                    swal.close();

                    if (data.status == true) {

                        $('#updateCaseIdModal').modal('hide');

                        resultTable.ajax.reload();

                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success",
                            timer: 1000
                        });

                    } else if (data.status == false) {

                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error"
                        });
                    } else {
                        location.reload();
                    }
                },
                error:function (jqXHR,textStatus,errorThrown) {

                    swal({
                        icon: "error",
                        title:'Oops!',
                        text: 'something went wrong, Response Status Code - '+jqXHR.status,
                        closeOnClickOutside:false
                    });
                    location.reload();
                },
            });

        });
        //--------------

        // To update the special request
        $(document).on('submit', '#updateSpecialRequestForm', function(e) {

            e.preventDefault();

            $.ajax({
                url:"{{ route('update.special_request') }}",
                type:'POST',
                data:$(this).serialize() + '&_token='+"{{ csrf_token() }}",
                beforeSend:function() {
                    
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    });

                },
                success:function(data) {

                    swal.close();

                    if (data.status == true) {

                        $('#updateSpecialRequestModal').modal('hide');

                        resultTable.ajax.reload();

                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success",
                            timer: 1000
                        });

                    } else if (data.status == false) {

                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error"
                        });
                    } else {
                        location.reload();
                    }
                },
                error:function (jqXHR,textStatus,errorThrown) {

                    swal({
                        icon: "error",
                        title:'Oops!',
                        text: 'something went wrong, Response Status Code - '+jqXHR.status,
                        closeOnClickOutside:false
                    });
                    location.reload();
                },
            });

        });


        // To update the phone number
        $(document).on('submit', '#updatePhoneNumberForm', function(e) {

            e.preventDefault();

            $.ajax({
                url:"{{ route('update.phone_number') }}",
                type:'POST',
                data:$(this).serialize() + '&_token='+"{{ csrf_token() }}",
                beforeSend:function() {
                    
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    });

                },
                success:function(data) {

                    swal.close();

                    if (data.status == true) {

                        $('#updatePhoneNumberModal').modal('hide');

                        resultTable.ajax.reload();

                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success",
                            timer: 1000
                        });

                    } else if (data.status == false) {

                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error"
                        });
                    } else {
                        location.reload();
                    }
                },
                error:function (jqXHR,textStatus,errorThrown) {

                    swal({
                        icon: "error",
                        title:'Oops!',
                        text: 'something went wrong, Response Status Code - '+jqXHR.status,
                        closeOnClickOutside:false
                    });
                    location.reload();
                },
            });
        });

        //This is used for change status into the broken
        $(document).on('click','.no_show',function(event) {

            let id = $(this).attr('data-id');
            $('#broken_appointment_id').val(id);

            $('#brokenCommentModal').modal('show')
        });

        //This is used for change the status into the cancel 
        $(document).on('click','.status_cancel',function(event) {

            let id = $(this).attr('data-id');
            $('#cancel_appointment_id').val(id);

            $('#cancelCommentModal').modal('show')
        });


        // To update the case id
        $(document).on('submit', '#cancelCommentForm', function(e) {

            e.preventDefault();

            $.ajax({
                url: "{{ route('update.appointmentStatus') }}",
                type: "POST",
                data:$(this).serialize() + '&_token='+"{{ csrf_token() }}",
                beforeSend:function() {
                    
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    });

                },
                success:function(data) {

                    swal.close();

                    if (data.status == true) {

                        // $('#updateCaseIdModal').modal('hide');
                        $('#cancelCommentModal').modal('hide')

                        resultTable.ajax.reload();

                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success"
                        });

                    } else if (data.status == false) {

                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error"
                        });
                    } else {
                        location.reload();
                    }
                },
                error:function (jqXHR,textStatus,errorThrown) {

                    swal({
                        icon: "error",
                        title:'Oops!',
                        text: 'something went wrong, Response Status Code - '+jqXHR.status,
                        closeOnClickOutside:false
                    });
                    location.reload();
                },
            });

        });
        //--------------

        // To update the case id
        $(document).on('submit', '#brokenCommentForm', function(e) {

            e.preventDefault();

            $.ajax({
                url: "{{ route('update.appointmentStatus') }}",
                type: "POST",
                data:$(this).serialize() + '&_token='+"{{ csrf_token() }}",
                beforeSend:function() {
                    
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    });

                },
                success:function(data) {

                    swal.close();

                    if (data.status == true) {

                        // $('#updateCaseIdModal').modal('hide');
                        $('#brokenCommentModal').modal('hide')

                        resultTable.ajax.reload();
                        getSechduleCount();

                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success"
                        });

                    } else if (data.status == false) {

                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error"
                        });
                    } else {
                        location.reload();
                    }
                },
                error:function (jqXHR,textStatus,errorThrown) {

                    swal({
                        icon: "error",
                        title:'Oops!',
                        text: 'something went wrong, Response Status Code - '+jqXHR.status,
                        closeOnClickOutside:false
                    });
                    location.reload();
                },
            });

        });
        //--------------
        
        // To add the call note
        $(document).on('submit', '#addCallNoteForm', function(e) {

            e.preventDefault();

            $.ajax({
                url:"{{ route('add.call_note') }}",
                type:'POST',
                data:$(this).serialize() + '&_token='+"{{ csrf_token() }}",
                beforeSend:function() {
                    
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    });

                },
                success:function(data) {

                    swal.close();

                    if (data.status == true) {

                        $('#callNoteModal').modal('hide');

                        resultTable.ajax.reload();

                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success"
                        });

                    } else if (data.status == false) {

                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error"
                        });
                    } else {
                        location.reload();
                    }
                },
                error:function (jqXHR,textStatus,errorThrown) {

                    swal({
                        icon: "error",
                        title:'Oops!',
                        text: 'something went wrong, Response Status Code - '+jqXHR.status,
                        closeOnClickOutside:false
                    });
                    location.reload();

                },
            });

        });
        //-------------- END Call Note -------------------------- 
            
        // To add the sticky note 
        $(document).on('submit', '#addStickyNoteForm', function(e) {

            e.preventDefault();

            $.ajax({
                url:"{{ route('add.sticky_note') }}",
                type:'POST',
                data:$(this).serialize() + '&_token='+"{{ csrf_token() }}",
                beforeSend:function() {
                    
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    });

                },
                success:function(data) {

                    swal.close();

                    if (data.status == true) {

                        $('#stickyNoteModal').modal('hide');

                        resultTable.ajax.reload();

                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success"
                        });

                    } else if (data.status == false) {

                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error"
                        });
                    } else {
                        location.reload();
                    }
                },
                error:function (jqXHR,textStatus,errorThrown) {

                    swal({
                        icon: "error",
                        title:'Oops!',
                        text: 'something went wrong, Response Status Code - '+jqXHR.status,
                        closeOnClickOutside:false
                    });
                    location.reload();

                },
            });

        });

        //This is used for delete sticky note
        $(document).on('click','.sticky_deletebtn',function(event) {

            let id = $(this).attr('data-id');

            swal({
                title: "Are you sure?",
                text: "you want to delete this sticky note",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                closeOnClickOutside:false
            }).then((willDelete) => {
                if (willDelete) {
                    
                    $.ajax({
                        url: "{{ route('delete.stickyNote') }}",
                        type: "POST",
                        data: {sticky_id:id,_token:"{{ csrf_token() }}"},
                        beforeSend:function() {
                            swal({
                                icon: "{{ url('/assets/images/loader.gif') }}",
                                text: 'Please Wait...',
                            
                            });
                        },
                        success:function(data) {
                            
                            swal.close();
                            if (data.status == true) {

                                $('#viewstickynotesModal').modal('hide');

                                swal({
                                    title: "Great!",
                                    text: data.msg,
                                    icon: "success",
                                });
                                resultTable.ajax.reload();
                                

                            } else if (data.status == false) {
                                swal({
                                    title: "Oops!",
                                    text: data.msg,
                                    icon: "error",
                                });
                            } else {
                                location.reload();
                            }
                        },
                        error:function (jqXHR, textStatus, errorThrown) {
                            if (jqXHR.status == 500) {
                                console.log('500 status');
                            } else {
                                console.log('something went wrong!');
                            }
                            location.reload();
                        },
                    });

                } else {}
            });
        });

        //This is used for delete Appointment
        $(document).on('click','.delete-appointment',function(event) {

            let id = $(this).attr('data-id');
            swal({
                title: "Are you sure?",
                text: "you want to delete this Appointment!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                closeOnClickOutside:false
            }).then((willDelete) => {
                if (willDelete) {
                    
                    $.ajax({
                        url: "{{ route('delete.appointment') }}",
                        type: "POST",
                        data: {appointment_id:id,_token:"{{ csrf_token() }}"},
                        beforeSend:function() {
                            swal({
                                icon: "{{ url('/assets/images/loader.gif') }}",
                                text: 'Please Wait...',
                            
                            });
                        },
                        success:function(data) {
                            
                            swal.close();
                            if (data.status == true) {
                                swal({
                                    title: "Great!",
                                    text: data.msg,
                                    icon: "success",
                                });
                                resultTable.ajax.reload();
                            } else if (data.status == false) {
                                swal({
                                    title: "Oops!",
                                    text: data.msg,
                                    icon: "error",
                                });
                            } else {
                                location.reload();
                            }
                        },
                        error:function (jqXHR, textStatus, errorThrown) {
                            if (jqXHR.status == 500) {
                                console.log('500 status');
                            } else {
                                console.log('something went wrong!');
                            }
                            location.reload();
                        },
                    });

                } else {}
            });
        });
        //-------------- END delete Appointment functionality ----------------------

        //This is used for delete sticky note
        $(document).on('click','.callnote_deletebtn',function(event) {

            let id = $(this).attr('data-id');

            swal({
                title: "Are you sure?",
                text: "you want to delete this call note",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                closeOnClickOutside:false
            }).then((willDelete) => {
                if (willDelete) {
                    
                    $.ajax({
                        url: "{{ route('delete.callNote') }}",
                        type: "POST",
                        data: {callNote_id:id,_token:"{{ csrf_token() }}"},
                        beforeSend:function() {
                            swal({
                                icon: "{{ url('/assets/images/loader.gif') }}",
                                text: 'Please Wait...',
                            
                            });
                        },
                        success:function(data) {
                            
                            swal.close();
                            if (data.status == true) {

                                $('#viewcallnotesModal').modal('hide');

                                swal({
                                    title: "Great!",
                                    text: data.msg,
                                    icon: "success",
                                });
                                resultTable.ajax.reload();
                                

                            } else if (data.status == false) {
                                swal({
                                    title: "Oops!",
                                    text: data.msg,
                                    icon: "error",
                                });
                            } else {
                                location.reload();
                            }
                        },
                        error:function (jqXHR, textStatus, errorThrown) {
                            if (jqXHR.status == 500) {
                                console.log('500 status');
                            } else {
                                console.log('something went wrong!');
                            }
                            location.reload();
                        },
                    });

                } else {}
            });
        });

        //This is used for apply the validation on add User form

        jQuery.validator.addMethod("lettersonly", function(value, element) {
            return this.optional(element) || /^[a-z\s]+$/i.test(value);
        }, "Only alphabetical characters");

        $("#addExamineeForm").validate({

            rules: {
                add_first_name:{
                    required:true,
                    lettersonly:true,
                    maxlength:20
                },
                add_last_name:{
                    required:true,
                    lettersonly:true,
                    maxlength:20
                },
                                  
                service_date: {
                    required:true
                },
               
                location:{
                    required:true
                }

            },

            messages: {

                add_first_name:{
                    required:"First Name is required",
                    minlength:"Enter character between 1-20"
                },
                add_lastName:{
                    required:"Last Name is required",
                    minlength:20
                },                 
                service_date: {
                    required:"Service date is required",
                },
              
                location:{
                    required:"Location is required",
                }

            },

            errorPlacement: function(label, element) {

                label.addClass('mt-2 text-danger');

                label.insertAfter(element);

            },

            highlight: function(element, errorClass) {

                $(element).parent().addClass('has-danger');

                $(element).addClass('form-control-danger');

            },

            unhighlight: function(element, errorClass, validClass) {

                $(element).parents().removeClass('has-danger');

                    $(element).removeClass('form-control-danger');

                $(element).parents('.form-group').addClass('has-success');

            }

        });
        //<=--------------------- END validation ------------------------------->

        //this is used for apply the validation on add User form
        $("#editExamineeForm").validate({

            rules: {
                first_name:{
                    required:true,
                    lettersonly:true,
                    maxlength:20
                },
                last_name:{
                    required:true,
                    maxlength:20
                },                   
                edit_service_date: {
                    required:true
                },
                location:{
                    required:true
                },

            },

            messages: {

                first_name:{
                    required:"First Name is required",
                    maxlength:"Enter character between 1-20"
                },
                last_name:{
                    required:"Last Name is required",
                    maxlength:"Enter character between 1-20"
                },
                service_date: {
                    required:"Service date is required",
                },
                location:{
                    required:"Location is required",
                },
            },

            errorPlacement: function(label, element) {

                label.addClass('mt-2 text-danger');

                label.insertAfter(element);

            },

            highlight: function(element, errorClass) {

                $(element).parent().addClass('has-danger');

                $(element).addClass('form-control-danger');

            },

            unhighlight: function(element, errorClass, validClass) {

                $(element).parents().removeClass('has-danger');

                    $(element).removeClass('form-control-danger');

                $(element).parents('.form-group').addClass('has-success');

            }

        });
        //<=--------------------- END Validation ------------------------------->

        // This is used to add the examinee.
        $(document).on('submit', '#addExamineeForm', function(e) {
            
            e.preventDefault();

            if(!$('#addExamineeForm').valid()) {
                alert('Something went wrong at time of fill the form');
                return;
            }

            let formdata = new FormData($('#addExamineeForm')[0]);

            formdata.append('_token',"{{ csrf_token() }}");
            $.ajax({
                url:"{{ route('add.patient') }}",
                type:'POST',
                enctype:"multipart/form-data",
                data:formdata,
                cache : false,
                processData: false,
                contentType: false,
                beforeSend:function() {
                    
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    });

                },
                success:function(data) {

                    swal.close();

                    if (data.status == true) {

                        $('#addExamineeModal').modal('hide');

                        resultTable.ajax.reload();
                        getSechduleCount();
                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success"
                        });

                    } else if (data.status == false) {

                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error"
                        });
                    } else {
                        location.reload();
                    }
                },
                error:function (jqXHR,textStatus,errorThrown) {

                    swal({
                        icon: "error",
                        title:'Oops!',
                        text: 'something went wrong, Response Status Code - '+jqXHR.status,
                        closeOnClickOutside:false
                    });
                    location.reload();
                },
            });

        });
        //<----------------------- END -------------------------->

        // This is used to showing the edit modal for update the examinee
        $(document).on('click','.editbtn', function() {
            
            let apptId = $(this).attr('data-id');

            $.ajax({
                url:"{{ route('get.patientDetails') }}",
                type:'GET',
                data: {_token:"{{ csrf_token()}}",appointment_id:apptId},
                dataType:'json',
                beforeSend:function() {

                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    
                    });
                },
                success:function(output) {
                    
                    swal.close();
                    if (output.status == true) {
                        let data = output.data;
                        console.log(output);
                        let first = data.first_name != '' && data.first_name != null ? data.first_name.trim().split(" ") : ['',''];
                        console.log(first,'check');
                        let time = data.service_time;
                        let len = first.length;
                        console.log({first,time,len});
                        $('#edit_appointment_id').val(data.appointment_id);
                        first.toString().substr(-1);
                        let firstNameStr = first.slice(1,len).toString();
                        $('#edit_first_name').val(first.slice(0,len-1).toString().replace(/,/g, " "));
                        // $('#edit_last_name').val(first.slice(1,len).toString().replace(",", " "));
                        $('#edit_last_name').val(first[len-1]);
                        $('#edit_dob').val(data.dob);
                        $('#edit_phone').val(data.phone);
                        // getTimeObject(time).toISOString().substring(11,16)
                        $('#edit_service_time').val(data.service_time);
                        $('#edit_service_time').attr('data-val', data.service_time);
                        $('#edit_case_id').val(data.case_id);
                        $('#edit_special_request').val(data.special_instruction);
                        $('#edit_exam_type').val(data.type_of_exam);
                        $('#edit_location_name').val(data.location_id).trigger('change');

                        // $('#edit_location_name option').each(function() {
                            
                        //     if (this.value == data.location_id) {
                        //         $(this).attr('selected',"selected");
                        //     }
                        // });
                        
                        $('#edit_dob').datepicker({
                            beforeShow: function(input, inst) {
                                $(document).off('focusin.bs.modal');
                            },
                            onClose:function() {
                                $(document).on('focusin.bs.modal');
                            },
                            "dateFormat":'mm-dd-yy',
                            maxDate:new Date(),
                            changeMonth:true,
                            changeYear:true,
                            yearRange:"-100:+100",
                        });

                        if (data.dob != '') {

                            $('#edit_dob').datepicker("setDate",data.dob);
                        }
                        
                        $('#edit_service_date').datepicker({
                            beforeShow: function(input, inst) {
                                $(document).off('focusin.bs.modal');
                            },
                            onClose:function() {
                                $(document).on('focusin.bs.modal');
                            },
                            "dateFormat":'mm-dd-yy',
                            changeMonth:true,
                            changeYear:true,
                            yearRange:"-1:+1",
                        }).datepicker("setDate",data.service_date);

                        $('#editExamineeModal').modal('show');

                    } else if (output.status == false) {
                        swal({  
                            title: "Oops!",
                            text: output.msg,
                            icon: "error",
                        });
                    } else {
                        location.reload();
                    }
                },
                error:function (jqXHR, textStatus, errorThrown) {
                    if (jqXHR.status == 500) {
                        console.log('500 status');
                    } else {
                        console.log('something went wrong!');
                    }
                    location.reload();
                },
            });
        });

        // This is used to update the examinee.
        $(document).on('submit', '#editExamineeForm', function(e) {

            e.preventDefault();
            if(!$('#editExamineeForm').valid()) {
                alert('Something went wrong at time of fill the form');
                return;
            }
            let formdata = new FormData($('#editExamineeForm')[0]);

            formdata.append('_token',"{{ csrf_token() }}");

            $.ajax({
                url:"{{ route('update.patient') }}",
                type:'POST',
                enctype:"multipart/form-data",
                data:formdata,
                cache : false,
                processData: false,
                contentType: false,
                beforeSend:function() {
                    
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    });

                },
                success:function(data) {

                    swal.close();

                    if (data.status == true) {

                        $('#editExamineeModal').modal('hide');

                        resultTable.ajax.reload();
                        getSechduleCount();
                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success",
                            timer: 1000
                        });

                    } else if (data.status == false) {

                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error"
                        });
                    } else {
                        location.reload();
                    }
                },
                error:function (jqXHR,textStatus,errorThrown) {

                    swal({
                        icon: "error",
                        title:'Oops!',
                        text: 'something went wrong, Response Status Code - '+jqXHR.status,
                        // closeOnClickOutside:false
                    });
                    location.reload();
                },
            });

        });
        //-------------- END Call Note --------------------------

        //this is used for unbroken status
        $(document).on('click','.unbroken',function(event) {

            let id = $(this).attr('data-id');

            swal({
                title: "Are you sure?",
                text: "you want to change status to unbreak",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                closeOnClickOutside:false
            }).then((willDelete) => {
                if (willDelete) {
                    
                    updateStatus(id,0);
                }
            });
        });
        //--------------END ----------------------

        //This is used for unbroken status
        $(document).on('click','.status_uncancel',function(event) {

            let id = $(this).attr('data-id');

            swal({
                title: "Are you sure?",
                text: "you want to change status to uncancel",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                closeOnClickOutside:false
            }).then((willDelete) => {
                if (willDelete) {
                    updateStatus(id,0);
                }
            });
        });
        //--------------END ----------------------

        //This function is used to submit the request for update the required status.
        function updateStatus(id,status) {

            $.ajax({
                url: "{{ route('update.appointmentStatus') }}",
                type: "POST",
                data: {appointment_id:id,status:status,_token:"{{ csrf_token() }}"},
                beforeSend:function() {
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait...',
                    
                    });
                },
                success:function(data) {
                    
                    swal.close();
                    if (data.status == true) {

                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success",
                        });
                        resultTable.ajax.reload();
                        getSechduleCount();
                        
                    } else if (data.status == false) {
                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error",
                        });
                    } else {
                        location.reload();
                    }
                },
                error:function (jqXHR, textStatus, errorThrown) {
                    if (jqXHR.status == 500) {
                        console.log('500 status');
                    } else {
                        console.log('something went wrong!');
                    }
                    location.reload();
                },
            });

        }
    });

    

$(function() {

    $('.modal').on('hidden.bs.modal', function (e) {
        // do something...
        $('#current_case_id').parent().css('display','none');
    })

    $('#add_dob').datepicker({
        beforeShow: function(input, inst) {
            $(document).off('focusin.bs.modal');
        },
        onClose:function() {
            $(document).on('focusin.bs.modal');
        },
        "dateFormat":'mm-dd-yy',
        maxDate:new Date(),
        changeMonth:true,
        changeYear:true,
        yearRange:"-100:+100",
    });

    $('#submitted_date').attr('readonly','readonly').datepicker({
        "dateFormat":'mm-dd-yy',
        // maxDate:new Date(),
        changeMonth:true,
        changeYear:true,
        yearRange:"-10:+10",
    });

    

    $(document).on('click','.access_denied',function() {

        swal({
            icon: "error",
            title:'Oops!',
            text: 'You do not have permission to perform this action',
            // buttons: false,
            closeOnClickOutside:false
            
        });
        return false;
    });
});

var editor = CKEDITOR.replace( 'current_special_request');

editor.on( 'change', function( evt ) {
   // getData() returns CKEditor's HTML content.

});


</script>
@endsection