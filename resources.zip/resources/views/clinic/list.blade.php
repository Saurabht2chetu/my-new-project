@extends('layouts.adminlayout')
@section('title','Clinic Management - Moonlight Examinations')

@section('content')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>

    .swal-icon--custom img {
        width:50px!important;
        height:50px!important;
    }
    .swal-modal .swal-text {
        text-align: center;
    }
    .swal-footer {
        text-align: center!important;
    }
    .input-icon-right {
        cursor: pointer;
    }
    .activesection input[type="checkbox"] {
        visibility: hidden;
    }
    .activesection label {
        cursor: pointer;
        text-indent: -9999px;
        width: 40px;
        height: 20px;
        background: grey;
        display: block;
        border-radius: 100px;
        position: relative;
    }
    .activesection label:after {
        content: '';
        position: absolute;
        top: 3px;
        left: 2px;
        width: 15px;
        height: 15px;
        background: #fff;
        border-radius: 90px;
        transition: all 0.3s;
    }
    .activesection input:checked + label {
        background: #ffc107;
    }
    .activesection input:checked + label:after {
        left: calc(100% - 5px);
        transform: translateX(-100%);
    }
    .activesection label:active:after {
        width: 130px;
    }

    .select2-container {
        width: 100%!important;
        /* font-size: 1rem;
        line-height: 1.5;
        color: #495057;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid #ced4da;
        border-radius: 10px!important; */
        transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;

    }

    .select2-results__option {
        padding-right: 20px;
        vertical-align: middle;
    }
    .select2-results__options[aria-multiselectable=true] .select2-results__option:before {
        content: "";
        display: inline-block;
        position: relative;
        height: 20px;
        width: 20px;
        border: 2px solid #e9e9e9;
        border-radius: 4px;
        background-color: #fff;
        margin-right: 20px;
        vertical-align: middle;
    }
    .select2-results__options[aria-multiselectable=true] .select2-results__option--selected:before {
        font-family:fontAwesome;
        content: "\f00c";
        color: #fff;
        background-color: #e1c331;
        border: 0;
        display: inline-block;
        padding-left: 3px;
        font-size: 14px;
    }
    .select2-results__options[aria-multiselectable=true] .select2-container--default .select2-results__option[aria-selected=true] {
        background-color: #fff;
    }
    .select2-results__options[aria-multiselectable=true] .select2-container--default .select2-results__option--highlighted[aria-selected] {
        background-color: #eaeaeb;
        color: #272727;
    }
    .select2-results__options[aria-multiselectable=true] .select2-container--default .select2-selection--multiple {
        margin-bottom: 10px;
    }
    .select2-results__options[aria-multiselectable=true] .select2-container--default.select2-container--open.select2-container--below .select2-selection--multiple {
        border-radius: 4px;
    }
    .select2-results__options[aria-multiselectable=true] .select2-container--default.select2-container--focus .select2-selection--multiple {
        border-color: #f77750;
        border-width: 2px;
    }
    .select2-results__options[aria-multiselectable=true] .select2-container--default .select2-selection--multiple {
        border-width: 2px;
    }
    .select2-container--open .select2-dropdown--below {
        
        border-radius: 6px;
        box-shadow: 0 0 10px rgba(0,0,0,0.5);

    }
    .select2-selection .select2-selection--multiple:after {
        content: '';
    }
    /* select with icons badges single*/
    .select-icon .select2-selection__placeholder .badge {
        display: none;
    }
    .select-icon .placeholder {
    /* 	display: none; */
    }
    .select-icon .select2-results__option:before,
    .select-icon .select2-results__option[aria-selected=true]:before {
        display: none !important;
        /* content: "" !important; */
    }
    .select-icon .select2-search--dropdown {
        display: none;
    }
    .green {
        background-color: #96D35F;
        border-radius: 10px;
    }
    .red {
        height: 30px;
        width: 30px;
        background-color: #FF2600;
        border-radius: 10px;
    }
    .yellow {
        height: 30px;
        width: 30px;
        background-color: #FFF76B;
        border-radius: 10px;
    }

    .dataTables_wrapper .dataTables_processing {
        position: fixed !important;
        top: 0!important;
        left: 0!important;
        bottom: 0!important;
        display: flex;
        right: 0!important;
        justify-content: center!important;
        align-items: center!important;
        /* vertical-align: middle!important; */
        /* z-index: 99999!important; */
        width: 100%!important;
        height: 100%!important;
        margin-left: 0!important;
        margin-top: 0!important;
        /* padding-top: 20px!important; */
        /* text-align: center!important; */
        font-size: 1.2em!important;
        background: #0000002e!important;
    
    }

    .dataTables_wrapper .dataTables_processing img {
        position: relative;
        top: 50%;
    }

    .master-seach-section {
        overflow-x: unset !important;
    }
    .search-dropdown-content {
        display: block;
        position: absolute;
        width: 90%;
        max-height: 420px;
        overflow: auto;
        background: #efefef;
        padding: 0 0px;
        z-index: 90;
        margin-top: -16px;
    }

    .search-dropdown-content table tr td,.search-dropdown-content table tr th {
        text-align: center;
    }

    .clinic-table select.form-control:not([size]):not([multiple])
    {
        height: calc(1.5rem + -5px);
    }

    #chkbox {
        pointer-events: none
    }

</style> 
<div class="container-fluid">
    <div class="db-top4-box-wrapper">
        <div class="mt-3 hm-dis">
            <p class="db-heading">
            @if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID'])
                <a href="{{ route('dashboard') }}">Dashboard / </a> @endif Clinic List
            </p>
            @if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID'])
                <button class="btn-main on-call-btn" data-toggle="modal" data-target="#onCallStatement"> On Call Number</button>
                <button class="btn-main clinic-btn" data-toggle="modal" data-target="#clinicAddModal"><i
                    class="fas fa-plus"></i> Add Clinic</button>
            @endif
        </div>
        @if (session('status'))
            <div class="alert alert-success" role="alert">
                {{ session('status') }}
            </div>
        @endif
        <!-- Add On Call Statement Starts -->
        <div class="modal fade md-round" id="onCallStatement" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content mc-clinic">

                    <div class="p-3">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="login-form">
                            <div class="text-center mb-4">
                                <h4>On Call Number</h4>
                            </div>
                            <form id="updateOnCallStatement">
                                <div class="form-group cli-grp">
                                    <div class="formicon-parent">
                                        <textarea class="form-control frm-input-2"
                                            id="on_call_statement" rows="2" name="onCallStatement" ><?php echo $onCallStatement; ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="formicon-parent">
                                        <button type="submit" class="btn btn-block login-btn-01 login-btn-02">SUBMIT</button>
                                        <span><i class="fas fa-arrow-right login-icon-right arro"></i></span>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- Add On Call Statement End -->
        <!-- Edit Clinic Form Starts -->
        <div class="modal fade md-round" id="clinicUpdateModal" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content mc-clinic">

                    <div class="p-3">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="login-form">
                            <div class="text-center mb-4">
                                <h4>Update Clinic</h4>
                            </div>
                            <form id="updateForm">
                                <input type="hidden" id="preServiceDate" name="preServiceDate" value=''>
                                <input type="hidden" id="preclinicLocation" name="preclinicLocation" value=''>
                                <input type="hidden" id="clinic_appoinment_id" name="appoinment_id" value=''>
                                <div class="form-group cli-grp">
                                    <label for="clinic_name">Clinic Name <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <!-- <input type="text" class="form-control frm-input-2"
                                            placeholder="Clinic Name" id="clinic_name" name="clinic_name" readonly required> -->
                                        <select class="form-control" id="clinic_name" name="location">
                                        <?php
                                            if (count($allClinics) > 0) {
                                                foreach($allClinics as $clinic) {
                                                    echo '<option value="'.$clinic->id.'">'.$clinic->name.'</option>';
                                                }
                                            }
                                        ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group cli-grp">
                                    <label for="actual_address">Actual Address</label>
                                    <div class="formicon-parent">
                                        <textarea class="form-control frm-input-2"
                                            id="actual_address" rows="2"  name="actual_address" readonly></textarea>
                                    </div>
                                </div>
                                <div class="form-group cli-grp">
                                    <label for="service_date">Service Date <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <input type="text" class="form-control frm-input-2"
                                            placeholder="10/14/2021" id="add_service_date" name="service_date" required >
                                    </div>
                                </div>
                                
                                <div class="form-group cli-grp">
                                    <label for="examiner_list">Examiners </label>
                                    <div class="formicon-parent">
                                        
                                        <select class="form-control" id="examiner_list" name="examiner_list[]" multiple>
                                            <?php
                                            $userlist = getuserByRoleId($_ENV['EXAMINER_ROLE_ID']);
                                            
                                            if(count($userlist) > 0) {

                                                foreach($userlist as $list) {
                                                    echo '<option data-badge="" value="'.$list->id.'">'.$list->name.'</option>';
                                                }
                                            }
                                            ?>
                                        </select>  
                                    </div>
                                </div>
                                <div class="form-group cli-grp">
                                    <label for="assistant_list">Clinic Assistants </label>
                                    <div class="formicon-parent">
                                        <select class="form-control" id="assistant_list" name="assistant_list[]" multiple>
                                            <?php
                                                $userlist = getuserByRoleId($_ENV['ASSISTANT_ROLE_ID']);
                                            
                                                if(count($userlist) > 0) {

                                                    foreach($userlist as $list) {
                                                        echo '<option data-badge="" value="'.$list->id.'">'.$list->name.'</option>';
                                                    }
                                                }
                                            ?>
                                        </select> 
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="formicon-parent">
                                        <button type="submit" class="btn btn-block login-btn-01 login-btn-02">SUBMIT</button>
                                        <span><i class="fas fa-arrow-right login-icon-right arro"></i></span>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- Edit Clinic Form End -->
        
        <!-- Add Clinic Form Starts -->
        <div class="modal fade md-round" id="clinicAddModal" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content mc-clinic">

                    <div class="p-3">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="login-form">
                            <div class="text-center mb-4">
                                <h4>Add Clinic</h4>
                            </div>
                            <form id="clinicAddForm">
                                <div class="form-group cli-grp">
                                    <label for="clinicName">Clinic Name <span class="text-danger">*</span></label>
                                    <div class="formicon-parent disable-check ">
                                        <select class="form-control" id="clinicName" name="clinicName">
                                        <!-- <option value="">- Select -</option> -->
                                        <?php
                                            if(count($allClinics) > 0) {
                                                foreach($allClinics as $clinic) {
                                                    echo '<option data-badge="" value="'.$clinic->id.'">'.$clinic->name.'</option>';
                                                }
                                            }
                                        ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group cli-grp">
                                    <label for="actual_address">Actual Address</label>
                                    <div class="formicon-parent">
                                        <textarea class="form-control frm-input-2"
                                            id="add_actual_address" rows="2" name="add_actual_address" readonly></textarea>
                                    </div>
                                </div>
                                <div class="form-group cli-grp">
                                    <label for="serviceDate">Service Date <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <input type="text" class="form-control frm-input-2"
                                            placeholder="mm-dd-yy" id="serviceDate" name="serviceDate" required >
                                    </div>
                                </div>
                                <div class="form-group cli-grp">
                                    <label for="examiner_list">Examiners </label>
                                    <div class="formicon-parent multiselect">
                                        <select class="form-control" id="addExaminerList" name="addExaminerList[]" multiple>
                                            <?php
                                            $userlist = getuserByRoleId($_ENV['EXAMINER_ROLE_ID']);
                                            
                                            if (count($userlist) > 0) {
                                                foreach($userlist as $list) {
                                                    echo '<option data-badge="" value="'.$list->id.'">'.$list->name.'</option>';
                                                }
                                            }
                                            ?>
                                        </select>  
                                    </div>
                                </div>
                                <div class="form-group cli-grp">
                                    <label for="assistant_list">Clinic Assistants </label>
                                    <div class="formicon-parent">
                                        <select class="form-control" id="addAssistantList" name="addAssistantList[]" multiple>
                                            <?php
                                                $userlist = getuserByRoleId($_ENV['ASSISTANT_ROLE_ID']);
                                            
                                                if(count($userlist) > 0) {

                                                    foreach($userlist as $list) {
                                                        echo '<option data-badge="" value="'.$list->id.'">'.$list->name.'</option>';
                                                    }
                                                }
                                            ?>
                                        </select> 
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="formicon-parent">
                                        <button type="submit" class="btn btn-block login-btn-01 login-btn-02">SUBMIT</button>
                                        <span><i class="fas fa-arrow-right login-icon-right arro"></i></span>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- Add Clinic Form End-->

        <!-- Add Comments on Clinic Cancel Form Starts-->
        <div class="modal fade bd-example-modal-md" id="cancelCommentModal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-md modal-dialog-centered">
                <div class="modal-content sticky">
                    <div class="">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="text-center">
                        <h5>Are you sure?</h5>
                        <p>You want to cancel all the clinic appointments for this date</p>
                    </div>
                    <form id="cancelCommentForm">
                        <div class="form-group">
                            <input type="hidden" name="serviceDate" id="cancelServiceDate" value="">
                            <input type="hidden" name="locationId" id="cancelLocationId" value="">
                            <input type="hidden" name="actionStatus" id="cancel_status" value="<?php echo $_ENV['APPT_STATUS_CANCEL'] ?>">
                            <textarea class="form-control" id="cancel_comment" name="cancel_comment" rows="5" placeholder="Write comment here...."></textarea>
                        </div>
                        <div class="text-center py-2">
                            <button class="lft-arrow sti-1">Submit</button>
                            <button class="rgt-arrow sti-1" data-dismiss="modal" aria-label="Close">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- Add Comments on Clinic Cancel Form End-->

        <!-- Change Color Reason Form Starts-->
        <div class="modal fade bd-example-modal-md" id="changeColorModal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-md modal-dialog-centered">
                <div class="modal-content sticky">
                    <div class="">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="text-center">
                        <h5>Are you sure?</h5>
                        <p>You want to change the color status of this clinic</p>
                    </div>
                    <form id="updateColorForm">
                        <div class="form-group">
                            <input type="hidden" name="serviceDate" id="colorServiceDate" value="">
                            <input type="hidden" name="locationId" id="colorLocationId" value="">
                            <select class="form-control" id="clinic_status" name="clinicStatus">
                                <option value="0">Green</option>    
                                <option value="1">Red</option>
                                <option value="2">Yellow</option>
                            </select>
                            <select class="form-control" id="clinic_reason" name="clinicReason">
                                <option value="LVC">LVC</option>    
                                <option value="Examiner">Examiner</option>
                                <option value="Clinic Assistant">Clinic Assistant</option>
                                <option value="Weather">Weather</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="text-center py-2">
                            <button class="lft-arrow sti-1">Submit</button>
                            <button class="rgt-arrow sti-1" data-dismiss="modal" aria-label="Close">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- Change Color Reason Form End-->

        <!-- Add Clinic Form Starts -->
        <div class="modal fade md-round" id="exportModal" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content mc-clinic">
                    <div class="p-3">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="login-form">
                            <div class="text-center mb-4">
                                <h4>Choose date range</h4>
                            </div>
                            <form id="exportDetailsForm" method="post" action="{{ route('masterExport') }}">
                                @csrf
                                <div class="form-group cli-grp">
                                    <label for="export_from_date">From <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <input type="text" class="form-control frm-input-2"
                                            placeholder="mm-dd-yy" id="export_from_date" name="from_date" required >
                                    </div>
                                </div>

                                <div class="form-group cli-grp">
                                    <label for="export_to_date">To <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <input type="text" class="form-control frm-input-2"
                                            placeholder="mm-dd-yy" id="export_to_date" name="to_date" required >
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <div class="formicon-parent">
                                        <button type="button" class="btn btn-block login-btn-01 login-btn-02" id="exportSubmit" >EXPORT</button>
                                        <span><i class="fas fa-arrow-right login-icon-right arro"></i></span>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- Add Clinic Form End-->

        <!-- Change X-Rays status Starts--> 
        <div class="modal fade bd-example-modal-md" id="xraysModal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-md modal-dialog-centered">
                <div class="modal-content sticky">
                    <div class="">
                        <button type="button" class="close"  data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="text-center">
                        <h5>Are you sure?</h5>
                        <p>You want to change the status!</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary changes_status" data-dismiss="modal" >Close</button>
                        <button type="button" class="btn btn-primary changes_status" id="status_id" data-row_id="" data-service_date="" data-location_id="" >Yes</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Change X-Rays status End-->


    </div>
    <div class="dashboard-table1 mb-0">
        
        <form id="filterRecordForm">

            <div class="row" style="align-items: end;">
                
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="select_state">Select State</label>
                        <select class="form-control" id="select_state" name="select_state[]" multiple>
                            @foreach($statelist as $list)
                            <option data-badge="" value="{{$list->id}}">{{$list->name}}</option>
                            @endforeach
                        </select>                                  
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                        <label for="from_date">From</label>
                        <input type="text" class="form-control" id="from_date" name="from_date">
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                        <label for="to_date">To</label>
                        <input type="text" class="form-control" id="to_date" name="to_date">
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                        <button class="btn-main clinic-btn">Search</button>
                    </div>
                </div>
            </div>
        </form>
    
    </div>
    
    @if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID'])
        <div class="dashboard-table1 mb-0 master-seach-section">
                        
            <div class="row" style="align-items: end;">
                <div class="col-md-6">
                    <div class="form-group">
                    <label for="searchExaminee">Search Examinee </label>
                        <input type="text" class="form-control" id="master_search" name="search">                            
                    </div>
                    
                </div>
                <div class="col-md-6">
                    <div class="form-group" style="float:right;">
                        <button class="btn-main clinic-btn" data-toggle="modal" data-target="#exportModal">Master Export</button>
                    </div>
                </div>
            </div>
    
            <div class="table-responsive search-dropdown-content" style="display:none;">
                <table class="table table-striped table-bordered examinee_search table-hover table-sm mb-0">
                    <thead>
                        <tr>
                            <th scope="col" style="width: 13%;">Service Date</th>
                            <th scope="col">Location</th>
                            <th scope="col" style="width: 16%;">Examinee</th>
                            <th scope="col">Phone</th>
                            <th scope="col" style="width: 13%;">DOB</th>
                            <th scope="col" style="width: 13%;">Case Id</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody> 
                </table>
            </div>
        
        </div>
    @endif
    
    <div class="dashboard-table1">
        @if(session('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>{{ session('success') }}</strong> 
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div>
    @endif
        <div class="row">
            <div class="col-md-12">

                <form action="{{ route('post.downloadClinicDocuments') }}" method="post" id="clinic_document_form">
                    @csrf
                    <input type="hidden" name="service_date" id="document_service_date">
                    <input type="hidden" name="location" id="document_location_id">
                </form>

                <table class="stripe clinic-table" style="width:100%">
                    <thead>
                        <tr>
                            @if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID'])
                                <th style="width:5%;">Preclinic Sent </th>    
                                <th style="width:5%;"></th>
                            @endif
                            <th style="width:12%;">Service Date</th>
                            <th>Location</th>
                            <th>Examiner</th>
                            <th>Clinic Assistants</th>
                            <th>Examinee List</th>
                            <th>Clinic Documents</th>
                            
                            @if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID'])
                                <th>X-Rays</th>
                                <th>Invoices</th>
                            @endif
                            <th>Records</th>
                            @if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID'])
                                <th>Action</th>
                            @endif
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <form id="buildinvoicepdf" action="{{ route('invoicepdf.build') }}" method="POST">
        @csrf
        <input type="hidden" id="invoiceServiceDate" name="invoiceServiceDate" value=''>
        <input type="hidden" id="invoiceLocationId" name="invoiceLocationId" value=''>
    </form>
    <form id="buildcepacketpdf" action="{{ route('cepacketpdf.build') }}" method="POST">
        @csrf
        <input type="hidden" id="cepacketServiceDate" name="cepacketServiceDate" value=''>
        <input type="hidden" id="cepacketLocationId" name="cepacketLocationId" value=''>
    </form>
    <form id="downloadinvoicefromS3Form" action="{{ route('post.downloadinvoicefromS3') }}" method="post">
        @csrf
        <input type="hidden" id="mergedinvoiceServiceDate" name="mergedinvoiceServiceDate" value=''>
        <input type="hidden" id="mergedinvoiceLocationId" name="mergedinvoiceLocationId" value=''>
    </form>
    <form id="downloadrecordfromS3Form" action="{{ route('post.downloadrecordfromS3') }}" method="post">
        @csrf
        <input type="hidden" id="mergedRecordServiceDate" name="mergedRecordServiceDate" value=''>
        <input type="hidden" id="mergedRecordLocationId" name="mergedRecordLocationId" value=''>
    </form>
    <div style="display:none;" id="invoiceloader">
        <img src="{{ url('/assets/images/loader.gif') }}" alt="">
    </div>
</div>

<!-- cdn link of select2 jquery -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.13.0/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.13.0/jquery-ui.js"></script>

<script>

    function setDefaultDate(date) {

        let dayOfWeekNumber = date.getDay();
        let adjustDate = date;

        switch(dayOfWeekNumber) {
            case 0: 
                nameOfDay = 'Sunday';
                adjustDate.setDate(adjustDate.getDate() + 3);
                return adjustDate;
                break;
            case 1:
                nameOfDay = 'Monday';
                adjustDate.setDate(adjustDate.getDate() + 2);
                return adjustDate;
                break;
            case 2:
                nameOfDay = 'Tuesday';
                adjustDate.setDate(adjustDate.getDate() + 1);
                return adjustDate;
                break;
            case 3:
                nameOfDay = 'Wednesday';
                return adjustDate;
                break;
            case 4:
                nameOfDay = 'Thursday';
                adjustDate.setDate(adjustDate.getDate() - 1);
                return adjustDate;
                break;
            case 5:
                nameOfDay = 'Friday';
                adjustDate.setDate(adjustDate.getDate() - 2);
                return adjustDate;
                break;
            case 6:
                nameOfDay = 'Saturday';
                adjustDate.setDate(adjustDate.getDate() - 2);
                return adjustDate;
                break;

        }
    }

    $(function () {

        $('#master_search').keyup(function(e) {

            console.log(e);
            var searchKeyword = this.value;
            
            if (searchKeyword.length > 2) {
                $('.search-dropdown-content').css('display','block');
            } else {
                $('.search-dropdown-content').css('display','none');
            }

            if (searchKeyword.length > 2) {

                $.ajax({
                    url: "{{route('search_examinee.get')}}",
                    type: "GET",
                    dataType:'json',
                    data: {searchKeyword:searchKeyword,_token:"{{csrf_token()}}"},
                    success:function(output){
                        
                        if (output.status == true) {
                            $('.examinee_search tbody').empty();
                            var data = output.data;
                            console.log(output);
                            var trHTML = '';
                            $.each(data, function (i, item) {
                                url = "{{ url('examinee-list') }}/"+item.service_date+'/'+item.location_id;
                                console.log(url);
                                trHTML += '<tr> <td>' + item.appointment_date + '</td><td><a style="color: #212529;" target="_blank" href='+"'"+url+"'"+'">' + item.clinic_name + '</a></td><td>' + item.examinee_name + '</td><td>' + item.examinee_phone + '</td><td>' + item.examinee_dob + '</td><td>' + item.case_id + '</td></tr>';
                            });
                            $('.examinee_search tbody').append(trHTML);
                        } else if (output.status == false) {
                            $('.examinee_search tbody').empty();
                            $('.examinee_search tbody').append('<tr><td colspan="6">No Record Found</td></tr>');
                        } else {
                            location.reload();
                        }
                    },
                    error:function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            console.log('500 status');
                        } else {
                            console.log('something went wrong!');
                        }
                        window.location.reload(true);
                    },
                });
            }
        });
        
        // $('#master_search').focusout(function(e) {
        //     console.log(e);
        //     $('.search-dropdown-content').css('display','none');
        // });
        

        $('#invoiceloader').css('display','none');

        $('#examiner_list').select2({
            closeOnSelect : false
        });

        $('#assistant_list').select2({
            closeOnSelect : false
        });

        $('#addExaminerList').select2({
            closeOnSelect : false
        });

        $('#addAssistantList').select2({
            closeOnSelect : false
        });

        $('#select_state').select2({
            closeOnSelect : false
        });

        $('#clinicName').select2({
            closeOnSelect : true
        });

        $('#clinic_name').select2({
            closeOnSelect : true
        });

        $('#searchExaminee').select2({
            closeOnSelect : false
        });

        let previous_date = new Date();
        let next_date = new Date();
        previous_date.setDate(previous_date.getDate() - 7).toLocaleString();
        next_date.setDate(next_date.getDate() + 7).toLocaleString();
        let from_date = setDefaultDate(new Date(previous_date));
        let to_date = setDefaultDate(new Date(next_date));

        $("#from_date" ).attr('readonly','readonly').datepicker({
            "dateFormat":'mm-dd-yy',
            changeMonth:true,
            changeYear:true,
            yearRange:"-10:+10",
            onSelect:function (e) {
                console.log('datepicker',e);
                $( "#to_date" ).datepicker("option","minDate",e);
            }
        }).datepicker("setDate",from_date);

        $( "#to_date" ).attr('readonly','readonly').datepicker({
            "dateFormat":'mm-dd-yy',
            changeMonth:true,
            changeYear:true,
            yearRange:"-10:+10",
            minDate:$('#from_date').val(),
            onSelect:function (e) {
                $( "#from_date" ).datepicker("option","maxDate",e);
            }
        }).datepicker("setDate",to_date);

        $( "#add_service_date" ).attr('readonly','readonly').datepicker({
            "dateFormat":'mm-dd-yy'
        });

        
        $("#export_from_date" ).attr('readonly','readonly').datepicker({
            "dateFormat":'mm-dd-yy',
            changeMonth:true,
            changeYear:true,
            yearRange:"-10:+10",
            onSelect:function (e) {
                console.log('datepicker',e);
                let currentDate = new Date(e);
                currentDate.setDate(currentDate.getDate() + 14).toLocaleString();
                
                $( "#export_to_date" ).datepicker("option","maxDate",currentDate);
                $( "#export_to_date" ).datepicker("option","minDate",e);
            }
        }).datepicker("setDate",new Date());
        
        $("#export_to_date" ).attr('readonly','readonly').datepicker({
            "dateFormat":'mm-dd-yy',
            changeMonth:true,
            changeYear:true,
            yearRange:"-10:+10",
            onSelect:function (e) {
                let currentDate = new Date(e);
                currentDate.setDate(currentDate.getDate() - 14).toLocaleString();
                
                $( "#export_from_date" ).datepicker("option","maxDate",e);
                $( "#export_from_date" ).datepicker("option","minDate",currentDate);
            }
        }).datepicker("setDate",new Date());

        $(document).on('click','#exportSubmit',function() {

            $('#exportModal').modal('hide');
            $('#exportDetailsForm').submit();
            
        });
        // Fetch all Clinic Service data
        var resultTable = $('.clinic-table').DataTable({
            processing: true,
            serverSide: false,
            order: [],
            "language": {
                "processing": "<img style='width:80px; height:80px;' src='{{url('/assets/images/loaderspinner.gif')}}' >"
            },
            ajax:{
                url:"{{ route('clinic-list') }}",
                data:function(data) {
                    data.from_date = $('#from_date').val();
                    data.to_date = $('#to_date').val();
                    data.state = $('#select_state').val();
                }
            },
            columns: [
                <?php if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID']) { ?>
                {data: 'pre_clinic_sent', name: 'pre_clinic_sent', orderable: false},
                {data: 'designation', name: 'designation'},
                <?php } ?>
                {data: 'service_date', name: 'service_date'},
                {data: 'location_name', name: 'location_name'},
                {data: 'examiner_list', name: 'examiner_list'},
                {data: 'assistant', name: 'assistant', orderable: true, searchable: true},
                {data: 'examinee', name: 'examinee', orderable: false, searchable: false},
                {data: 'clinic_document', name: 'clinic_document', orderable: false, searchable: false},
                <?php if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID']) { ?>
                {data: 'x_rays', name: 'x_rays', orderable: false},
                {data: 'invoice', name: 'invoice', orderable: false, searchable: false},
                <?php } ?>
                {data: 'cepacket', name: 'cepacket', orderable: false, searchable: false},
                <?php if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID']) { ?>
                {data: 'action', name: 'action', orderable: false, searchable: false},
                <?php } ?>
                
            ],
            "createdRow": function( row, data, dataIndex ) {
               console.log('datas',{row, data, dataIndex});
               if(parseInt(data.sticky_count) > 0) {
                   $(row).css('background','#f9e095');
               }
            }
        });

        $(document).on('submit','#filterRecordForm',function(e){

            e.preventDefault();
            resultTable.ajax.reload();
        });

        // Validation on add clinic service
        $("#clinicAddForm").validate({

            rules: {
                clinicName:{
                    required:true,
                },
                serviceDate:{
                    required:true,
                },
                "addExaminerList[]":{
                    // required:true,
                }                    
            },

            messages: {
                clinicName:{
                    required:"Clinic Name is required",
                },
                serviceDate:{
                    required:"Service Date is required",
                }, 
                addExaminerList: {
                    // required:"Examiner is required",
                }
            },

            errorPlacement: function(label, element) {

                label.addClass('mt-2 text-danger');
                console.log(element)
                // label.insertAfter(element);
                element.parent().append(label);

            },

            highlight: function(element, errorClass) {

                $(element).parent().addClass('has-danger');

                $(element).addClass('form-control-danger');

            },

            unhighlight: function(element, errorClass, validClass) {

                $(element).parents().removeClass('has-danger');

                    $(element).removeClass('form-control-danger');

                $(element).parents('.form-group').addClass('has-success');

            }
        });

        // Validation on add or update on call statement
        $("#updateOnCallStatement").validate({
            rules: {
                onCallStatement:{
                    required:true,
                }                 
            },
            messages: {
                onCallStatement:{
                    required:"On Call Statement is required",
                }
            },

            errorPlacement: function(label, element) {
                label.addClass('mt-2 text-danger');
                console.log(element)
                element.parent().append(label);
            },
            highlight: function(element, errorClass) {
                $(element).parent().addClass('has-danger');
                $(element).addClass('form-control-danger');
            },
            unhighlight: function(element, errorClass, validClass) {
                $(element).parents().removeClass('has-danger');
                $(element).removeClass('form-control-danger');
                $(element).parents('.form-group').addClass('has-success');
            }
        });

        // To add Clinic Service data
        $(document).on('submit', '#clinicAddForm', function (e) {
            e.preventDefault();
            if (!$("#clinicAddForm").valid()) {
                alert('Something went wrong at the time of filling the form');
                return;
            }

            $.ajax({
                url: "{{ route('clinicservice.add') }}",
                type:"post",
                data: $(this).serialize() +'&_token='+"{{ csrf_token() }}",
                beforeSend:function() {
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    
                    });
                },
                success:function(data){
                    // console.log(data, 'forms');
                    swal.close();
                    if (data.status == true) {
                        $('#clinicAddModal').modal('hide');
                        resultTable.ajax.reload();
                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success",
                        });

                    } else if (data.status == false) {
                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error",
                        });
                    } else {
                        location.reload();
                    }
                },
                error:function (jqXHR, textStatus, errorThrown) {
                    swal({
                        icon: "error",
                        title:'Oops!',
                        text: 'soemthing went wrong, Response StatusCode - '+jqXHR.status,
                        buttons: false,
                        closeOnClickOutside:false
                    });
                    window.location.reload(true);
                },
            });
        });

        // To get Actual address based on location
        $(document).on('change','#clinicName, #clinic_name', function () {

            var locationId = this.value;
            
            $.ajax({
                url: "{{ route('location.get')}}",
                type: "GET",
                dataType:'json',
                data: {id:locationId, _token:"{{csrf_token()}}"},
                beforeSend:function() {
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait...',
                    });
                },
                success:function(output) {
                    
                    swal.close();
                    if (output.status == true) {
                        var data = output.data;
                        $('#add_actual_address').val(data.actual_address);
                        $('#actual_address').val(data.actual_address);
                    } else if (output.status == false) {
                        swal({
                            title: "Oops!",
                            text: output.msg,
                            icon: "error",
                        });
                    } else {
                        location.reload();
                    }
                    
                },
                error:function (jqXHR, textStatus, errorThrown) {
                    if (jqXHR.status == 500) {
                        console.log('500 status');
                    } else {
                        console.log('something went wrong!');
                    }
                    window.location.reload(true);
                },
            });
            
        });

        // Add validation on update clinic service data
        $("#updateForm").validate({
            rules: {

                examiner_list:{
                    required:true
                }

            },
            messages: {
                examiner_list:{
                    required:"Examiner is required",
                }
            },
            errorPlacement: function(label, element) {
                label.addClass('mt-2 text-danger');
                label.insertAfter(element);
            },
            highlight: function(element, errorClass) {
                $(element).parent().addClass('has-danger');
                $(element).addClass('form-control-danger');
            },

            unhighlight: function(element, errorClass, validClass) {
                $(element).parents().removeClass('has-danger');
                $(element).removeClass('form-control-danger');
                $(element).parents('.form-group').addClass('has-success');
            }
        });

        // To get clinic service data to update
        $(document).on('click','.editbtn', function(){
            let date = $(this).attr('data-date');
            let location = $(this).attr('data-location');

            $.ajax({
                url:"{{ route('get.examinerlist') }}",
                type:'GET',
                dataType:'json',
                data: {_token:"{{ csrf_token()}}",date:date,location:location},

                success:function(output) {
                    if (output.status == true) {
                        let data = output.data;
                        console.log(output);
                        $('#preclinicLocation').val(data.location_id);
                        $('#preServiceDate').val(data.service_date);
                        $('#clinic_appoinment_id').val(data.id);
                        $('#clinic_name').val(data.location_id).trigger('change');
                        $('#actual_address').val(data.location_address);
                        $('#add_service_date').val(output.edit_service_date);
                        $('#examiner_list').val(output.examiner_list.split(",")).trigger('change');
                        $('#assistant_list').val(output.assistant_list.split(",")).trigger('change');
                        $('#clinicUpdateModal').modal('show');
                    } else if (output.status == false) {
                        swal({
                            title: "Oops!",
                            text: output.msg,
                            icon: "error",
                        });
                    } else {
                        location.reload();
                    }
                },
                error:function (jqXHR, textStatus, errorThrown) {
                    if (jqXHR.status == 500) {
                        console.log('500 status');
                    } else {
                        console.log('something went wrong!');
                    }
                    window.location.reload(true);
                },
            });
        });

        // To cancel a clinic's appointments for a date
        $(document).on('click', '.cancelbtn', function() {

            let serviceDate  = $(this).attr('data-date');
            let locationId   = $(this).attr('data-location');
            let actionStatus = $(this).attr('data-action');

            swal({
                title: "Are you sure?",
                text: "You want to change the status of all the clinic appointments for this date!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                closeOnClickOutside:false
            }).then((willCancel) => {
                if (willCancel) {
                    $.ajax({
                        url:"{{ route('clinicservice.cancel') }}",
                        type:'POST',
                        data: {_token:"{{ csrf_token()}}", serviceDate:serviceDate, locationId:locationId, actionStatus:actionStatus},
                        beforeSend:function() {
                            swal({
                                icon: "{{ url('/assets/images/loader.gif') }}",
                                text: 'Please Wait!',
                                buttons: false,
                                closeOnClickOutside:false
                            });
                        },
                        success:function(data) {
                            swal.close();
                            if (data.status == true) {
                                resultTable.ajax.reload();
                                swal({
                                    title: "Great!",
                                    text: data.msg,
                                    icon: "success"
                                });
                            } else if (data.status == false) {
                                swal({
                                    title: "Oops!",
                                    text: data.msg,
                                    icon: "error"
                                });
                            } else {
                                location.reload();
                            }
                        },
                        error:function (jqXHR, textStatus, errorThrown) {
                            swal({
                                icon: "error",
                                title:'Oops!',
                                text: 'something went wrong, Response Status Code - '+jqXHR.status,
                                closeOnClickOutside:false
                            });
                            window.location.reload(true);
                        },
                    });
                } else { }
            });
        });

        // To reverse a cancelled clinic and date combined record 
        $(document).on('click','.reactivatebtn',function(event) {

            let serviceDate  = $(this).attr('data-date');
            let locationId   = $(this).attr('data-location');
            $('#cancelServiceDate').val(serviceDate);
            $('#cancelLocationId').val(locationId);

            $('#cancelCommentModal').modal('show')
        });

        $(document).on('submit', '#cancelCommentForm', function(e) {

            e.preventDefault();

            $.ajax({
                url: "{{ route('clinicservice.cancel') }}",
                type: "POST",
                data:$(this).serialize() + '&_token='+"{{ csrf_token() }}",
                beforeSend:function() {
                    
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    });

                },
                success:function(data) {

                    swal.close();

                    if (data.status == true) {
                        $('#cancelCommentModal').modal('hide')

                        resultTable.ajax.reload();

                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success"
                        });

                    } else if (data.status == false) {

                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error"
                        });
                    } else {
                        location.reload();
                    }
                },
                error:function (jqXHR,textStatus,errorThrown) {
                    swal({
                        icon: "error",
                        title:'Oops!',
                        text: 'something went wrong, Response Status Code - '+jqXHR.status,
                        closeOnClickOutside:false
                    });
                    window.location.reload(true);
                },
            });
        });

        // To change the color of a clinic and date combined record 
        $(document).on('click','.changecolor',function(event) {

            let serviceDate  = $(this).attr('data-date');
            let locationId   = $(this).attr('data-location');
            let colorStatus   = $(this).attr('data-color-status');
           

            $('#colorServiceDate').val(serviceDate);
            $('#colorLocationId').val(locationId);
            $('#color_status').val(colorStatus);
            let status = $(this).attr('data-color-status');
            $('#clinic_status option').each(function(){
                // $(this).css('display','block');
                if (this.value == status) {
                    $(this).attr('selected','selected')
                    // $(this).css('display','none');
                }
            });
            $('#changeColorModal').modal('show')
        });

        $(document).on('change','.change_color_option',function(e){
            console.log(e.target.dataset);
            
            if ($(this).val() == '0') {

                swal({
                    title: "Are you sure?",
                    text: "you want to change the color to green",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                    closeOnClickOutside:false
                }).then((willDelete) => {
                    let serviceDate  = e.target.dataset.date;
                    let locationId   = e.target.dataset.location;
                    let colorStatus   = e.target.dataset.colorStatus;

                    $('#colorServiceDate').val(serviceDate);
                    $('#colorLocationId').val(locationId);
                    $('#clinic_status').val($(this).val()).css('display','none');

                    $('#updateColorForm').submit();
                });

            } else {

                let serviceDate  = e.target.dataset.date;
                let locationId   = e.target.dataset.location;
                let colorStatus   = e.target.dataset.colorStatus;

                $('#colorServiceDate').val(serviceDate);
                $('#colorLocationId').val(locationId);
                $('#clinic_status').val($(this).val()).css('display','none');
                $('#changeColorModal').modal('show');
            }
            
        });

        $(document).on('change','#clinic_status',function(){
            alert($(this).val())
            $('#clinic_reason').css('display','block');
            if ($(this).val() == 0) {
                $('#clinic_reason').css('display','none');
            } else if ($(this).val() == 1) {
                // $('#clinic_reason').css('display','none');
            } else {

            }
        });

        // To submit the change Color Form
        $(document).on('submit', '#updateColorForm', function(e) {

            e.preventDefault();

            $.ajax({
                url: "{{ route('cliniccolor.update') }}",
                type: "POST",
                data:$(this).serialize() + '&_token='+"{{ csrf_token() }}",
                beforeSend:function() {
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    });
                },
                success:function(data) {
                    swal.close();
                    if (data.status == true) {
                        $('#changeColorModal').modal('hide')

                        resultTable.ajax.reload();

                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success"
                        });

                    } else if (data.status == false) {

                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error"
                        });
                    } else {
                        location.reload();
                    }
                },
                error:function (jqXHR,textStatus,errorThrown) {
                    swal({
                        icon: "error",
                        title:'Oops!',
                        text: 'something went wrong, Response Status Code - '+jqXHR.status,
                        closeOnClickOutside:false
                    });
                    window.location.reload(true);
                },
            });
        });

        // this is to delete a clinic and date combined record 
        $(document).on('click', '.deletebtn', function(event) {

            let serviceDate  = $(this).attr('data-date');
            let locationId   = $(this).attr('data-location');

            swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover the Clinic for this date",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                closeOnClickOutside:false
            }).then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        url: "{{route('clinicservice.delete')}}",
                        type: "POST",
                        data: {_token:"{{ csrf_token()}}", serviceDate:serviceDate, locationId:locationId},
                        beforeSend:function() {
                            swal({
                                icon: "{{ url('/assets/images/loader.gif') }}",
                                text: 'Please Wait...',
                            });
                        },
                        success:function(data){
                            swal.close();
                            if (data.status == true) {
                                resultTable.ajax.reload();
                                swal({
                                    title: "Great!",
                                    text: data.msg,
                                    icon: "success",
                                });
                            } else if (data.status == false) {
                                swal({
                                    title: "Oops!",
                                    text: data.msg,
                                    icon: "error",
                                });
                            } else {
                                location.reload();
                            }
                        },
                        error:function (jqXHR, textStatus, errorThrown) {
                            if (jqXHR.status == 500) {
                                console.log('500 status');
                            } else {
                                console.log('something went wrong!');
                            }
                            window.location.reload(true);
                        },
                    });
                } else {}
            });
        });

        // To Update Clinic Service Data
        $(document).on('submit', '#updateForm', function(e) {
            e.preventDefault();

            if (!$('#updateForm').valid()) {
                alert('Something went wrong at time of filling the form');
                return;
            }

            $.ajax({
                url:"{{ route('update.clinicservice') }}",
                type:'POST',
                data:$(this).serialize() + '&_token='+"{{ csrf_token() }}",
                beforeSend:function() {
                    
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    });

                },
                success:function(data) {
                    swal.close();

                    if (data.status == true) {

                        $('#clinicUpdateModal').modal('hide');

                        resultTable.ajax.reload();

                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success"
                        });

                    } else if (data.status == false) {

                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error"
                        });
                    } else {
                        location.reload();
                    }
                },
                error:function (jqXHR,textStatus,errorThrown) {

                    swal({
                        icon: "error",
                        title:'Oops!',
                        text: 'something went wrong, Response Status Code - '+jqXHR.status,
                        closeOnClickOutside:false
                    });
                    window.location.reload(true);
                },
            });
        });

        // To build invoice pdf
        $(document).on('click', '.buildinvoicepdfbtn', function() {
            let invoiceServiceDate = $(this).attr('data-date');
            let invoiceLocationId = $(this).attr('data-location');
            console.log(invoiceServiceDate);

            $('#invoiceServiceDate').val(invoiceServiceDate);
            $('#invoiceLocationId').val(invoiceLocationId);

            // $('#invoiceloader').css('display','block');
            // swal({
            //     icon: "{{ url('/assets/images/loader.gif') }}",
            //     text: 'Please Wait!',
            //     buttons: false,
            //     closeOnClickOutside:false
            
            // });

            $('#buildinvoicepdf').submit();
        });

        // To build cepacket pdf
        $(document).on('click', '.buildcepacketpdfbtn', function() {
            let cepacketServiceDate = $(this).attr('data-date');
            let cepacketLocationId = $(this).attr('data-location');
            console.log(cepacketServiceDate);

            $('#cepacketServiceDate').val(cepacketServiceDate);
            $('#cepacketLocationId').val(cepacketLocationId);

            // $('#invoiceloader').css('display','block');
            // swal({
            //     icon: "{{ url('/assets/images/loader.gif') }}",
            //     text: 'Please Wait!',
            //     buttons: false,
            //     closeOnClickOutside:false
            
            // });

            $('#buildcepacketpdf').submit();
        });

        // To add or update on call statement
        $(document).on('submit', '#updateOnCallStatement', function(e) {
            e.preventDefault();
            if (!$("#updateOnCallStatement").valid()) {
                alert('Something went wrong at the time of filling the form');
                return;
            }

            $.ajax({
                url: "{{ route('oncallstatement.add') }}",
                type:"post",
                data: $(this).serialize() +'&_token='+"{{ csrf_token() }}",
                beforeSend:function() {
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    });
                },
                success:function(data){
                    swal.close();
                    if (data.status == true) {
                        $('#on_call_statement').text(data.statement);
                        $('#onCallStatement').modal('hide');
                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success",
                        });
                    } else if (data.status == false) {
                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error",
                        });
                    } else {
                        location.reload();
                    }
                },
                error:function (jqXHR, textStatus, errorThrown) {
                    swal({
                        icon: "error",
                        title:'Oops!',
                        text: 'soemthing went wrong, Response StatusCode - '+jqXHR.status,
                        buttons: false,
                        closeOnClickOutside:false
                    });
                    window.location.reload(true);
                },
            });
        });

        $(document).on('click','.downloadinvoicefromS3', function() {
            
            let mergedInvoiceServiceDate = $(this).attr('data-date');
            let mergedInvoiceLocationId = $(this).attr('data-location');

            $('#mergedinvoiceServiceDate').val(mergedInvoiceServiceDate);
            $('#mergedinvoiceLocationId').val(mergedInvoiceLocationId);

            $('#downloadinvoicefromS3Form').submit();
            
        });

        $(document).on('click','.downloadrecordfromS3', function() {
            
            let mergedRecordServiceDate = $(this).attr('data-date');
            let mergedRecordLocationId = $(this).attr('data-location');

            $('#mergedRecordServiceDate').val(mergedRecordServiceDate);
            $('#mergedRecordLocationId').val(mergedRecordLocationId);

            $('#downloadrecordfromS3Form').submit();
            
        });

        // Service date
        $(document).ready(function(){
            $("#serviceDate").attr('readonly','readonly').datepicker({
                "dateFormat":'mm-dd-yy'
            });
        });

    });

    $(document).on('click','.download_clinic_documents', function() {

        let service_date = $(this).attr('data-service_date');
        let location = $(this).attr('data-location');
        $('#document_service_date').val(service_date);
        $('#document_location_id').val(location);

        $('#clinic_document_form').submit();
    });
      
    $(document).on('click', '.access_denied', function() {
        swal({
            icon: "error",
            title:'Oops!',
            text: 'You do not have permission to perform this action',
            closeOnClickOutside:false
        });
        return false;
    });

    $('.modal').on('hidden.bs.modal', function () {
       
       $('#clinicAddModal,#clinicUpdateModal').find('form')[0].reset();
       $('#addExaminerList').val('').trigger('change');
       $('#addAssistantList').val('').trigger('change');
       $('#clinicAddModal,#clinicUpdateModal').find('textarea').val('');
    });


    $(document).on('click', '.xray_status', function(e) {
        e.preventDefault();
        let service_date = $(this).data('service_date');
        let location_id = $(this).data('location_id');
        let xraysValue = Number($(this).prop('checked'));
        swal({
            title: "Are you sure?",
            text: "You want to change the status!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
            closeOnClickOutside:false
        }).then((willDelete) => {
            if (willDelete) {
                $.ajax({
                    url:"{{route('change-xrays-status')}}",
                    type: 'POST',
                    data: {
                        location_id:location_id,
                        service_date:service_date,
                        xraysValue:xraysValue,
                        _token:"{{ csrf_token()}}"
                    },
                    success:function(data){
                        swal.close();
                        if (data.status == true) {
                            window.location.reload(true);
                            swal({
                                title: "Great!",
                                text: data.msg,
                                icon: "success",
                            });
                        } else if (data.status == false) {
                            swal({
                                title: "Oops!",
                                text: data.msg,
                                icon: "error",
                            });
                        } else {
                            location.reload();
                        }
                    },
                    error:function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            console.log('500 status');
                        } else {
                            console.log('something went wrong!');
                        }
                        window.location.reload(true);
                    },
                });
            } else {}
        });

    });

       
</script>
@endsection