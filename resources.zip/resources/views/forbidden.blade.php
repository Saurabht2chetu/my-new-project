@extends('layouts.adminlayout')
@section('title','Dashboard - Moonlight Examinations')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="text-center py-5">
                    <i class="fas fa-low-vision" style="font-size: 80px;"></i>
                    
                </div>
                <p class="text-center">you are unauthorized user to access this page.</p>
                <!-- <div class="card-header"><p class="text-center">you are unauthorized user for access this page.</p></div> -->
            </div>
        </div>
    </div>
</div>
@endsection
