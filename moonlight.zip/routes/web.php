<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\ResetPasswordController;
use App\Http\Controllers\Auth\ResetUserIdController;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Auth\ForgotPasswordController;
use App\Http\Controllers\Auth\ForgotUserIdController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\HeadquarterController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\StateController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\LocationController;
use App\Http\Controllers\ClinicController;
use App\Http\Controllers\PatientController;
use App\Http\Controllers\NotificationController;


/* 
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return redirect('/login');
// });

Route::get('/home', [HomeController::class, 'index'])->name('home');

//auth routes 
Auth::routes();

Route::get('/', [LoginController::class, 'showLoginForm']);

//dashboard routes
Route::get('/no-access', [DashboardController::class, 'forbidden'])->middleware('auth');

//login to dashboard after selecting the role
Route::post('/login_to_dashboard',[LoginController::class, 'loginCheckRole'])->name('login_to_dashboard');

// Forgot Password
Route::get('/password/reset', [ResetPasswordController::class, 'showResetForm']);
Route::get('/auth/forgot-password', [ForgotPasswordController::class, 'showForgotPasswordForm'])->name('forgot.password.get');
Route::get('reset-password/{token}', [ForgotPasswordController::class, 'showResetPasswordForm'])->name('reset.password.get');


// Forgot User Id
Route::get('/uid/reset', [ResetUserIdController::class, 'showResetForm']);
Route::get('auth/forgot-userid', [ForgotUserIdController::class, 'showForgotUserIdForm'])->name('forgot.userid.get');

Route::middleware(['throttle:limiting'])->group(function () {
    Route::post('forgot-password', [ForgotPasswordController::class, 'submitForgotPasswordForm'])->name('forgot.password.post');   
    Route::post('reset-password', [ForgotPasswordController::class, 'submitResetPasswordForm'])->name('update.password.post');
    Route::post('forgot-userid', [ForgotUserIdController::class, 'submitForgotUserIdForm'])->name('forgot.userid.post');
});


// All Menus
Route::middleware(['auto_logout','auth'])->group(function () {
    
    //dashboard routes
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard')->middleware('roleauth');
    Route::get('/export-dashboard-report', [DashboardController::class, 'exportDashboardReport'])->name('exportDashboardReport');

    //headquarter routes
    Route::get('/headquarter-management', [HeadquarterController::class, 'index'])->name('headquarter-management')->middleware('roleauth');
    Route::post('add-headquarter',[HeadquarterController::class, 'addHeadquarter'])->name('add-headquarter.post');
    Route::get('/fetch-headquarter-details', [HeadquarterController::class, 'editHeadquarter'])->name('getheadquarteruser');
    Route::post('/fetch-headquarter-list', [HeadquarterController::class, 'fetchHeadquarterList'])->name('fetchheadquarterlist');
    Route::post('/update-headquarter', [HeadquarterController::class, 'updateHeadquarterUser'])->name('updateheadquarter');
    Route::post('/delete-headquarter', [HeadquarterController::class, 'deleteHeadquarterUser'])->name('deleteheadquarter');

    //Role and permission
    Route::get('/role-permissions', [RoleController::class, 'index'])->name('role-permissions')->middleware('roleauth');
    Route::post('/add-role', [RoleController::class, 'addRole'])->name('add-role');
    Route::get('/get-permission-list', [RoleController::class, 'getPermissionList'])->name('get.permissonlist');
    
    // change password menus routes after the login
    Route::get('change-password',[ProfileController::class, 'showChangePasswordForm'])->name('change.password.get');
    Route::post('change-password', [ProfileController::class, 'submitChangePasswordForm'])->name('change.password.post');

    // States
    Route::get('/state-ere-management',[StateController::class, 'index'])->name('state-ere-management');
    Route::post('add-state', [StateController::class, 'addState'])->name('add-state.post');
    Route::get('/fetch-state-details', [StateController::class, 'editState'])->name('fetchState');
    Route::post('/update-state', [StateController::class, 'updateState'])->name('updateState');
    Route::post('/update-status', [StateController::class, 'updateStatus'])->name('update.status');
    Route::post('/delete-status', [StateController::class, 'deleteState'])->name('delete.state');

    // Users
    // Route::get('users', [DashboardController::class, 'index'])->name('users');
    Route::get('/users', [UserController::class, 'index'])->name('users')->middleware('roleauth');
    Route::post('add-user',[UserController::class, 'addUser'])->name('users.add');
    Route::get('/fetch-user', [UserController::class, 'editUser'])->name('users.get');
    Route::post('/update-user', [UserController::class, 'updateUser'])->name('users.update');
    Route::post('/delete-user', [UserController::class, 'deleteUser'])->name('users.delete');
    Route::post('/update-user-password', [UserController::class, 'updateUserPassword'])->name('users.updatepassword');
    Route::post('/download-examiner-signature', [UserController::class, 'downloadExaminerSignature'])->name('post.downloadSignature');

    // Locations
    // Route::get('/locations', [DashboardController::class, 'index'])->name('locations');
    Route::get('/locations', [LocationController::class, 'index'])->name('locations')->middleware('roleauth');
    Route::post('/add-location',[LocationController::class, 'addLocation'])->name('location.add');
    Route::get('/fetch-location', [LocationController::class, 'editLocation'])->name('location.get');
    Route::post('/update-location', [LocationController::class, 'updateLocation'])->name('location.update');
    Route::post('/delete-location', [LocationController::class, 'deleteLocation'])->name('location.delete');
    Route::post('/fetch-city', [LocationController::class, 'fetchState'])->name('fetchCity');


    // Clinic List route
    // Route::get('/clinic-list', [DashboardController::class, 'index'])->name('clinic-list');
    Route::get('/clinic-list', [ClinicController::class, 'index'])->name('clinic-list');
    Route::get('/testing', [ClinicController::class, 'testing'])->name('testing');
    Route::get('/get-examiner', [ClinicController::class, 'getdataforEdit'])->name('get.examinerlist');
    Route::post('/update-assistant', [ClinicController::class, 'updateAssistant'])->name('update.assistant');
    Route::post('/update-clinic-service', [ClinicController::class, 'updateClinicService'])->name('update.clinicservice');
    Route::post('add-clinic-service',[ClinicController::class, 'addClinicService'])->name('clinicservice.add');
    Route::post('cancel-clinic-service',[ClinicController::class, 'cancelClinicService'])->name('clinicservice.cancel');
    Route::post('delete-clinic-service',[ClinicController::class, 'deleteClinicService'])->name('clinicservice.delete');
    Route::post('update-color-clinic-service',[ClinicController::class, 'updateClinicColor'])->name('cliniccolor.update');
    Route::post('/build-invoice-pdf', [ClinicController::class, 'createInvoicePDF'])->name('invoicepdf.build');
    Route::post('/build-cepacket-pdf', [ClinicController::class, 'createCEPacketPDF'])->name('cepacketpdf.build');
    Route::post('/download-clinic-documents', [ClinicController::class, 'MergeAndDownloadClinicDocument'])->name('post.downloadClinicDocuments');
    Route::post('add-on-call-statement',[ClinicController::class, 'addOnCallStatement'])->name('oncallstatement.add');
    Route::get('/get-on-call-statement', [ClinicController::class, 'getOnCallStatment'])->name('oncallstatement.get');
    Route::get('/search_examinee', [ClinicController::class, 'searchExaminee'])->name('search_examinee.get');
    Route::post('master-export/', [ClinicController::class, 'masterExport'])->name('masterExport');
    Route::post('/download-invoice-fromS3', [ClinicController::class, 'downloadMergedInvoice'])->name('post.downloadinvoicefromS3');
    Route::post('/download-record-fromS3', [ClinicController::class, 'downloadMergedRecord'])->name('post.downloadrecordfromS3');
    Route::post('/change-xrays-status', [ClinicController::class, 'changeXraysStatus'])->name('change-xrays-status');

    //Patient List route
    Route::get('/pdf-viewer', [PatientController::class, 'pdfviewer'])->name('pdfviewer');
    Route::get('/examinee-list/{date}/{location}', [PatientController::class, 'PatientList'])->name('patient.list')->middleware('examinee_auth');
    Route::get('/patient-list', [PatientController::class, 'getPatientList'])->name('getPatientList');
    Route::post('/update-caseId', [PatientController::class, 'updateCaseId'])->name('update.case_id');
    Route::post('/add-call-note', [PatientController::class, 'addCallNote'])->name('add.call_note');
    Route::post('/add-sticky-note', [PatientController::class, 'addStickyNote'])->name('add.sticky_note');
    Route::post('/get-sticky-note', [PatientController::class, 'getstickyNote'])->name('get.sticky_note');
    Route::post('/get-call-note', [PatientController::class, 'getcallNote'])->name('get.call_note');
    Route::post('/add-clinic-data', [PatientController::class, 'addClinicData'])->name('add.clinic_data');
    Route::post('/delete-sticky-note', [PatientController::class, 'RemoveStickyNote'])->name('delete.stickyNote');
    Route::post('/update-appointment-status', [PatientController::class, 'updateAppointmentStatus'])->name('update.appointmentStatus');
    Route::post('/add-patient', [PatientController::class, 'addPatient'])->name('add.patient');
    Route::post('/update-patient', [PatientController::class, 'updatePatient'])->name('update.patient');
    Route::get('/get-appointment-count', [PatientController::class, 'getSechduleCount'])->name('get.sechduelCount');
    Route::get('/get-patient-details', [PatientController::class, 'getPatientDetails'])->name('get.patientDetails');
    Route::get('/export-details', [PatientController::class, 'exportPatientDetails'])->name('post.exportDetails');
    Route::post('/upload-clinic-documents', [PatientController::class, 'uploadClinicDocuments'])->name('post.uploadDocument');
    Route::get('/build-pdf', [PatientController::class, 'buildInvoice']);
    Route::post('/save-clinic-calculations', [PatientController::class, 'saveClinicCalculations'])->name('post.saveClinicCalculations');
    Route::post('/update-specialRequest', [PatientController::class, 'updateSpecialRequest'])->name('update.special_request');
    Route::post('/update-phoneNumber', [PatientController::class, 'updatePhoneNumber'])->name('update.phone_number');
    Route::post('/delete-call-note', [PatientController::class, 'removeCallNote'])->name('delete.callNote');
    Route::post('/delete-appointment', [PatientController::class, 'deleteAppointment'])->name('delete.appointment');
    Route::get('/appointment-history/{id}', [PatientController::class, 'getAppointmentHistory'])->name('appointment-history')->middleware('roleauth');
    Route::get('/examinee-history/{id}', [PatientController::class, 'getExamineeHistory'])->name('examinee-history')->middleware('roleauth');
    
    //Notification route list
    Route::get('/notification-template', [NotificationController::class, 'index'])->name('notification-template')->middleware('roleauth');
    Route::post('/add-notification-template', [NotificationController::class, 'addNewTemplate'])->name('post.addNewTemplate');
    Route::post('/update-notification-template', [NotificationController::class, 'updateTemplate'])->name('post.updateTemplate');
    Route::get('/get-notification-template', [NotificationController::class, 'getTemplate'])->name('get.getTemplate');
    Route::post('/delete-notification-template', [NotificationController::class, 'deleteTemplate'])->name('post.deleteTemplate');
    Route::get('/appointment-reminder', [NotificationController::class, 'appointmentReminder'])->name('appointment-reminder')->middleware('roleauth');
    Route::get('/get-nofication-reminder', [NotificationController::class, 'getAllSentNotification'])->name('get.nofication.reminder');
    Route::post('/send-notification', [NotificationController::class, 'sendNotification'])->name('post.sendNotification');
    Route::get('/send-notification-testing', [NotificationController::class, 'sendMessageByTwilioTesting'])->name('send.notification.testing');
    Route::get('/notification-examinee-list/{notificationId}', [NotificationController::class, 'appointmentExamineeList'])->name('get.notification.examineeList');
    Route::get('get-examinee-list/', [NotificationController::class, 'getappointmentExamineeList'])->name('get.notification.examinee');
    Route::get('/get-clinics-by-service-date', [NotificationController::class, 'getClinicsByServiceDate'])->name('get.clinicsByServiceDate');
    Route::post('/get-notification_template', [NotificationController::class, 'getNotificationTemplate'])->name('get.notification_template');

    Route::get('examiner-signature/', [ProfileController::class, 'examinerSignature'])->name('view.examinerSignature');
    Route::get('test-download/', [ProfileController::class, 'downloadAsset']);
    Route::post('upload-signature/', [ProfileController::class, 'uploadSignature'])->name('post.uploadSignature');
    Route::get('/signature-viewer', [ProfileController::class, 'signatureViewer'])->name('signatureViewer');
    Route::get('testurl/', [UserController::class, 'testUrl']);
    

    
});
Route::get('testing/', [UserController::class, 'testing']);
