<?php

//  $fileName = "Examineedetails.xls"; 

//  print_r($appointmentData);
//  die;

//  Headers for download 
ob_end_clean();
header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
// header("Content-type: application/vnd.ms-excel; name='excel'");
// header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

header("Content-Disposition: attachment; filename=\"$fileName\""); 
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("Cache-Control: private",false);
header("Cache-Control: max-age=0");

?>

<html>
    <head>
    </head>
    <body style="border: 0.1pt solid #ccc">
        <?php
        if(isset($appointmentDataList)) {
            foreach ($appointmentDataList as $key => $apptList) { ?>
        
                <table cellpadding="15" width="100%" border="1" name="results" style="border-collapse: collapse;font-family:Arial;font-size:21px;">

                    <tr width="100%" style="background:#efe6cd;">
                        <th valign="top" style="font-weight:bold;text-align:center;">Schedule/Showed</th>
                        <th height="60" valign="top" style="font-weight:bold;text-align:center;">Chart Type</th>
                        <th height="60" valign="top" style="font-weight:bold;text-align:center;">Training</th>
                        <th height="60" valign="top" style="font-weight:bold;text-align:center;">Email</th>
                        <th height="60" valign="top" style="font-weight:bold;text-align:center;">Invite</th>
                        <th height="60" valign="top" style="font-weight:bold;text-align:center;">X-ray Vendor</th>
                        <th height="60" valign="top" style="font-weight:bold;text-align:center;">Team Member</th>
                        <th height="60" valign="top" style="font-weight:bold;text-align:center;">Contact Type</th>
                        <th height="60" valign="top" style="font-weight:bold;text-align:center;">Moonlight Headquarter Comment</th>
                        <th height="60" valign="top" style="font-weight:bold;text-align:center;">Clinic Staff Comment</th>
                        <th height="60" valign="top" style="font-weight:bold;text-align:center;">Submitted By</th>
                        <th height="60" valign="top" style="font-weight:bold;text-align:center;">Submitted Date</th>
                        <th height="60" valign="top" style="font-weight:bold;text-align:center;">Examiner Pay</th>
                        <th height="60" valign="top" style="font-weight:bold;text-align:center;">Revenue</th>
                    </tr>
                    <?php
                        $clinicDataList = getClinicDataByDateorLocation($apptList->service_date,$apptList->location_id);
                        $CalculationList = getClinicCalculation($apptList->service_date,$apptList->location_id);

                        $totalSechdule = getSechduleAppointmentCount($apptList->service_date,$apptList->location_id);

                        $totalShowed = getShowedAppointmentCount($apptList->service_date,$apptList->location_id);

                    ?>
                    <tr width="100%" style="background:#efe6cd;border:none;">
                        <th><?php $total = $totalSechdule."/".$totalShowed; echo "&nbsp;".$total."&nbsp;"; ?></th>
                        <td><?php echo isset($clinicDataList) && isset($clinicDataList->chart_type) ? $clinicDataList->chart_type : '';  ?></td>
                        <td><?php echo isset($clinicDataList) && isset($clinicDataList->training) ? $clinicDataList->training ? 'Yes' : 'no' : '';  ?></td>
                        <td><?php echo isset($clinicDataList) && isset($clinicDataList->email) ? $clinicDataList->email ? 'Yes' : 'no' : '';  ?></td>
                        <td><?php echo isset($clinicDataList) && isset($clinicDataList->invite) ? $clinicDataList->invite ? 'Yes' : 'no' : '';  ?></td>
                        <td>
                        <?php 
                            echo isset($clinicDataList) && isset($clinicDataList->x_ray_vendor) ? $clinicDataList->x_ray_vendor.' | ' : '';
                            echo isset($clinicDataList) && isset($clinicDataList->from_time) ? $clinicDataList->from_time.' - ' : '';
                            echo isset($clinicDataList) && isset($clinicDataList->to_time) ? $clinicDataList->to_time : '';
                        ?>
                        </td>
                        <td><?php echo isset($clinicDataList) && isset($clinicDataList->team_member) ? $clinicDataList->team_member : '';  ?></td>
                        <td><?php echo isset($clinicDataList) && isset($clinicDataList->contact_type) ? $clinicDataList->contact_type : '';  ?></td>
                        <td><?php echo isset($clinicDataList) && isset($clinicDataList->admin_write_in) ? $clinicDataList->admin_write_in : '';  ?></td>
                        <td><?php echo isset($clinicDataList) && isset($clinicDataList->assistant_write_in) ? $clinicDataList->assistant_write_in : '';  ?></td>
                        <td>
                            <?php 
                            if(isset($CalculationList) && isset($CalculationList[0]->submitted_by)) { 
                                echo $CalculationList[0]->submitted_by;
                            }  else { 
                                echo ""; 
                            } 
                            ?></td>
                        <td><?php echo isset($CalculationList) && isset($CalculationList[0]->submitted_date) ? convertDate($CalculationList[0]->submitted_date) : "";?></td>
                        <td><?php echo isset($CalculationList) && isset($CalculationList[0]->examiner_pay) ? "$".$CalculationList[0]->examiner_pay : "";?></td>
                        <td><?php echo isset($CalculationList) && isset($CalculationList[0]->revenue) ? "$".$CalculationList[0]->revenue : "";?></td>
                    </tr>
                </table>
                <table cellpadding="15" width="100%" border="1" name="results" style="border-collapse: collapse;font-family:Arial;font-size:32px;">
                    <tr class="heading_section" width="100%" style="background:#ddd;">
                        <th></th>
                        <th height="50" colspan="8" style="font-weight:bold;text-align:left;">Clinic Name: {{ $apptList->location_name }} </th>
                    </tr>
                </table>
                <table cellpadding="15" width="100%" border="1" name="results" style="border-collapse: collapse;font-family:Arial;font-size:21px;">
                    <tr>
                        <th></th>
                        <th colspan="2" style="text-align:left;white-space: nowrap;"><?php echo 'Service Date : '.convertDate($apptList->service_date); ?></th>
                        <th colspan="3" style="text-align:left;white-space: nowrap;">
                            <?php
                                $examinerList = getExaminersByDateAndLocation($apptList->service_date,$apptList->location_id); 

                                //get Examiner List
                                $examiners = count($examinerList) > 0 ? $examinerList['examiner_list']['user_name'] : getAllexaminerByDateOrLocation($apptList->service_date,$apptList->location_id)['user_name']; 
                                echo 'Examiner: '.$examiners; 
                            ?>
                        </th>
                        <th colspan="3" style="text-align:left;white-space: nowrap;">
                            <?php 
                                //get Assistant List
                                $assistnlist = getAssistantsByDateAndLocation($apptList->service_date,$apptList->location_id); 
                                $assitants = count($assistnlist) > 0 ? $assistnlist['assistant_list']['user_name'] : "";
                                echo 'Assistant : '.$assitants; 
                            ?>
                        </th>
                    
                    </tr>
                </table>
                <table cellpadding="15" width="100%" border="1" name="results" style="border-collapse: collapse;font-family:Arial;font-size:16px;">
                    <thead>
                        <tr width="100%">
                            <th width="50">Status</th>
                            <th width="150">Service Time</th>
                            <th width="200">Examinee Name</th>
                            <th width="200">Special Request</th>
                            <th width="100">Case ID</th>
                            <th width="200">DOB</th>
                            <th width="150">Phone</th>
                            <th width="300">Call Notes</th>
                            <th width="300" style="background:yellow;">Sticky Notes</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $appointmentData = getAppointmentListByDateOrLocation($apptList->service_date,$apptList->location_id);
                            
                        ?>
                    @if (isset($appointmentData) && count($appointmentData) > 0)
                        @foreach ($appointmentData as $appointmentList)
                        <tr>
                            <td width="50" style="text-align:center;">
                                @if ($appointmentList->status == '0') 
                                
                                @elseif($appointmentList->status == '1') 
                                    {{ ('Broken - '.$appointmentList->status_text) }}
                                    
                                @elseif($appointmentList->status == '2')
                                        
                                {{ ('Cancelled - '.$appointmentList->status_text) }}
                                @endif

                            </td>
                            <td width="150" style="text-align:center;">{{ convertTime($appointmentList->service_time) }}</td>
                            <td width="200" style="text-align:left;">{{ $appointmentList->first_name }}</td>
                            <td width="200" style="text-align:center;">{!! $appointmentList->special_instruction !!}</td>
                            <td width="100" style="text-align:center;">{{ $appointmentList->case_id }}</td>
                            <td width="200" style="text-align:right;">{{ date("m-d-Y",strtotime($appointmentList->dob)) }}</td>
                            <td width="150" style="text-align:center;">{{ formatPhoneNumber($appointmentList->phone) }}</td>
                            <td style="text-align:center;">
                                <?php
                                    $callnotes = getLastCallNotes($appointmentList->appointment_id);
                                    echo $callnotes ? $callnotes->call_note : '';
                                ?>
                            </td>
                            <td style="text-align:center;background:yellow;">
                                <?php
                                    $stickynotes = getLastStickyNotes($appointmentList->appointment_id);
                                    echo $stickynotes ? $stickynotes->sticky_note : '';
                                ?>
                            </td>
                        </tr>
                        @endforeach
                    @endif
                    </tbody>
                </table>

                <table>
                    <tr>
                        <td></td>
                        <td></td>
                        
                    <tr>
                        <td></td>
                        
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                    </tr>
                </table>
            <?php 
            } 
        } ?>
    </body>
</html>

<?php

header("location : index.php"); exit;

?>