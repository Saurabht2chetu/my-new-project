@extends('layouts.adminlayout')
@section('title','Appointment History - Moonlight Examinations')

@section('content')
<style>

    table.dataTable tbody th, table.dataTable tbody td {
        white-space: nowrap;
    }
    #stickycontent .table td, .table th,#callcontent .table td, .table th {
        padding: 0.75rem;
        vertical-align: middle!important;
        text-align: left !important;
    }

    .swal-icon--custom img {
        width:50px!important;
        height:50px!important;
    }
  
    table.stripe tr td:nth-child(4) span{
        display: block;
        width:200px;
        word-wrap: break-word;
        white-space: normal;
    }
    table.stripe tr td:nth-child(4) {
        word-wrap: break-word;
        white-space: normal;
        width:200px;
        min-width: 200px;
    }

/*22/8/2022 css start here */
.current-tabs table thead tr th {
    white-space: nowrap;
}
.current-tabs table tbody tr td {
    white-space: nowrap;
}

.dashboard-table1.current-tabs .table-responsive.current_section {
    margin-bottom: 40px;
}
/*22/8/2022 css end here */
</style>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />

<div class="container-fluid">

    <div class="db-top4-box-wrapper">
        <div class="my-3 hm-dis">

        <div class="col-md-6">
            <p class="db-heading m-0">@if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID'])
                <a href="{{ route('dashboard') }}">Dashboard / </a> @endif
                <a class="db-heading" href="{{ route('clinic-list'); }}">Appointmet History</a>
            </p>
            </div>
            <div class="col-md-6">
            <div class="float-right">
          
        <a href="{{ url('examinee-history', $currentRecord->patient_id) }}" target="_blank"><button class="btn-main historydata">Examinee History</button></a>
      
        <!-- <a href="{{ url('clinic-data-list/'.$currentRecord->service_date.'/'.$currentRecord->location_id.'/') }}" target="_blank">
       <button class="btn-main historydata">Clinic Data History</button></a> -->
     
        </div>
            </div>


        </div>
  
        <div class="dashboard-table1 current-tabs">
            <div class="p-form">
            <h4> Current Record</h4>
            <div class="table-responsive current_section">
            <table id="" class="table table-bordered" style="width:100%">
              <thead>
                        <tr>
                        <th>Broken kept</th>
                        <th>Location </th>
                        <th>Examinee</th>
                        <th>Appt. Time</th>
                        <th>Case Id </th>
                        <th>Exam Type </th>
                        <th>Service Date </th>
                        <th>Examinee Name</th>
                        <th>Invoice</th>
                        <th>Record</th>
                        <th>Special Instructions</th>
                        <th>Updated At</th>
                        <th>Updated By</th>
                        </tr>
                    </thead>
                    <tbody>
                   <tr>
                        <td>
                      @if($currentRecord->status == env('APPT_STATUS_BROKEN'))
                                    {{ __('Broken') }}
                                @elseif($currentRecord->status == env('APPT_STATUS_CANCEL'))
                                    {{ __('Cancelled') }}
                                @else
                                    {{ __('') }}
                                @endif
                        </td>
                      <td>{{$currentRecord->location_name}}</td>
                      <td>{{$currentRecord->patient_name}}</td>
                      <td>{{$currentRecord->service_time}}</td>
                      <td>{{ $currentRecord->case_id }}</td>
                      <td>{{ $currentRecord->type_of_exam}}</td> 
                      <td>{{ convertDate($currentRecord->service_date) }}</td>
                      <td>
                        <?php 
                            // $list = getuserListByid($currentRecord->);
                        ?>
                      </td>
                     
                      <td>
                      
                        @if($currentRecord->invoice_update != 0) 
                        {{ __('Invoice updated') }}
                          @endif
                      </td>
                      <td>
                        @if($currentRecord->record_update != '0')  
                            {{ __('Record updated') }}
                        @endif
                      </td>
                      <td> {!! $currentRecord->special_instruction !!} </td>
                      <td> {{$updatedAtApptHistoryLatest}} </td>
                      <td> {{$firstName}} </td>
                      </tr>
                    </tbody>
                </table>
                </div>

                <h4> History Records</h4>

                <div class="table-responsive">
                <table id="" class="table table-bordered" style="width:100%">
                <thead>
                    <tr>
                    <th>Broken kept</th>
                    <th>Location</th>
                    <th>Examinee</th>
                    <th>Appt. Time</th>
                    <th>Case Id </th>
                    <th>Exam Type </th>
                    <th>Service Date</th>
                    <th>Invoice</th>
                    <th>Record</th>
                    <th>Special Instructions</th>
                    <th>Updated At</th>
                    <th>Updated By</th>
                    </tr>
                </thead>
                <tbody>
                @php $i=0; @endphp
                    @foreach($historyRecord as $list)
                        <tr>
                            <td>
                                @if($list->status == env('APPT_STATUS_BROKEN'))
                                    {{ __('Broken') }}
                                @elseif($list->status == env('APPT_STATUS_CANCEL'))
                                    {{ __('Cancelled') }}
                                @else
                                    {{ __('') }}
                                @endif
                            </td>
                            <td>{{$list->location_name}}</td>
                            <td>{{$list->patient_name}}</td> 
                            <td>{{$list->service_time}}</td>
                            <td>{{ $list->case_id }}</td>
                            <td>{{ $list->type_of_exam }}</td>
                            <td>{{ convertDate($list->service_date) }}</td>
                           
                            <td>
                                @if($list->invoice_update != 0)
                                    {{ __('Invoice updated') }}
                                @endif
                            </td>
                            <td>
                                @if($list->record_update != 0)  
                                    {{ __('Record updated') }}
                                @endif
                            </td>
                            <td> {!! $list->special_instruction !!}</td>
                            <td> {{isset( $updatedAtApptHistory[$i])? $updatedAtApptHistory[$i]:""}} </td>
                            <td> {{isset( $updatedByUser[$i])? $updatedByUser[$i]:""}}</td>
                        </tr>
                        @php $i++; @endphp
                    @endforeach 
                </tbody>
            </table>.
            </div>
            </div>
        </div>  
    </div>  
</div>

@endsection