@extends('layouts.adminlayout')
@section('title','Examinee History - Moonlight Examinations')

@section('content')
<style>

    table.dataTable tbody th, table.dataTable tbody td {
        white-space: nowrap;
    }
    #stickycontent .table td, .table th,#callcontent .table td, .table th {
        padding: 0.75rem;
        vertical-align: middle!important;
        text-align: left !important;
    }

    .swal-icon--custom img {
        width:50px!important;
        height:50px!important;
    }
  
    table.stripe tr td:nth-child(4) span{
        display: block;
        width:200px;
        word-wrap: break-word;
        white-space: normal;
    }
    table.stripe tr td:nth-child(4) {
        word-wrap: break-word;
        white-space: normal;
        width:200px;
        min-width: 200px;
    }

</style>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css" />

<div class="container-fluid">
    
    <div class="db-top4-box-wrapper">
        <div class="my-3 hm-dis">
            <p class="db-heading m-0">@if (Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID'])
                <a href="{{ route('dashboard') }}">Dashboard / </a> @endif
                <a class="db-heading" href="{{ route('clinic-list'); }}">Examinee History</a>
            </p>

           
            
         
        </div>
        <div class="dashboard-table1">
            <div class="p-form">
            <h4> Current Record</h4>
            <div class="table-responsive current_section">
                <table id="" class="table table-bordered" style="width:100%">
            
                    <thead>
                        <tr>
                            <th>Examinee Name</th>
                            <th>DOB</th>
                            <th>Phone</th>
                            <th>Updated At</th>
                            <th>Updated By</th>
                        </tr>
                    </thead>
                    <tbody>
                  
                      <tr>
                      <td> {{$currentPatientRecord->first_name}} </td>
                      <td>
                        @if($currentPatientRecord->dob) 
                            {{ date("m-d-Y",strtotime($currentPatientRecord->dob))}}
                        @endif
                      </td>
                      <td>  {{ formatPhoneNumber($currentPatientRecord->phone) }} </td>
                      <td> {{$updatedAtLatest}} </td>
                      <td> {{$firstNamePatient}} </td>
                      </tr>
                   
                    </tbody>
                  
                </table>
            </div>
            <h4> History Records</h4>
             <div class="table-responsive">
            <table id="" class="table table-bordered" style="width:100%">
            
                    <thead>
                        <tr>
                       
                       
                        <th>Examinee Name</th>
                            
                            <th>DOB</th>
                            <th>Phone</th>
                            <th>Updated At</th>
                            <th>Updated By</th>
                         
                        </tr>
                    </thead>
                    <tbody>
                    @php $i=0; @endphp
                    @foreach($patientRecord as $list)
                   
                      <tr>
                      <td>{{$list->first_name}}</td>
                      <td>
                        @if($list->dob) 
                            {{ date("m-d-Y",strtotime($list->dob))}}
                        @endif
                      </td>
                      <td> {{ formatPhoneNumber($list->phone) }} </td>
                      <td> {{isset( $updatedAtPatient[$i])? $updatedAtPatient[$i]:""}} </td>
                      <td> {{isset( $updatedByUserPatient[$i])? $updatedByUserPatient[$i]:""}} </td>
                    </tr>
                    @php $i++; @endphp
                    @endforeach 
                    
                  
                    </tbody>
                  
                </table>
                </div>

            </div>
        </div>

      

    
    </div>
   
    
</div>

@endsection