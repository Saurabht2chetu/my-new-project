
<div class="container-fluid">
    <embed src="{{$file}}" width="100%" height='856' type="application/pdf">
</div>
