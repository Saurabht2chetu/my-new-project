
@extends('layouts.loginlayout')
@section('title','Moonlight login')

@section('content')
<div style="padding: 0px 80px;">
    <p class="text-left font-14" style="font-weight:bold;" >Please select your user role</p>
</div>
<div class="login-form">
   <form action="{{ route('login_to_dashboard') }}" class="confirm-form my-4" method="POST">
       @csrf
        <input type="text" name="email" id="email" value="{{$email}}" hidden>
        <input type="text" name="password" id="password" value="{{$password}}" hidden>

        @foreach($role_arr as $key => $list)
        <div class="form-check">
            <input class="form-check-input" type="radio" name="user_role" id="exampleRadios_{{$key}}" value="{{$list->id}}" required >
            <label class="form-check-label" for="exampleRadios_{{$key}}">
            {{$list->name}}
            </label>
        </div>
        @endforeach
        <div class="form-group mt-4">
			<div class="formicon-parent text-center">
				<button type="button" onclick="window.history.back();" class="lft-arrow login-btn-01">Back</button>
				<button type="submit" class="rgt-arrow login-btn-01">Submit</button><span><i class="fas fa-arrow-right login-icon-right arr"></i></span>
			</div>
		</div>
        
    </form>
</div>
@endsection
