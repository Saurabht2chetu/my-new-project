@extends('layouts.loginlayout')
@section('title','Reset Password - Moonlight Examinations')

@if ($email != '')
@section('content')

<style>
    .invalid-feedback{
        display:block!important;
    }
</style>

<div class="">
    <p class="text-center font-14" style="font-weight: 500;">Please enter new password and confirm new password</p>
</div>

<div class="login-form">

    @if (session('error'))
        <div class="alert alert-danger" role="alert">
            {{ session('error') }}
        </div>
    @endif

    <form action="{{ route('update.password.post') }}" method="POST" id="resetpasswordForm" onsubmit="return submitform()" >
		@csrf
        <input type="hidden" name="token" value="{{ $token }}">
		<input type="hidden" class="form-control frm-input-1" name="email" value="{{ $email ?? old('email') }}" required autocomplete="email" autofocus>

        <div class="form-group">

			<label for="resetpass">{{ __('New Password ') }}<span class="star">*</span></label>
			<div class="formicon-parent">
				<span><i class="fas fa-user input-icon-left"></i></span>
				<input type="password" maxlength="15" class="form-control frm-input-1 @error('password') is-invalid @enderror" name="password" placeholder="Enter New Password" required autocomplete="new-password" id="resetpass"  data-toggle="popover" data-trigger="focus" title="Password Hint" data-content="At least one capital letter, <br>At least one number, <br> At least one special character from<br>(@, #, $, %, &)" >
                <span>
                    <i class="far fa-eye-slash input-icon-right aw" onclick="return visibility('resetpass',this);"></i>
                </span>
			</div>

            <script>

                function visibility(id,event) {
      
                    var x = document.getElementById(id);
                    if (x.type === 'password') {
                            x.type = "text";
                            $(event).removeClass('fa-eye-slash');
                            $(event).addClass('fa-eye');
                    } else {
                            x.type = "password";
                            $(event).removeClass('fa-eye');
                            $(event).addClass('fa-eye-slash');
                    }
                }

            </script>
          
            @error('password')
                <span class="invalid-feedback" role="alert">
                    <strong>{{ $message }}</strong>
                </span>
            @enderror
           

		</div>

        <div class="form-group">
			<label for="confirm_resetpass">{{ __('Confirm New Password ') }}<span class="star">*</span></label>

			<div class="formicon-parent">
				<span><i class="fas fa-user input-icon-left"></i></span>
				<input type="password" maxlength="15" class="form-control frm-input-1" name="password_confirmation" placeholder="Enter Confirm Password" required autocomplete="new-password" id="confirm_resetpass" onkeyup="removeerror()">
                <span>
                    <i class="far fa-eye-slash input-icon-right aw" onclick="return visibility('confirm_resetpass',this);"></i>
                </span>
			</div>
            @error('password_confirmation')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
            @enderror
		</div>

		<div class="form-group mt-4">
			<div class="formicon-parent">
                <button type="submit" class="btn btn-block login-btn-01">{{ __('Reset Password') }}</button>
                <span>
                    <i class="fas fa-arrow-right login-icon-right arr"></i>
                </span>
			</div>
		</div>
	</form>
</div>
        

<script>

    function removeerror() {
        
        let resetpass = $('#resetpass').val();
        let confirm_resetpass = $('#confirm_resetpass').val();
        if(resetpass == '') {
            return;
        }
        console.log({resetpass,confirm_resetpass})
        if(resetpass == confirm_resetpass) {
            $('.invalid-feedback').remove();
        }
        
    }

    function submitform() {

        if(!$("#resetpasswordForm").valid()) {
            return false;
        }
        return true;
    }
    
    $(function() {

        $('#resetpass').popover({
            container: 'body',
            html:true,
            placement:'right'
        });

    
        $("#resetpasswordForm").validate({

            rules: {
                password: {
                    required:true,
                    strong_password:true
                },
                password_confirmation:{
                    required:true,
                    matchedpass:true
                    // equalTo:'#confirm_resetpass'
                }

            },
            messages: {
                password: {
                    required:"Password is required",
                },
                password_confirmation:{
                    required:"Confirm Password is required",
                    equalTo:'Confirm Password does not match'
                }

            },

            errorPlacement: function(label, element) {

                label.addClass('mt-2 text-danger');

                label.insertAfter(element);

            },

            highlight: function(element, errorClass) {

                $(element).parent().addClass('has-danger');

                $(element).addClass('form-control-danger');

            },

            unhighlight: function(element, errorClass, validClass) {

                $(element).parents().removeClass('has-danger');

                    $(element).removeClass('form-control-danger');

                $(element).parents('.form-group').addClass('has-success');

            }

        });

        jQuery.validator.addMethod("strong_password", function (value, element) {
            let password = value;
            if (!(/^(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%&])(.{8,15}$)/.test(password))) {
                return false;
            }
            return true;
        }, function (value, element) {

            let password = $(element).val();

            if (!(/^(.{8,15}$)/.test(password))) {
                return 'Password must be between 8 to 15 characters.';
            }
            else if (!(/^(?=.*[A-Z])/.test(password))) {
                return 'Password must contain at least one Capital Letter.';
            }
            else if (!(/^(?=.*[0-9])/.test(password))) {
                return 'Password must contain at least one number.';
            }
            else if (!(/^(?=.*[@#$%&])/.test(password))) {
                return "Password must contain at least one special character from @#$%&.";
            }
            return false;
        });

        jQuery.validator.addMethod("matchedpass", function (value, element) {

            let password = $('#resetpass').val();
            let confirm_resetpass = $('#confirm_resetpass').val();

            if (password == confirm_resetpass) {
                return true;
            }
            return false;
        }, 'Confirm Password does not match');

        
        // $('#resetpasswordForm').on('submit',function(e) {

        //     e.preventDefault();
          
        //     if(!$("#resetpasswordForm").valid()) {
        //         return false;
        //     }
       
        // });

    });



</script>
@endsection
@else
@section('content')
<div class="text-center">
    <p>This link is expired</p>
</div>
@endsection
@endif




