
@extends('layouts.loginlayout')
@section('title','Forgot User Id - Moonlight Examinations')

@section('content')

<div class="p-pad">
    <p class="text-center font-14">Enter your registered email below to receive User Id</p>
</div>
<div class="login-form">

@if (session('status'))
	<div class="alert alert-success" role="alert">
		{{ session('status') }}
	</div>
	<div class="form-group mt-4">
		<div class="formicon-parent text-center">
			<button type="button" onclick="return window.location.href='{{ route("login") }}'" class="lft-arrow login-btn-01">Login</button>
		</div>
	</div>
@else
@if (session('error'))
	<div class="alert alert-danger" role="alert">
		{{ session('error') }}
	</div>
@endif
	<form action="{{ route('forgot.userid.post') }}" method="POST">
		@csrf
		<div class="form-group">
			<label for="email">Email <span class="star">*</span></label>

			<div class="formicon-parent">
				<span><i class="fas fa-user input-icon-left"></i></span>
				<input type="email" class="form-control frm-input-1" value="{{ old('email') }}" maxlength="40" name="email" placeholder="Enter Your Email" required="">
			</div>
			@error('email')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
            @enderror
		</div>
		<div class="form-group mt-4">
			<div class="formicon-parent text-center">
				<button type="button" onclick="return window.location.href='{{ route("login") }}'" class="lft-arrow login-btn-01">Back</button>
				<button type="submit" class="rgt-arrow login-btn-01">Submit</button>
			</div>
		</div>
	</form>
	@endif
	
</div>
@endsection
