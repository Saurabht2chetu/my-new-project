<!DOCTYPE html>
<html lang="en">
<head>
	<title>@yield('title')</title>
   	@include('layouts.login.header')
</head>
<style>
    .invalid-feedback{
        display:block!important;
    }
</style>
<body>
    <div class="container-fluid login-wrapper">
        <div class="container">
            <div class="row justify-content-center align-items-center">
                <div class="col-lg-6 col-md-8 col-sm-10 col-12" >
                    <!-- <div class="col-lg-4 col-md-3"></div> -->
                    <!-- <div class="col-lg-6 col-md-6"> -->
                    <!-- Login Section Starts -->
                    <div class="login-box ">
                        <div class="logo text-center">
                            <img src="{{ asset('assets/images/logo.png') }}" alt="" class="img-fluid">
                        </div>

                        @yield('content')

                    </div>
                    <!-- Login Section Ends -->
                </div>
                <!-- <div class="col-lg-4 col-md-3"></div> -->
            </div>
        </div>
    </div>




@include('layouts.login.footer')

</body>
</html>