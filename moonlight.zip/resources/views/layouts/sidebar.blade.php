<?php
// To Retrieve The Request URI
$uriPath = \Request::segment(1);

$menus = getSideMenus();

?>
<div class="sidenav" id="dbSidenav">
	<div class="db-menu">
		<ul>
            @if(Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID'])
                <li class="<?php if($uriPath == 'dashboard') { echo 'active-db-menu'; } ?>"><a href="{{ route('dashboard') }}"><span><i class="fas fa-home"></i></span><span>Dashboard</span></a></li>
            @endif
            @foreach($menus as $counter => $menu)
                <li class="<?php if($uriPath == $menu->slug) { echo 'active-db-menu'; } ?>"><a href="{{ route($menu->slug) }}"><span><i class="fas fa-{{$menu->icon}}"></i></span><span>{{$menu->name}}</span></a></li>
            @endforeach
            <li class="<?php if($uriPath == 'clinic-list' || $uriPath == 'examinee-list' || $uriPath == 'appointment-history' || $uriPath == 'examinee-history') { echo 'active-db-menu'; } ?>"><a href="{{ route('clinic-list') }}"><span><i class="fas fa-clinic-medical"></i></span><span>Clinic List</span></a></li>
            @if(Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'])
                <li class="<?php if($uriPath == 'role-permissions') { echo 'active-db-menu'; } ?>"><a href="{{ route('role-permissions') }}"><span><i class="fas fa-map-marked-alt"></i></span><span>Role & Permissions</span></a></li>
                <li class="<?php if($uriPath == 'state-ere-management') { echo 'active-db-menu'; } ?>"><a href="{{ route('state-ere-management') }}"><span><i class="fas fa-flag"></i></span><span>State ERE Management</span></a></li>
            @endif
            @if(Auth::user()->role_id == $_ENV['SUPERADMIN_ROLE_ID'] || Auth::user()->role_id == $_ENV['HEADQUARTER_ROLE_ID'])
                <li class="<?php if($uriPath == 'notification-template') { echo 'active-db-menu'; } ?>"><a href="{{ route('notification-template') }}"><span><i class="fa fa-comments"></i></span><span>Notification Template</span></a></li>
                <li class="<?php if($uriPath == 'appointment-reminder' || $uriPath == 'notification-examinee-list')  { echo 'active-db-menu'; } ?>"><a href="{{ route('appointment-reminder') }}"><span><i class="fa fa-calendar"></i></span><span>Appointment Reminder</span></a></li>
            @endif
			<li><a href="{{ route('logout') }}" onclick="event.preventDefault();
 			document.getElementById('logout-form').submit();"><span><i class="fas fa-sign-in-alt"></i></span><span>Log Out</span></a>
			</li> 
			<form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
 				@csrf
 			</form>
		</ul>
	</div>
</div>