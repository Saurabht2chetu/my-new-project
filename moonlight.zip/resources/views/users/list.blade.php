@extends('layouts.adminlayout')
@section('title','User Management - Moonlight Examinations')

@section('content')
 
<div class="container-fluid">
    <div class="db-top4-box-wrapper">
        <div class="mt-3 hm-dis">
            <p class="db-heading"><a href="{{ route('dashboard') }}">Dashboard</a> / User Management</p>
            @if($action == 1)
            <button class="btn-main" data-toggle="modal" data-target="#userAddModal"><i
                    class="fas fa-plus"></i> Add</button>
                    @endif
        </div>
        @if (session('status'))
            <div class="alert alert-success" role="alert">
                {{ session('status') }}
            </div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger" role="alert">
                {{ session('error') }}
            </div>
        @endif

        <!-- Add Modal Form starts -->
        <div class="modal fade md-round" id="userAddModal" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">

                    <div class="p-3">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="login-form">
                            <div class="text-center mb-4">
                                <h4>Add User </h4>
                            </div>
                            <form action="" method="POST" id="addUserForm">
                                
                                <div class="form-group">
                                <label for="add_firstName">First Name <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <span><i class="fas fa-user input-icon-left"></i></span>
                                        <input type="text" name="firstName" class="form-control frm-input-1" placeholder="First Name" maxlength="30" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                <label for="add_firstName">Last Name <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <span><i class="fas fa-user input-icon-left"></i></span>
                                        <input type="text" name="lastName" class="form-control frm-input-1" placeholder="Last Name" maxlength="30" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="add_user_role">Role <span class="text-danger">*</span></label>
                                    <select class="form-control" id="user_role" name="user_role" required>
                                        <option value="">-- Select --</option>
                                        @foreach($RoleList as $list)
                                            <option value="{{$list->id}}">{{$list->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email Id <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <span><i class="fas fa-envelope input-icon-left"></i></span>
                                        <input type="text" name="email" value="" id="email" class="form-control frm-input-1" maxlength="40" placeholder="Email Id" autocomplete="off" required>
                                    </div>
                                </div>
                                <!-- <div class="form-group">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="checkUserId" name="checkStatus" checked >
                                        <label class="form-check-label font-14" style="color:#767575!important;" for="gridCheck">
                                        UserId same as Email
                                        </label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="formicon-parent">
                                        <span><i class="fas fa-id-card input-icon-left"></i></span>
                                        <input type="text" class="form-control frm-input-1"
                                            placeholder="User Id" name="userId" id="userId" value="" readonly="readonly" required autocomplete="off" >
                                    </div>
                                </div> -->
                                <div class="form-group">
                                    <label for="passwordField">Password <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <span><i class="fas fa-key input-icon-left"></i></span>
                                        <input type="password" name="password" class="form-control frm-input-1" placeholder="Password" id="passwordField" data-toggle="popover" data-trigger="focus" title="Password Hint" data-content="At least one capital letter, <br>At least one number, <br> At least one special character from<br>(@, #, $, %, &)" required>
                                        <span><i class="far fa-eye-slash input-icon-right aw" onclick="return visibility('passwordField',this);"></i></span>
                                    </div>
                                    @error('password')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                                <div class="form-group">
                                    <label for="passwordConfirmField"> Confirm Password <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <span><i class="fas fa-key input-icon-left"></i></span>
                                        <input type="password" name="password_confirmation" class="form-control frm-input-1" placeholder="Confirm Password" id="passwordConfirmField" required>
                                        <span><i class="far fa-eye-slash input-icon-right aw" onclick="return visibility('passwordConfirmField',this);"></i></span>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="formicon-parent">
                                        <button type="submit"
                                            class="btn btn-block login-btn-01">SUBMIT</button><span><i
                                                class="fas fa-arrow-right login-icon-right arr"></i></span>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Add Modal Form End -->

        <!-- Change Password Modal Form starts -->
        <div class="modal fade md-round" id="changepasswordModal" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">

                    <div class="p-3">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="login-form">
                            <div class="text-center mb-4">
                                <h4>Change Password</h4>
                            </div>
                            <form action="" method="POST" id="changepasswordForm">
                                <div class="form-group">
                                    <label for="passwordConfirmField">New Password <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <span><i class="fas fa-user input-icon-left"></i></span>
                                        <input type="hidden" name="idval" id="changepassId" value="">
                                        <input type="password" name="password" id="userpass" class="form-control frm-input-1" placeholder="New Password" data-toggle="popover" data-trigger="focus" title="Password Hint" data-content="At least one capital letter, <br>At least one number, <br> At least one special character from<br>(@, #, $, %, &)" required>
                                        <span><i class="far fa-eye-slash input-icon-right aw" onclick="return visibility('userpass',this);"></i></span>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="passwordConfirmField">Confirm New Password <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <span><i class="fas fa-user input-icon-left"></i></span>
                                        <input type="password" name="password_confirmation" class="form-control frm-input-1" id="userpass_confirmation" placeholder="Confirm New Password" required>
                                        <span><i class="far fa-eye-slash input-icon-right aw" onclick="return visibility('userpass_confirmation',this);"></i></span>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <div class="formicon-parent">
                                        <button type="submit"
                                            class="btn btn-block login-btn-01">SUBMIT</button><span><i
                                                class="fas fa-arrow-right login-icon-right arr"></i></span>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Add Modal Form End -->

        <!-- change Modal Form Starts -->
        <div class="modal fade md-round" id="editModal" tabindex="-1" role="dialog"
            aria-labelledby="editModalTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">

                    <div class="p-3">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="login-form">
                            <div class="text-center mb-4">
                                <h4>Edit User</h4>
                            </div>
                            <form id="editForm" method="post">
                                @csrf
                                <input type="hidden" name="idval" id="idval" value="">
                                <div class="form-group">
                                <label for="exampleInputEmail1">First Name <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                    
                                        <span><i class="fas fa-user input-icon-left"></i></span>
                                        <input type="text" name="firstName" id="firstName" class="form-control frm-input-1" placeholder="First Name" maxlength="30" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                <label for="exampleInputEmail1">Last Name <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <span><i class="fas fa-user input-icon-left"></i></span>
                                        <input type="text" name="lastName" id="lastName" class="form-control frm-input-1" placeholder="Last Name" maxlength="30" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="edit_user_role">Role <span class="text-danger">*</span></label>
                                    <select class="form-control" id="edit_user_role" name="user_role" required>
                                        @foreach($RoleList as $list)
                                            <option value="{{$list->id}}">{{$list->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div id="emailId" class="form-group">
                                    <label for="exampleInputEmail1">Email Id</label>
                                    <div class="formicon-parent">
                                        <span><i class="fas fa-envelope input-icon-left"></i></span>
                                        <input type="text" name="email" id="editemail" class="form-control frm-input-1" maxlength="40" placeholder="Email Id">
                                    </div>
                                </div>
                                <!-- 
                                <div class="form-group">
                                <label for="exampleInputEmail1">User Id</label>
                                    <div class="formicon-parent">
                                        <span><i class="fas fa-id-card input-icon-left"></i></span>
                                        <input type="text" class="form-control frm-input-1"
                                            placeholder="User Id" name="userId" id="edituserId" value=""  required>
                                    </div>
                                </div> -->
                                <div class="form-group">
                                    <div class="formicon-parent">
                                        <button type="submit"
                                            class="btn btn-block login-btn-01">SUBMIT</button><span><i
                                                class="fas fa-arrow-right login-icon-right arr"></i></span>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Edit Modal Form End -->
        
        
    </div>
    <div class="dashboard-table1">

        <div class="row">
            <div class="col-md-12">
                <form id="downloadSignatureForm" action="{{ route('post.downloadSignature') }}" method="post">
                    @csrf
                    <input type="hidden" name="user_id" id="signature_user_id">
                </form>
                <table id="" class="stripe user-table" style="width:100%">
                    <thead>
                        <tr>
                            <th>Last Name</th>
                            <th>First Name</th>
                            <th>Email Id</th>
                            <th>Role</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
      

<script>
    
    $( window ).on("load", function() {
        // Handler for .load() called.
        $('#userAddModal').find('form')[0].reset();
    });

    //fetch table list 
    $(function () {
        
        $('#passwordField').popover({
            container: 'body',
            html:true,
            placement:'right'
        });

        $('#userpass').popover({
            container: 'body',
            html:true,
            placement:'right'
        });
        
        var resultTable = $('.user-table').DataTable({
            processing: true,
            serverSide: false,
            order: [],
            "language": {
                "processing": "<img style='width:80px; height:80px;' src='{{url('/assets/images/loaderspinner.gif')}}' >"
            },
            ajax: "{{ route('users') }}",
            columns: [
                {data: 'lastname', name: 'lastname'},
                {data: 'firstname', name: 'firstname'},
                {data: 'email', name: 'email'},
                {data: 'role_name', name: 'role_name', orderable: true, searchable: true},
                {data: 'action', name: 'action', orderable: false, searchable: false},
            ]
        });
        
        jQuery.validator.addMethod("lettersonly", function(value, element) {
            // return this.optional(element) || /^[a-z\s]+$/i.test(value);
            return this.optional(element) || /^[a-zA-Z](?:[ '\-a-zA-Z]*[a-zA-Z])?$/i.test(value);
        }, "Only alphabetical characters");

        jQuery.validator.addMethod("strong_password", function (value, element) {
            let password = value;
            if (!(/^(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%&])(.{8,15}$)/.test(password))) {
                return false;
            }
            return true;
        }, function (value, element) {

            let password = $(element).val();

            if (!(/^(.{8,15}$)/.test(password))) {
                return 'Password must be between 8 to 15 characters.';
            }
            else if (!(/^(?=.*[A-Z])/.test(password))) {
                return 'Password must contain at least one Capital Letter.';
            }
            else if (!(/^(?=.*[0-9])/.test(password))) {
                return 'Password must contain at least one number.';
            }
            else if (!(/^(?=.*[@#$%&])/.test(password))) {
                return "Password must contain at least one special character from @#$%&.";
            }
            return false;
        });

        //this is used for apply the validation on add User form
        $("#addUserForm").validate({

            rules: {
                firstName:{
                    required:true,
                    lettersonly:true,
                    maxlength:30
                },
                lastName:{
                    required:true,
                    lettersonly:true,
                    maxlength:30
                },
                userId:{
                    required:true,
                },                    
                email: {
                    required:true,
                    email:true
                },
                password: {
                    required:true,
                    strong_password:true
                },
                password_confirmation:{
                    required:true,
                    equalTo:'#passwordField'
                }

            },

            messages: {
                firstName:{
                    required:"First Name is required",
                    maxlength:"Please enter character between 1-30 length"
                },
                lastName:{
                    required:"Last Name is required",
                    maxlength:"Please enter character between 1-30 length"
                }, 
                email: {
                    required:"Email Id is required",
                    email:"Email Id is not valid"
                },
                userId:{
                    required:"User Id is required",
                },
                password: {
                    required:"Password is required",
                },
                password_confirmation:{
                    required:"Confirm Password is required",
                    equalTo:'Confirm Password does not match'
                }

            },

            errorPlacement: function(label, element) {

                label.addClass('mt-2 text-danger');

                label.insertAfter(element);

            },

            highlight: function(element, errorClass) {

                $(element).parent().addClass('has-danger');

                $(element).addClass('form-control-danger');

            },

            unhighlight: function(element, errorClass, validClass) {

                $(element).parents().removeClass('has-danger');

                    $(element).removeClass('form-control-danger');

                $(element).parents('.form-group').addClass('has-success');

            }

        });
        //<=--------------------- END validation ------------------------------->

        //this is used for apply the validation on add user form
        $("#editForm").validate({

            rules: {
                firstName:{
                    required:true,
                    lettersonly:true,
                    maxlength:30
                },
                lastName:{
                    required:true,
                    lettersonly:true,
                    maxlength:30
                },                    
                userId:{
                    required:true,
                },
                email: {
                    email:true
                },
                password: {
                    required:true,
                    minlength:8
                },
                password_confirmation:{
                    required:true,
                    equalTo:'#passwordField'
                }
            },

            messages: {
                firstName:{
                    required:"First Name is required",
                    maxlength:"Please enter character between 1-30 length"
                },
                lastName:{
                    required:"Last Name is required",
                    maxlength:"Please enter character between 1-30 length"
                }, 
                email: {
                    email:"Email Id is not valid"
                },
                userId:{
                    required:"User Id is required",
                },
                password: {
                    required:"Password is required",
                    minlength:"Enter valid password 8-15 character"
                },
                password_confirmation:{
                    required:"Confirm Password is required",
                    equalTo:'Confirm Password does not match'
                }

            },

            errorPlacement: function(label, element) {

                label.addClass('mt-2 text-danger');

                label.insertAfter(element);

            },

            highlight: function(element, errorClass) {

                $(element).parent().addClass('has-danger');

                $(element).addClass('form-control-danger');

            },

            unhighlight: function(element, errorClass, validClass) {

                $(element).parents().removeClass('has-danger');

                    $(element).removeClass('form-control-danger');

                $(element).parents('.form-group').addClass('has-success');

            }

        });
        //<=---------------------END validation ------------------------------->


        $("#email").change(function(){
            checkUserId();
        });

        //this is used for add or edit user functionality
        $(document).ready(function() {

            //this is used for apply the validation on changepassword form
            $("#changepasswordForm").validate({

                rules: {
                    password:{
                        required:true,
                        strong_password:true
                    },
                    password_confirmation:{
                        required:true,
                        equalTo:'#userpass'
                    }

                },
                messages: {

                    password:{
                        required:"New Password is required",
                    },
                    password_confirmation:{
                        required:"Confirm New Password is required",
                        equalTo:'Confirm Password does not match'
                    }

                },

                errorPlacement: function(label, element) {

                    label.addClass('mt-2 text-danger');

                    label.insertAfter(element);

                },

                highlight: function(element, errorClass) {

                    $(element).parent().addClass('has-danger');

                    $(element).addClass('form-control-danger');

                },

                unhighlight: function(element, errorClass, validClass) {

                    $(element).parents().removeClass('has-danger');

                        $(element).removeClass('form-control-danger');

                    $(element).parents('.form-group').addClass('has-success');

                }

            });
            //<=---------------------END validation ------------------------------->

            $(document).on('click','.editbtn', function() {
                
                var id = $(this).attr('data-id');
                $.ajax({
                    url: "{{route('users.get')}}",
                    type: "GET",
                    dataType:'json',
                    data: {id:id,_token:"{{csrf_token()}}"},

                    success:function(output){
                        
                        if (output.status == true) {
                            var data = output.data;
                            var fName = data.name.split(" ");
                            $('#firstName').val(fName[0]);
                            fName.shift();
                            $('#lastName').val(fName.toString().replace(",", " "));
                            $('#editemail').val(data.email);
                            $('#edituserId').val(data.user_id);
                            $('#idval').val(data.id);
                            $('#edit_user_role').val(data.role_id).trigger('change');
                            if (data.email == '' || data.email == null) {
                                $('#emailId').css('display','block');
                            } else {
                                $('#emailId').css('display','none');
                            }
                            $('#editModal').modal('show');
                        } else if (output.status == false) {
                            swal({
                                title: "Oops!",
                                text: output.msg,
                                icon: "error",
                            });
                        } else {
                            location.reload(); 
                        }
                        
                    },
                    error:function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            console.log('500 status');
                        } else {
                            console.log('something went wrong!');
                        }
                        window.location.reload(true);
                    },
                });
            });

            //open change password modal
            $(document).on('click','.changepass', function(){
                $('#changepassId').val($(this).attr('data-id'));
                $('#changepasswordModal').modal('show');
            });

            $(document).on('submit','#changepasswordForm',function(e) {
                e.preventDefault();
                if(!$("#changepasswordForm").valid()) {
                    alert('Something went wrong at time of fill the form');
                    return;
                } 
                $.ajax({
                    url: "{{ route('users.updatepassword') }}",
                    type: "post",
                    data: $(this).serialize() +'&_token='+"{{ csrf_token() }}",
                    beforeSend:function() {
                        swal({
                            icon: "{{ url('/assets/images/loader.gif') }}",
                            text: 'Please Wait!',
                            buttons: false,
                            closeOnClickOutside:false
                        
                        });
                    },
                    success:function(data) {
                        console.log(data,'forms');
                        swal.close();
                        if (data.status == true) {

                            $('#changepasswordModal').modal('hide');

                            swal({
                                title: "Great!",
                                text: data.msg,
                                icon: "success",
                            }).then(function(event) {
                                if(event) {
                                    resultTable.ajax.reload();
                                }
                            });

                        } else if (data.status == false) {
                            swal({
                                title: "Oops!",
                                text: data.msg,
                                icon: "error",
                            });
                        } else {
                            location.reload();
                        }
                    },
                    error:function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            console.log('500 status');
                        } else {
                            console.log('something went wrong!');
                        }
                        location.reload();
                    },
                });
            });

            //for update user
            $(document).on('submit','#editForm',function(e) {
    
                e.preventDefault();
                if(!$("#editForm").valid()) {
                    alert('Something went wrong at time of fill the form');
                    return;
                } 
                $.ajax({
                    url: "{{ route('users.update') }}",
                    type: "post",
                    data: $(this).serialize() +'&_token='+"{{ csrf_token() }}",
                    beforeSend:function() {
                        swal({
                            icon: "{{ url('/assets/images/loader.gif') }}",
                            text: 'Please Wait!',
                            buttons: false,
                            closeOnClickOutside:false
                        
                        });
                    },
                    success:function(data){
                        console.log(data,'forms');
                        swal.close();
                        if (data.status == true) {

                            $('#editModal').modal('hide');

                            swal({
                                title: "Great!",
                                text: data.msg,
                                icon: "success",
                            }).then(function(event){
                                if(event) {
                                    resultTable.ajax.reload();
                                }
                            });

                        } else if (data.status == false) {
                            swal({
                                title: "Oops!",
                                text: data.msg,
                                icon: "error",
                            });
                        } else {
                            location.reload(); 
                        }
                    },
                    error:function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status == 500) {
                            console.log('500 status');
                        } else {
                            console.log('something went wrong!');
                        }
                        location.reload();
                    },
                });
            });

            //for add user personnel
            $(document).on('submit','#addUserForm',function(e){
                e.preventDefault(); 
                if(!$("#addUserForm").valid()) {
                    alert('Something went wrong at time of fill the form');
                    return;
                }
                
                $.ajax({
                    url: "{{ route('users.add') }}",
                    type: "post",
                    data: $(this).serialize() +'&_token='+"{{ csrf_token() }}",
                    beforeSend:function() {
                        
                        swal({
                            icon: "{{ url('/assets/images/loader.gif') }}",
                            text: 'Please Wait!',
                            buttons: false,
                            closeOnClickOutside:false
                        
                        });
                    },
                    success:function(data){
                        console.log(data,'forms');
                        swal.close();
                        if (data.status == true) {

                            $('#userAddModal').modal('hide');
                            resultTable.ajax.reload();
                            swal({
                                title: "Great!",
                                text: data.msg,
                                icon: "success",
                            });

                        } else if (data.status == false) {
                            swal({
                                title: "Oops!",
                                text: data.msg,
                                icon: "error",
                            });
                        } else {
                            location.reload();
                        }
                    },
                    error:function (jqXHR, textStatus, errorThrown) {
                        location.reload();
                    },
                });
            });
            // ---------------- End add user perosonnel --------------------------
        });
        //--------------- END --------------------- 

        //this is used for delete a user
        $(document).on('click','.deletebtn',function(event){

            let id = $(this).attr('data-id');

            swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this User",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                closeOnClickOutside:false
            }).then((willDelete) => {
                if (willDelete) {
                    
                    $.ajax({
                        url: "{{route('users.delete')}}",
                        type: "POST",
                        data: {idval:id,_token:"{{ csrf_token() }}"},
                        beforeSend:function() {
                            swal({
                                icon: "{{ url('/assets/images/loader.gif') }}",
                                text: 'Please Wait...',
                            
                            });
                        },
                        success:function(data){
                            
                            swal.close();
                            if (data.status == true) {
                                resultTable.ajax.reload();
                                swal({
                                    title: "Great!",
                                    text: data.msg,
                                    icon: "success",
                                });

                            } else if (data.status == false) {
                                swal({
                                    title: "Oops!",
                                    text: data.msg,
                                    icon: "error",
                                });
                            } else {
                                location.reload();
                            }
                        },
                        error:function (jqXHR, textStatus, errorThrown) {
                            if (jqXHR.status == 500) {
                                console.log('500 status');
                            } else {
                                console.log('something went wrong!');
                            }
                            location.reload();
                        },
                    });

                } else {}
            });
        });
        //--------------END delet user functionality----------------------

        //this is used for set value as email address on userid when checkbox is checked
        $(document).on('keyup','#email',function(){
            console.log($(this).val());

            if($('#checkUserId').prop('checked')) {
                $('#userId').val($(this).val());
            }
            
        });        

        $(document).on('click','#checkUserId',function(){
            console.log($('#checkUserId').prop('checked'));

            if($('#checkUserId').prop('checked')) {
                // $(this).val($('#email').val());
                $('#userId').attr('readonly',true);
                $('#userId').val($('#email').val());
            }
            else {
                
                $('#userId').val('');
                $('#userId').attr('readonly',false);
            }
            
        });
        //--------------END ----------------------------------

        $(document).on('click','.downloadsignature', function() {
            
            let id = $(this).attr('data-id');
            $('#signature_user_id').val(id);
            $('#downloadSignatureForm').submit();
            
        });

    });
    
    function visibility(id,event) {

        var x = document.getElementById(id);
        
        if (x.type === 'password') {
                x.type = "text";
                $(event).removeClass('fa-eye-slash');
                $(event).addClass('fa-eye');
        } else {
                x.type = "password";
                $(event).removeClass('fa-eye');
                $(event).addClass('fa-eye-slash');
        }
    }

    $(document).on('click','.access_denied',function() {

        swal({
            icon: "error",
            title:'Oops!',
            text: 'You do not have permission to perform this action',
            // buttons: false,
            closeOnClickOutside:false
            
        });
    });
</script>
@endsection