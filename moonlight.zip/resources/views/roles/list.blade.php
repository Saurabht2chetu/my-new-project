
@extends('layouts.adminlayout')
@section('title','Role and Permissions Management- Moonlight Examinations')

@section('content')
<style>

.swal-icon--custom img {
            width:50px!important;
            height:50px!important;
        }
        .swal-modal .swal-text {
            text-align: center;
        }
        .swal-footer {
            text-align: center!important;
        }

</style>
        
<div class="container-fluid">
    <div class="db-top4-box-wrapper">

        <div class="mt-3 hm-dis">
            <p class="db-heading"><a href="{{ route('dashboard') }}">Dashboard / </a> Role & Permissions Management</p>
        </div>
    </div>
    @if (session('status'))
            <div class="alert alert-success" role="alert">
                {{ session('status') }}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        @endif    
    <!-- Begining of Role Management form------------------------>
    <form action="{{ route('add-role') }}" method="POST">
        @csrf
        <div class="dashboard-table1 role-main">
            <!-- <div class="mb-3">
                <h4>Role Management</h4>
            </div> -->
        <!-- Begenning of row--------------------------------------->
            <div class="row">
                <!-- Begining of col-left------------------------>
                <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                    <div class="rol-content">
                        <h5 class="mb-3">Select Role Type</h5>
                        <div class="input-group mb-3">
                            <select class="form-control" name="chooseRole" id="userRole" required>
                                @foreach($roles as $role)
                                
                                @if(session('roletype') == $role->id)  
                                <option value="{{$role->id}}" selected>{{$role->name}}</option>
                                @else 
                                <option value="{{$role->id}}" >{{$role->name}}</option>
                                @endif
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
                <!-- End of col-left------------------------>
                <!-- Begin col-right------------------------>

                <div class="col-lg-6 col-md-12 col-12">

                    <div class="rol-list" id="permissionSection">

                        @foreach($menus as $key => $menu)
                        <div class="rol-check d-flex align-items-center role-a">
                            <div class="sho">
                                <input type="checkbox" class="itemMenu" name="menu[]" value="{{$menu->id}}" data-id="addsection_{{$key}}" data-key="{{$menu->id}}"   > {{$menu->name}}
                            </div>                               
                            <div id="addsection_{{$key}}">

                            </div>
                        </div>
                        
                        @endforeach  
                    </div>
                </div>
            <!-- End col-right------------------------>

            </div>

            <!-- Ending of Row------------------------------>
            <hr class="mtb">
            <div class="role-butt">
                <button class="lft-arrow" type="button" onclick="return window.history.back();"> <span class="rol-lf"><i
                            class="fas fa-arrow-left"></i></span>Back</button>
                <button class="rgt-arrow" type="submit">Submit <span class="rol-rt"><i
                            class="fas fa-arrow-right"></i></span></button>
            </div>
        </div>
        <!-- Ending of Role Management form------------------------>

    </form>
</div>
     

<script>

function add_read_write(event) {
   
    if(!$(event).prop('checked')) {
        $('#'+$(event).attr('data-id')).html('');
    }
    else {
        var dataId = $(event).attr('data-id');
        var key = $(event).attr('data-key');
        let html = '<div class="check-hide mx-2 " id=""> <input type="radio" name="menu['+key+'][]" value=0 class="" id="" checked >Read <input type="radio" class="" id="" name="['+key+'][]" value=1 > Write</div>';
        console.log($(event).attr('data-id'));
        $('#'+$(event).attr('data-id')).html(html);
        history.forward();
    }
   
    
}

$(document).ready(function(){
   
    $(document).on('click','.itemMenu',function(e) {
        // e.preventDefault();
        let event = this;
        if(!$(event).prop('checked')) {
            $('#'+$(event).attr('data-id')).html('');
        }
        else {
            var dataId = $(event).attr('data-id');
            var key = $(event).attr('data-key');
            let html = '<div class="check-hide mx-2 " id=""> <input type="radio" name=menu_['+key+'][] value=0 class="" id="" checked > Read &nbsp;&nbsp;<input type="radio" class="" id="" name=menu_['+key+'][] value=1 > Read & Write</div>';
            $('#'+$(event).attr('data-id')).html(html);
            
        }
    });
});


function getPermissionList(id) {

    $.ajax({
        url: "{{ route('get.permissonlist')}}",
        type: "GET",
        dataType:'json',
        data: {role_id:id,_token:"{{csrf_token()}}"},
        beforeSend:function() {
            
            // swal({
            //     icon: "{{ url('/assets/images/loader.gif') }}",
            //     text: 'Loading!',
            //     buttons: false,
            //     closeOnClickOutside:false
            
            // });
        },
        success:function(output){
            // swal.close();
            if(output.status) {

                var htmlcontent = '';
                $.each(output.data,function(i,val){
                    $checked = '';
                    if(val.is_writable != null) {
                        $checked = 'checked';
                    }
                    htmlcontent += '<div class="rol-check d-flex align-items-center role-a"><div class="sho"><input type="checkbox" class="itemMenu" name="menu[]" value="'+val.id+'" data-id="addsection_'+i+'" data-key="'+val.id+'" '+$checked+'> '+val.name+'</div><div id="addsection_'+i+'">';
                    
                    if(val.is_writable != null) {

                        if(val.is_writable == 0) {

                            htmlcontent += '<div class="check-hide mx-2 " id=""> <input type="radio" name=menu_['+val.id+'][] value=0 class="" checked > Read &nbsp;&nbsp;<input type="radio" class="" id="" name=menu_['+val.id+'][] value=1> Read & Write</div>';

                        }
                        else {
                            htmlcontent += '<div class="check-hide mx-2 " id=""> <input type="radio" name=menu_['+val.id+'][] value=0 class="" > Read &nbsp;&nbsp;<input type="radio" class="" id="" name=menu_['+val.id+'][] value=1 checked > Read & Write</div>';

                        }

                        
                    }
                    else {
                        // htmlcontent += '<div class="check-hide mx-2 " id=""> <input type="radio" name=menu_['+val.id+'][] value=0 class="" id="" checked >Read <input type="radio" class="" id="" name=menu_['+val.id+'][] value=1> Read & Write</div>';
                    }
                    
                    htmlcontent += '</div></div>';
                });

                $('#permissionSection').html(htmlcontent);
            }
            else {
                swal({
                    title: "Sorry!",
                    text: output.msg,
                    icon: "error",
                });
            }
            
        },
        error:function (jqXHR, textStatus, errorThrown) {
            if (jqXHR.status == 500) {
                console.log('500 status');
            } else {
                console.log('something went wrong!');
            }
        },
    });

}

$(document).on('change','#userRole',function() {
    
    let userRole = $(this).val();
    getPermissionList(userRole);
});

getPermissionList($('#userRole').val());

</script>
@endsection