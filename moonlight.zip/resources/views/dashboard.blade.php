@extends('layouts.adminlayout')
@section('title','Dashboard - Moonlight Examinations')

@section('content')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
    .select2-container {
        width: 100%!important;
        /* font-size: 1rem;
        line-height: 1.5;
        color: #495057;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid #ced4da;
        border-radius: 10px!important; */
        transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;

    }

    .select2-results__option {
        padding-right: 20px;
        vertical-align: middle;
    }
    .select2-results__option:before {
        content: "";
        display: inline-block;
        position: relative;
        height: 20px;
        width: 20px;
        border: 2px solid #e9e9e9;
        border-radius: 4px;
        background-color: #fff;
        margin-right: 20px;
        vertical-align: middle;
    }
    .select2-results__option--selected:before {
        font-family:fontAwesome;
        content: "\f00c";
        color: #fff;
        background-color: #e1c331;
        border: 0;
        display: inline-block;
        padding-left: 3px;
        font-size: 14px;
    }
    .select2-container--default .select2-results__option[aria-selected=true] {
        background-color: #fff;
    }
    .select2-container--default .select2-results__option--highlighted[aria-selected] {
        background-color: #eaeaeb;
        color: #272727;
    }
    .select2-container--default .select2-selection--multiple {
        margin-bottom: 10px;
    }
    .select2-container--default.select2-container--open.select2-container--below .select2-selection--multiple {
        border-radius: 4px;
    }
    .select2-container--default.select2-container--focus .select2-selection--multiple {
        border-color: #f77750;
        border-width: 2px;
    }
    .select2-container--default .select2-selection--multiple {
        border-width: 2px;
    }
    .select2-container--open .select2-dropdown--below {
        
        border-radius: 6px;
        box-shadow: 0 0 10px rgba(0,0,0,0.5);

    }
    .select2-selection .select2-selection--multiple:after {
        content: '';
    }
    /* select with icons badges single*/
    .select-icon .select2-selection__placeholder .badge {
        display: none;
    }
    .select-icon .placeholder {
    /* 	display: none; */
    }
    .select-icon .select2-results__option:before,
    .select-icon .select2-results__option[aria-selected=true]:before {
        display: none !important;
        /* content: "" !important; */
    }
    .select-icon .select2-search--dropdown {
        display: none;
    }
</style>

<div class="container-fluid">
    <div class="mb-3">
        <h4>Matrix Dashboard</h4>
    </div>
    <div class="dashboard-table1 mb-0">
        
        <form id="filterRecordForm">

            <div class="row" style="align-items: end;">
                
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="select_clinic">Clinic Type</label>
                        <select class="form-control" id="select_clinic" name="select_clinic[]" multiple>
                            @foreach($clinicTypes as $clinic)
                            <option data-badge="" value="{{$clinic->id}}">{{$clinic->name}}</option>
                            @endforeach
                        </select>                                  
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                        <label for="from_date">From</label>
                        <input type="text" class="form-control" id="from_date" name="from_date">
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                        <label for="to_date">To</label>
                        <input type="text" class="form-control" id="to_date" name="to_date">
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                        <button class="btn-main clinic-btn">Search</button>
                        <a style="background: var(--yellow);" class="btn-main" href="{{route('dashboard')}}"> Reset</a>
                    </div>
                </div>
            </div>
        </form>
    
    </div>
    <div class="container-fluid px-0">
        <div class="dashboard-table1">
            <form id="exportDashboard" action="{{ route('exportDashboardReport')}}">
                @csrf
                <input type="hidden" name="fromDate" id="fromDate" value="">
                <input type="hidden" name="toDate" id="toDate" value="">
                <input type="hidden" name="clinicType[]" id="clinicType" value="">
                <button type="submit" class="btn-main " style="float:right;">Export</button>
            </form>
            <div class="mb-3">
                <h4>Volume Count</h4>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <table class="stripe dashboard-table" style="width:100%">
                        <thead>
                            <tr>
                                <th style="width:95px">Service Date</th>
                                <th>Clinic Name</th>
                                <th>State</th>
                                <th>Scheduled</th>
                                <th style="width:85px">Clinic Type</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <!-- <div class="container-fluid">
        <div class="dashboard-table1 pt-mdb">
            <div class="mb-3">
                <h4>My Report</h4>
            </div>
            <main>
                <div id="bar-chart"></div>
            </main>
        </div>
    </div> -->
</div>


<!-- cdn link of select2 jquery -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.13.0/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.13.0/jquery-ui.js"></script>

<script>

    function setDefaultDate(date) {

        let dayOfWeekNumber = date.getDay();
        let adjustDate = date;

        switch(dayOfWeekNumber) {
            case 0: 
                nameOfDay = 'Sunday';
                adjustDate.setDate(adjustDate.getDate() + 3);
                return adjustDate;
                break;
            case 1:
                nameOfDay = 'Monday';
                adjustDate.setDate(adjustDate.getDate() + 2);
                return adjustDate;
                break;
            case 2:
                nameOfDay = 'Tuesday';
                adjustDate.setDate(adjustDate.getDate() + 1);
                return adjustDate;
                break;
            case 3:
                nameOfDay = 'Wednesday';
                return adjustDate;
                break;
            case 4:
                nameOfDay = 'Thursday';
                adjustDate.setDate(adjustDate.getDate() - 1);
                return adjustDate;
                break;
            case 5:
                nameOfDay = 'Friday';
                adjustDate.setDate(adjustDate.getDate() - 2);
                return adjustDate;
                break;
            case 6:
                nameOfDay = 'Saturday';
                adjustDate.setDate(adjustDate.getDate() - 2);
                return adjustDate;
                break;

        }
    }

    $(function(){

        $('#select_clinic').select2({
            closeOnSelect : false
        });

        let previous_date = new Date();
        let next_date = new Date();
        previous_date.setDate(previous_date.getDate() - 7).toLocaleString();
        next_date.setDate(next_date.getDate() + 7).toLocaleString();
        let from_date = setDefaultDate(new Date(previous_date));
        let to_date = setDefaultDate(new Date(next_date));

        $("#from_date" ).attr('readonly','readonly').datepicker({
            "dateFormat":'mm-dd-yy',
            changeMonth:true,
            changeYear:true,
            yearRange:"-10:+10",
            onSelect:function (e) {
                console.log('datepicker',e);
                $( "#to_date" ).datepicker("option","minDate",e);
            }
        }).datepicker("setDate",from_date);

        $( "#to_date" ).attr('readonly','readonly').datepicker({
            "dateFormat":'mm-dd-yy',
            changeMonth:true,
            changeYear:true,
            yearRange:"-10:+10",
            minDate:$('#from_date').val(),
            onSelect:function (e) {
                $( "#from_date" ).datepicker("option","maxDate",e);
            }
        }).datepicker("setDate",to_date);
    

        // Fetch all Clinic Service data
        var resultTable = $('.dashboard-table').DataTable({
            processing: true,
            serverSide: false,
            order: [],
            "language": {
                "processing": "<img style='width:80px; height:80px;' src='{{url('/assets/images/loaderspinner.gif')}}' >"
            },
            ajax:{
                url:"{{ route('dashboard') }}",
                data:function(data) {                  
                    data.from_date = $('#from_date').val();
                    data.to_date = $('#to_date').val();
                    data.clinic_type = $('#select_clinic').val();
                }
            },
            columns: [
                {data: 'service_date', name: 'service_date'},
                {data: 'location_name', name: 'location_name'},
                {data: 'state_name', name: 'state_name'},
                {data: 'scheduled', name: 'scheduled'},
                {data: 'clinic_type', name: 'clinic_type'},
            ]
        });

        $(document).on('submit', '#filterRecordForm', function(e){
            e.preventDefault();
            resultTable.ajax.reload();
        });

        $(document).on('click', '#exportDashboard', function(e){
            e.preventDefault();
            $('#fromDate').val($('#from_date').val());
            $('#toDate').val($('#to_date').val());
            $('#clinicType').val($('#select_clinic').val());
            var fromDate = $('#fromDate').val();
            var toDate = $('#toDate').val();
// return;
            $('#exportDashboard').submit();
        });

    });

</script>

@endsection