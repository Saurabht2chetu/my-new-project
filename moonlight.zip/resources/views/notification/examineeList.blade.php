@extends('layouts.adminlayout')
@section('title','Notification Examinee List - Moonlight Examinations')

@section('content')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<div class="container-fluid">
    <div class="db-top4-box-wrapper">
        <div class="mt-3 hm-dis">
            <p class="db-heading"><a href="{{ route('dashboard') }}">Dashboard</a> / <a href="{{ route('appointment-reminder') }}">Appointment Reminder</a> / Examinee List</p>
        </div>

        @if (session('status'))
            <div class="alert alert-success" role="alert">
                {{ session('status') }}
            </div>
        @endif

        @if (session('error'))
            <div class="alert alert-danger" role="alert">
                {{ session('error') }}
            </div>
        @endif


    
    </div>

    <div class="dashboard-table1">
        
       
        <div class="row">
            <div class="col-md-12">
               
                <table id="" class="stripe user-table" style="width:100%">
                    <thead>
                        <tr>
                            <th>Examinee Name</th>
                            <th>Examinee Phone</th>
                            <th>Message</th>
                            <th>status</th>
                        </tr>
                    </thead>
                    <tbody>
                    
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- cdn link of select2 jquery -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>

    $(function() {

        $('#service_location').select2({
            closeOnSelect : false,
            placeholder:'Select Service date - Clinic Name'
        });

        $('#template_name').select2({
            closeOnSelect : false,
            placeholder:'Select Template Name'
        });

        var resultTable = $('.user-table').DataTable({
            processing: true,
            serverSide: false,
            order: [],
            "language": {
                "processing": "<img style='width:80px; height:80px;' src='{{url('/assets/images/loaderspinner.gif')}}' >"
            },
            ajax: {
                method:'GET',
                url:"{{ route('get.notification.examinee') }}",
                data:function(data) {
                    data.notification_id = "{{ $notificationId }}";
                },
            },
            columns: [
                {data: 'patient_name', name: 'patient_name'},
                {data: 'patient_phone', name: 'patient_phone'},
                {data: 'message', name: 'message'},
                {data: 'message_status', name: 'message_status',orderable: false, searchable: false},
            ]
        });

        
    });

</script>


@endsection