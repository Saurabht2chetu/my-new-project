@extends('layouts.adminlayout')
@section('title','Notification Template - Moonlight Examinations')

@section('content')
 
<div class="container-fluid">
    <div class="db-top4-box-wrapper">
        <div class="mt-3 hm-dis">
            <p class="db-heading"><a href="{{ route('dashboard') }}">Dashboard</a> / Notification Template</p>
          
            <button class="btn-main" data-toggle="modal" data-target="#addtemplateModal"><i
                    class="fas fa-plus"></i> Add Template</button>
                    
        </div>
        @if (session('status'))
            <div class="alert alert-success" role="alert">
                {{ session('status') }}
            </div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger" role="alert">
                {{ session('error') }}
            </div>
        @endif

        <!-- Add Modal Form starts -->
        <div class="modal fade md-round" id="addtemplateModal" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">

                    <div class="p-3">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="login-form">
                            <div class="text-center mb-4">
                                <h4>Add New Template </h4>
                            </div>
                            <form action="" method="POST" id="addTemplateForm">
                                
                                <div class="form-group">
                                <label for="add_template_title">Title <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        
                                        <input type="text" name="title" id="add_template_title" class="form-control frm-input-1" maxlength="40" placeholder="Title" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                <label for="add_template_message">Message <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <textarea class="form-control frm-input-1 w-100" name="template_message" id="add_template_message" cols="10" rows="5" placeholder="Message" required></textarea>
                                        <small class="p-2"><strong>Hint:</strong> please enter same format for replacement of dynamic values :-   <br> {Day}, {Date}, {Time}</small>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <div class="formicon-parent">
                                        <button type="submit"
                                            class="btn btn-block login-btn-01">SUBMIT</button><span><i
                                                class="fas fa-arrow-right login-icon-right arr"></i></span>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Add Modal Form End -->

          <!-- Edit Modal Form starts -->
          <div class="modal fade md-round" id="edittemplateModal" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">

                    <div class="p-3">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="login-form">
                            <div class="text-center mb-4">
                                <h4>Update Template </h4>
                            </div>
                            <form action="" method="POST" id="editTemplateForm">
                                
                                <div class="form-group">
                                <label for="edit_template_title">Title <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <input type="hidden" name="template_id" id="template_id" value="">
                                        <input type="text" name="title" id="edit_template_title" class="form-control frm-input-1" maxlength="40" placeholder="Title" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                <label for="edit_template_message">Message <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <textarea class="form-control frm-input-1 w-100" name="template_message" id="edit_template_message" cols="30" rows="5" placeholder="Message" required></textarea>
                                        <small class="p-2"><strong>Hint:</strong> please enter same format for replacement of dynamic values :- <br>   {Day}, {Date}, {Time}</small>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <div class="formicon-parent">
                                        <button type="submit"
                                            class="btn btn-block login-btn-01">UPDATE</button><span><i class="fas fa-arrow-right login-icon-right arr"></i></span>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Add Modal Form End -->
    
    </div>
    <div class="dashboard-table1">
        
        <div class="mb-3">
            <h4>Template List</h4>           
        </div>
        <div class="row">
            <div class="col-md-12">
               
                <table id="" class="stripe user-table" style="width:100%">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Message</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>

    $(function() {

        var resultTable = $('.user-table').DataTable({
            processing: true,
            serverSide: false,
            order: [],
            "language": {
                "processing": "<img style='width:80px; height:80px;' src='{{url('/assets/images/loaderspinner.gif')}}' >"
            },
            ajax: "{{ route('notification-template') }}",
            columns: [
                {data: 'title', name: 'title'},
                {data: 'message', name: 'message'},
                {data: 'action', name: 'action', orderable: false, searchable: false},
            ]
        });

        // this is used to add template
        $(document).on('submit','#addTemplateForm',function (e) {

            e.preventDefault();
            if (!$(this).valid()) {
                alert('Something went wrong at the time of filling the form');
                return;
            }

            $.ajax({
                url: "{{ route('post.addNewTemplate') }}",
                type: "post",
                data: $(this).serialize() +'&_token='+"{{ csrf_token() }}",
                beforeSend:function() {
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    });
                },
                success:function(data){
                    
                    swal.close();

                    if (data.status == true) {

                        $('#addtemplateModal').modal('hide');

                        resultTable.ajax.reload();

                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success",
                        });

                    } else if (data.status == false) {
                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error",
                        });
                    } else {
                        window.location.reload(true);
                    }
                },
                error:function (jqXHR, textStatus, errorThrown) {
                    window.location.reload(true);

                },
            });
        });
        //<!---------------- END  ------------------------>
        
         // To get clinic service data to update
        $(document).on('click','.template_editbtn', function() {
            
            let id = $(this).attr('data-id');

            $.ajax({
                url:"{{ route('get.getTemplate') }}",
                type:'GET',
                data: {_token:"{{ csrf_token()}}",template_id:id},
                dataType:'json',
                beforeSend:function() {
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    
                    });
                },
                success:function(output) {

                    swal.close();

                    if (output.status == true) {

                        let data = output.data;
                    
                        $('#template_id').val(data.id);
                        $('#edit_template_title').val(data.title);
                        $('#edit_template_message').val(data.message);
                       
                        $('#edittemplateModal').modal('show');

                    } else if (output.status == false) {

                        swal({
                            title: "Oops!",
                            text: output.msg,
                            icon: "error",
                        });
                    } else {
                        window.location.reload(true);
                    }
                },
                error:function (jqXHR, textStatus, errorThrown) {
                    window.location.reload(true);
                },
            });
        });

         // this is used to add template
        $(document).on('submit','#editTemplateForm',function (e) {

            e.preventDefault();

            if (!$(this).valid()) {
                alert('Something went wrong at the time of filling the form');
                return;
            }

            $.ajax({
                url: "{{ route('post.updateTemplate') }}",
                type: "post",
                data: $(this).serialize() +'&_token='+"{{ csrf_token() }}",
                beforeSend:function() {
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    });
                },
                success:function(data) {
                    
                    swal.close();

                    if (data.status == true) {

                        $('#edittemplateModal').modal('hide');

                        resultTable.ajax.reload();

                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success",
                        });

                    } else if (data.status == false) {
                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error",
                        });
                    } else {
                        window.location.reload(true);
                    }
                },
                error:function (jqXHR, textStatus, errorThrown) {
                    window.location.reload(true);
                },
            });
        });
        //<!---------------- END  ------------------------>

        // this is used to delete a template 
        $(document).on('click', '.template_deletebtn', function(event) {

            let id  = $(this).attr('data-id');

            swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover the template",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                closeOnClickOutside:false
            }).then((willDelete) => {

                if (willDelete) {

                    $.ajax({
                        url: "{{ route('post.deleteTemplate') }}",
                        type: "POST",
                        data: {_token:"{{ csrf_token()}}", template_id:id},
                        beforeSend:function() {
                            swal({
                                icon: "{{ url('/assets/images/loader.gif') }}",
                                text: 'Please Wait...',
                            });
                        },
                        success:function(data) {

                            swal.close();

                            if (data.status == true) {

                                resultTable.ajax.reload();

                                swal({
                                    title: "Great!",
                                    text: data.msg,
                                    icon: "success",
                                });

                            } else if (data.status == false) {
                                swal({
                                    title: "Oops!",
                                    text: data.msg,
                                    icon: "error",
                                });
                            } else {
                                window.location.reload(true);
                            }
                        },
                        error:function (jqXHR, textStatus, errorThrown) {
                            window.location.reload(true);
                        },
                    });

                } else {}
            });
        });
        //<!------------------- END ----------------------------------->
        
    });

</script>


@endsection