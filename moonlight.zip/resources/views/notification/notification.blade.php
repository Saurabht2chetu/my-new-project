@extends('layouts.adminlayout')
@section('title','Appointment Reminder - Moonlight Examinations')

@section('content')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>

    table.dataTable tbody th, table.dataTable tbody td {
        white-space: nowrap;
    }
    #stickycontent .table td, .table th,#callcontent .table td, .table th {
        padding: 0.75rem;
        vertical-align: middle!important;
        text-align: center !important;
    }

    .select2-results__option {
        padding-right: 20px;
        vertical-align: middle;
    }
    .select2-results__option:before {
        content: "";
        display: inline-block;
        position: relative;
        height: 20px;
        width: 20px;
        border: 2px solid #e9e9e9;
        border-radius: 4px;
        background-color: #fff;
        margin-right: 20px;
        vertical-align: middle;
    }
    .select2-results__option--selected:before {
        font-family:fontAwesome;
        content: "\f00c";
        color: #fff;
        background-color: #e1c331;
        border: 0;
        display: inline-block;
        padding-left: 3px;
        font-size: 14px;
    }
    .select2-container--default .select2-results__option[aria-selected=true] {
        background-color: #fff;
    }
    .select2-container--default .select2-results__option--highlighted[aria-selected] {
        background-color: #eaeaeb;
        color: #272727;
    }
    .select2-container--default .select2-selection--multiple {
        margin-bottom: 10px;
    }
    .select2-container--default.select2-container--open.select2-container--below .select2-selection--multiple {
        border-radius: 4px;
    }
    .select2-container--default.select2-container--focus .select2-selection--multiple {
        border-color: #f77750;
        border-width: 2px;
    }
    .select2-container--default .select2-selection--multiple {
        border-width: 2px;
    }
    .select2-container--open .select2-dropdown--below {
        
        border-radius: 6px;
        box-shadow: 0 0 10px rgba(0,0,0,0.5);

    }
    .select2-selection .select2-selection--multiple:after {
        content: '';
    }
    /* select with icons badges single*/
    .select-icon .select2-selection__placeholder .badge {
        display: none;
    }
    
    .select-icon .select2-results__option:before,
    .select-icon .select2-results__option[aria-selected=true]:before {
        display: none !important;
        /* content: "" !important; */
    }
    .select-icon .select2-search--dropdown {
        display: none;
    }
    .select2-container {
        width:100%!important;
    }
    .select2-selection .select2-selection--multiple {

        min-height: 55px!important;   
        border-radius: 10px;
        border: 1px solid #ced4da;
        transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
    }

    .select2-container--default .select2-search--inline .select2-search__field {
    
        font-size: 15px!important;
        font-family: inherit!important;
    }

    .select2-container--default .select2-selection--multiple:before {
        content: ' ';
        display: block;
        position: absolute;
        border-color: #888 transparent transparent transparent;
        border-style: solid;
        border-width: 5px 4px 0 4px;
        height: 0;
        right: 6px;
        margin-left: -4px;
        margin-top: -2px;top: 50%;
        width: 0;cursor: pointer
    }

    .select2-container--open .select2-selection--multiple:before {
        content: ' ';
        display: block;
        position: absolute;
        border-color: transparent transparent #888 transparent;
        border-width: 0 4px 5px 4px;
        height: 0;
        right: 6px;
        margin-left: -4px;
        margin-top: -2px;top: 50%;
        width: 0;cursor: pointer
    }

    .color_designation {
        background: red;
        width: 20px;
        height: 21px;
        display: block;
        border-radius: 2px;
    }

    span#designation {
        display: inline-flex;
    }

    .close {
        float: right;
        font-size: 1rem;
        font-weight: 700;
        line-height: 1;
        color: #000;
        text-shadow: 0 0px 0 #fff;
        opacity: 1;
    }

    .modal-body {
        max-height: calc(100vh - 210px);
        overflow-y: auto;
    }

    .review-form .login-form {
        padding-top: 30px;
    }
    .review-form button.close {
        position: absolute;
        right: 20px;
        top: 10px;
    }

    .review-form::-webkit-scrollbar-track {
        box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
    }

    .review-form::-webkit-scrollbar-thumb {
        background-color: #b0b0b0;
        border-radius: 10px;
    }
    .review-form::-webkit-scrollbar {
        width: 0.5em;
    }

</style>

<div class="container-fluid">
    <div class="db-top4-box-wrapper">
        <div class="mt-3 hm-dis">
            <p class="db-heading"><a href="{{ route('dashboard') }}">Dashboard</a> / Appointment Reminder</p>
        </div>

        @if (session('status'))
            <div class="alert alert-success" role="alert">
                <strong>{{ session('status') }} </strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        @endif

        @if (session('error'))
            <div class="alert alert-danger" role="alert">
                {{ session('error') }}
            </div>
        @endif

        <!-- Add Modal Form starts -->
        <div class="modal fade md-round" id="addtemplateModal" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">

                    <div class="p-3">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="login-form">
                            <div class="text-center mb-4">
                                <h4>Add New Template </h4>
                            </div>
                            <form action="" method="POST" id="addTemplateForm">
                                
                                <div class="form-group">
                                <label for="add_template_title">Title <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        
                                        <input type="text" name="title" id="add_template_title" class="form-control frm-input-1" placeholder="Title" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                <label for="add_template_message">Message <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <textarea class="form-control frm-input-1 w-100" name="template_message" id="add_template_message" cols="30" rows="10" placeholder="Message" required></textarea>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <div class="formicon-parent">
                                        <button type="submit"
                                            class="btn btn-block login-btn-01">SUBMIT</button><span><i
                                                class="fas fa-arrow-right login-icon-right arr"></i></span>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Add Modal Form End -->

          <!-- Edit Modal Form starts -->
          <div class="modal fade md-round" id="edittemplateModal" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">

                    <div class="p-3">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="login-form">
                            <div class="text-center mb-4">
                                <h4>Update Template </h4>
                            </div>
                            <form action="" method="POST" id="editTemplateForm">
                                
                                <div class="form-group">
                                <label for="edit_template_title">Title <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <input type="hidden" name="template_id" id="template_id" value="">
                                        <input type="text" name="title" id="edit_template_title" class="form-control frm-input-1" placeholder="Title" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                <label for="edit_template_message">Message <span class="text-danger">*</span></label>
                                    <div class="formicon-parent">
                                        <textarea class="form-control frm-input-1 w-100" name="template_message" id="edit_template_message" cols="30" rows="10" placeholder="Message" required></textarea>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <div class="formicon-parent">
                                        <button type="submit"
                                            class="btn btn-block login-btn-01">UPDATE</button><span><i class="fas fa-arrow-right login-icon-right arr"></i></span>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Add Modal Form End -->
    
    </div>
    <!---------------------- send notification section  ----------------->
    <div class="dashboard-table1">
     
        <form id="clinicDocumentForm" action="{{ route('post.sendNotification') }}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="row">
                
                <div class="col-md-7">
                    <div class="form-group p-2 cli-grp">
                        <label for="service_location" class="font-weight-bold" >Service Date <span class="text-danger">*</span></label>
                        <div class="formicon-parent">
                            
                            <select class="form-control" id="notification_service_date" name="service_date" required>

                                <option value="">--Select Service Date--</option>
                                <?php 
                            
                                $appointmentList = getAppointmentDate();
                                
                                if(count($appointmentList) > 0) {

                                    foreach ($appointmentList as $key => $list) {
                                        echo  '<option data-badge="" value="'.date("m-d-Y",strtotime($list->service_date)).'" >'.date("m-d-Y",strtotime($list->service_date)).'</option>';
                                    }
                                }
                                ?>
                            </select>  
                        </div>
                    </div>
                </div>

                <div class="col-md-5">

                    <div class="form-group cli-grp">
                        <label for="" class="font-weight-bold" >Select Designation <span class="text-danger">*</span></label>
                        <div class="formicon-parent">

                            <div class="form-check form-check-inline">
                                <input class="form-check-input colour_designation" type="radio" id="green_check" value="0" name="color_type" required>
                                <label class="form-check-label font-weight-bold mt-1 ml-2" for="green_check"><span class="color_designation" style="background:#96D35F!important;"></span></label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input class="form-check-input colour_designation" type="radio" id="red_check" value="1" name="color_type" required>
                                <label class="form-check-label font-weight-bold mt-1 ml-2" for="red_check"><span class="color_designation bg-danger" style="background:#FF2600!important;"></span></label>
                            </div>
                            
                            <div class="form-check form-check-inline">
                                <input class="form-check-input colour_designation" type="radio" id="yellow_check" value="2" name="color_type" required>
                                <label class="form-check-label font-weight-bold mt-1 ml-2" for="yellow_check"><span class="color_designation" style="background:#FFF76B!important;"></span></label>
                            </div>
                        </div>
                    </div>
        
                </div>

                <div class="col-md-9 clinic_search" style="display:none">
                    <div class="form-group p-2 cli-grp">
                        <label for="template_name" class="font-weight-bold" >Choose Clinics <span class="text-danger">*</span></label>
                        <div class="formicon-parent">
                            <select class="form-control" id="clinic_list" name="clinic_list[]" multiple required>
                            </select>
                            
                        </div>
                    </div>
                </div>
                <div class="col-md-2 clinic_search" style="display:none; margin: 45px 0px 0px -20px;">
                    <input type="checkbox" id="checkbox"> Select All Clinics
                </div>
                <div class="col-md-7">
                    <div class="form-group p-2 cli-grp">
                        <label for="template_name" class="font-weight-bold" >Select Template <span class="text-danger">*</span></label>
                        <div class="formicon-parent">
                            <select class="form-control" id="template_n" name="template_name" required>
                                <option value="">--Select Template--</option>
                            <?php 
                                
                                if (isset($templateList) && count($templateList) > 0) {

                                    foreach ($templateList as $templist) {
                                        echo  '<option data-badge="" value="'.$templist->id.'" >'.$templist->title.'</option>';
                                    }
                                }
                            ?>
                            </select>  
                        </div>
                    </div>
                </div>

                <div class="col-md-5 d-flex align-items-end">
                    <div class="form-group p-2 cli-grp">
                        <div class="ex-btn-botm ">
                            <!-- <button class="btn-main">Send</button> -->
                            <span class="btn-main" data-toggle="modal" id="reviewBtn">Review</span>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Add Modal Review Starts -->
            <div class="modal fade md-round" id="ReviewAddModal" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content mc-clinic">
                        <div class="modal-body review-form">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <div class="login-form">
                                <div class="text-center mb-4">
                                    <h4>Review - Appointment Reminder</h4>
                                </div>
                            
                                <div class="form-group cli-grp">
                                    <label for="inputEmail4" class="d-flex align-items-center"><b>Service Date: </b> &nbsp;<span id="service_date"></span> &nbsp; <span id="designation"></span> </label>
                                    
                                </div>
                                <div class="form-group cli-grp">
                                    <label for="inputEmail4 d-inline-flex"><b>Selected Clinics: </b> <br><span id="clinic"></span></label>
                                    
                                </div>
                                <div class="form-group cli-grp">
                                    <label for="inputEmail4 d-inline-flex"><b>Template: </b> &nbsp;<span id="template"></span></label>
                                
                                </div>
                                
                                <div class="form-group cli-grp">
                                    <label for="exampleInputEmail1 d-inline-flex"><b>Template Message: </b><br><span id="message"></span></label>
                                    
                                </div>
                                <div class="form-group">
                                    <div class="formicon-parent">
                                        <button type="submit" class="btn btn-block login-btn-01 login-btn-02">SEND</button>
                                        <span><i class="fas fa-arrow-right login-icon-right arro"></i></span>
                                    </div>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
             <!-- Add Modal Review End -->
        </form>
    </div>
    <!------------------ END Appointment reminder section --------------------->

    <div class="dashboard-table1">
        
        <div class="row">
            <div class="col-md-12">
               
                <table id="" class="stripe user-table" style="width:100%">
                    <thead>
                        <tr>
                            <th>Service Date</th>
                            <th>Template Name</th>
                            <th>Color Designation</th>
                            <th>Examinee List</th>
                            <th>Created Date</th>
                        </tr>
                    </thead>
                    <tbody>
                    
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- cdn link of select2 jquery -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>

    $(function() {

        $('#clinic_list').select2({
            closeOnSelect : false
        });

        $("#checkbox").click(function(){
            if($("#checkbox").is(':checked') ){
                $("#clinic_list > option").prop("selected","selected");
                $("#clinic_list").trigger("change");
            }else{
                $('#clinic_list').val(null).trigger('change');
            }
        });

        $('#service_location').select2({
            closeOnSelect : false,
            placeholder:'Select Service date - Clinic Name'
        });

        $('#template_name').select2({
            closeOnSelect : false,
            placeholder:'Select Template Name'
        });

        var resultTable = $('.user-table').DataTable({
            processing: true,
            serverSide: false,
            order: [],
            "language": {
                "processing": "<img style='width:80px; height:80px;' src='{{url('/assets/images/loaderspinner.gif')}}' >"
            },
            ajax: "{{ route('appointment-reminder') }}",
            columns: [
                {data: 'service_date', name: 'service_date'},
                {data: 'template_name', name: 'template_name'},
                {data: 'color_name', name: 'color_name',orderable: false, searchable: false},
                {data: 'examinee_list', name: 'examinee_list', orderable: false, searchable: false},
                {data: 'date', name: 'date', orderable: false, searchable: false},
            ]
        });

        // this is used to add template
        $(document).on('submit','#addTemplateForm',function (e) {

            e.preventDefault();
            if (!$(this).valid()) {
                alert('Something went wrong at the time of filling the form');
                return;
            }

            $.ajax({
                url: "{{ route('post.addNewTemplate') }}",
                type: "post",
                data: $(this).serialize() +'&_token='+"{{ csrf_token() }}",
                beforeSend:function() {
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    });
                },
                success:function(data){
                    
                    swal.close();

                    if (data.status) {

                        $('#addtemplateModal').modal('hide');

                        resultTable.ajax.reload();

                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success",
                        });

                    } else {
                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error",
                        });
                    }
                },
                error:function (jqXHR, textStatus, errorThrown) {

                    if (jqXHR.status == 419) {

                        swal({
                            icon: "error",
                            title:'Oops!',
                            text: 'soemthing went wrong, please login again',
                            buttons: true,
                            closeOnClickOutside:false
                            
                        });
                        
                    } else {
                        swal({
                            icon: "error",
                            title:'Oops!',
                            text: 'soemthing went wrong, Response StatusCode - '+jqXHR.status,
                            buttons: true,
                            closeOnClickOutside:false
                            
                        });
                    }
                    

                },
            });
        });
        //<!---------------- END  ------------------------>
        
         // To get clinic service data to update
        $(document).on('click','.template_editbtn', function() {
            
            let id = $(this).attr('data-id');

            $.ajax({
                url:"{{ route('get.getTemplate') }}",
                type:'GET',
                data: {_token:"{{ csrf_token()}}",template_id:id},
                dataType:'json',
                beforeSend:function() {
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    
                    });
                },
                success:function(output) {

                    swal.close();

                    if (output.status) {

                        let data = output.data;
                    
                        $('#template_id').val(data.id);
                        $('#edit_template_title').val(data.title);
                        $('#edit_template_message').val(data.message);
                       
                        $('#edittemplateModal').modal('show');

                    } else {

                        swal({
                            title: "Oops!",
                            text: output.msg,
                            icon: "error",
                        });
                    }
                },
                error:function (jqXHR, textStatus, errorThrown) {
                    
                    if (jqXHR.status == 500) {

                        swal({
                            title: "Oops!",
                            text: textStatus,
                            icon: "error",
                        });

                    } else {

                        console.log('something went wrong!');
                    }
                },
            });
        });

         // this is used to add template
        $(document).on('submit','#editTemplateForm',function (e) {

            e.preventDefault();

            if (!$(this).valid()) {
                alert('Something went wrong at the time of filling the form');
                return;
            }

            $.ajax({
                url: "{{ route('post.updateTemplate') }}",
                type: "post",
                data: $(this).serialize() +'&_token='+"{{ csrf_token() }}",
                beforeSend:function() {
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    });
                },
                success:function(data) {
                    
                    swal.close();

                    if (data.status) {

                        $('#edittemplateModal').modal('hide');

                        resultTable.ajax.reload();

                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success",
                        });

                    } else {
                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error",
                        });
                    }
                },
                error:function (jqXHR, textStatus, errorThrown) {

                    if (jqXHR.status == 419) {

                        swal({
                            icon: "error",
                            title:'Oops!',
                            text: 'soemthing went wrong, please login again',
                            buttons: true,
                            closeOnClickOutside:false
                            
                        });
                        
                    } else {
                        swal({
                            icon: "error",
                            title:'Oops!',
                            text: 'soemthing went wrong, Response StatusCode - '+jqXHR.status,
                            buttons: true,
                            closeOnClickOutside:false
                            
                        });
                    }
                    

                },
            });
        });
        //<!---------------- END  ------------------------>

        // this is used to delete a template 
        $(document).on('click', '.template_deletebtn', function(event) {

            let id  = $(this).attr('data-id');

            swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover the template",
                icon: "warning",
                buttons: true,
                dangerMode: true,
                closeOnClickOutside:false
            }).then((willDelete) => {

                if (willDelete) {

                    $.ajax({
                        url: "{{ route('post.deleteTemplate') }}",
                        type: "POST",
                        data: {_token:"{{ csrf_token()}}", template_id:id},
                        beforeSend:function() {
                            swal({
                                icon: "{{ url('/assets/images/loader.gif') }}",
                                text: 'Please Wait...',
                            });
                        },
                        success:function(data) {

                            swal.close();

                            if (data.status) {

                                resultTable.ajax.reload();

                                swal({
                                    title: "Great!",
                                    text: data.msg,
                                    icon: "success",
                                });

                            } else {
                                swal({
                                    title: "Oops!",
                                    text: data.msg,
                                    icon: "error",
                                });
                            }
                        },
                        error:function (jqXHR, textStatus, errorThrown) {

                            if (jqXHR.status == 419) {

                                swal({
                                    title: "Oops!",
                                    text: 'please login again in the application',
                                    icon: "error",
                                });

                            } else {
                                console.log('something went wrong!');
                            }
                        },
                    });

                } else {}
            });
        });
        //<!------------------- END ----------------------------------->

        $(document).on('change', '#notification_service_date', function(e){
            getClinicsByDateandColor();
        });

        $(document).on('change', '.colour_designation', function(e){
            getClinicsByDateandColor();
        });

        // This method is used to get clinics by service date and color designation
        function getClinicsByDateandColor(){
            var serviceDate = $('#notification_service_date').val();
            var colorType = $('input[name="color_type"]:checked').val();
            if (serviceDate != '' && colorType != undefined) {
                $("#clinic_list").empty();
                $('#checkbox').prop('checked',false);
                $.ajax({
                    url:"{{ route('get.clinicsByServiceDate') }}",
                    type:'GET',
                    data: {_token:"{{ csrf_token()}}",serviceDate:serviceDate,colorType:colorType},
                    dataType:'json',
                    beforeSend:function() {
                        swal({
                            icon: "{{ url('/assets/images/loader.gif') }}",
                            text: 'Please Wait!',
                            buttons: false,
                            closeOnClickOutside:false
                        });
                    },
                    success:function(output) {
                        swal.close();
                        if (output.status == true) {
                            let data = output.data;
                            console.log(data);
                            let text = '';
                            $.each(data, function (key, value) {
                                text+='<option value="' + value.location_id + '">' + value.name + '</option>';
                            });
                            $("#clinic_list").append(text);
                        } else if (output.status == false) {
                            swal({
                                title: "Oops!",
                                text: output.msg,
                                icon: "error",
                            });
                        } else {
                            window.location.reload(true);
                        }
                    },
                    error:function (jqXHR, textStatus, errorThrown) {
                        window.location.reload(true);
                    },
                });
                $('.clinic_search').css('display','block');
            }
        }
        
    });

    $('#notification_service_date').on('change', function () {
        var e = document.getElementById("notification_service_date");
        var value = e.value;
        var servicedate = e.options[e.selectedIndex].text;
        document.getElementById("service_date").innerHTML  = servicedate;
    });

    $('#clinic_list').on('change', function () {
        var selected = [];
        document.getElementById("clinic").innerHTML = "";
        var e = document.getElementById("clinic_list");

        var value = e.value;

        for (var option of document.getElementById('clinic_list').options) {
            if (option.selected) {
                selected.push(option.text);
            }
        }

        if (e.options[e.selectedIndex] != undefined) {
            var cliniclist = e.options[e.selectedIndex].text;
            var selectedVal = "";
            $.each(selected, function (key, value) {
                selectedVal+= "<b>"+(key+1)+"</b>" + "-&nbsp;" + value+ '<br>';
            });
            const values = Array.from(e).map(el => el.text);
            document.getElementById("clinic").innerHTML = selectedVal;
        }
    });

    $('#reviewBtn').on('click', function () {
        var selected = [];
        var e = document.getElementById("template_n");
        var value = e.value;
        var template = e.options[e.selectedIndex].text;
        var serviceDate = $('#notification_service_date').val();
        document.getElementById("template").innerHTML = template;
        var cL = document.getElementById("clinic_list");  

        for (var option of document.getElementById('clinic_list').options) {
            if (option.selected) {
                selected.push(option.value);
            }
        }
        const clinicList = selected;
        if (serviceDate == '') {
            alert("Please Select Service Date");
            return false;
        }
        var len = $('[name=color_type]:checked').length;

        if (len < 1)  {
            alert('Please select designation.'); 
            return false;
        }
        if (clinicList == '') {
            alert("Please Select Clinic");
            return false;
        }
        if (value == '') {
            alert("Please Select Template");
            return false;
        }

        $.ajax({
            url: "{{ route('get.notification_template') }}",
            type: "POST",
            data: {
            _token:"{{ csrf_token()}}", template_id:value,
            service_date:serviceDate,
            clinic_list:clinicList
            },
            dataType:'json',
            success: function(Response) {
                let obj = JSON.parse(Response.data);
                $('#message').text(`${obj.message}`);
                $('#ReviewAddModal').modal('show');
            }
        });
    });

    $('#green_check').on('change', function () {
        if (document.getElementById('green_check').checked) {
            var color = "<span id='green' class='color_designation' style='background:#96D35F!important;'></span>";
            document.getElementById("designation").innerHTML = color;
        }
    });
    
    $('#red_check').on('change', function () {
        if (document.getElementById('red_check').checked) {
            var red_value = document.getElementById('red_check').value;
            var color = "<span class='color_designation bg-danger' style='background:#FF2600!important;'></span>";
            document.getElementById("designation").innerHTML = color;
        }
    });

    $('#yellow_check').on('change', function () {
        if (document.getElementById('yellow_check').checked) {
            var yellow_value = document.getElementById('yellow_check').value;
            var color = "<span class='color_designation' style='background:#FFF76B!important;'></span>";
            document.getElementById("designation").innerHTML = color;
        }
    });

</script>


@endsection