@extends('layouts.adminlayout')
@section('title','Change Password - Moonlight Examinations')
@section('content')
<style>
   .invalid-feedback{
   display:block!important;
   }
   .card.shadow.border-0.bg-light.custom-styling {
   box-shadow: 2px 2px 12px 1px #ddd;
   }
   .custom-styling label {
   font-weight: bold;
   }
   .custom-styling input {
   max-height: 50px;
   }
   h2.title-change-pwd {
   font-size: 22px;
   font-weight: bold;
   margin-bottom: 20px;
   }
   .custom-styling .login-btn-01 {
   font-weight: bold;
   }
</style>
<div class="container">
    <div class="row">
        <div class="col-md-3">
        </div>
        <div class="col-md-6">
            <h2 class="title-change-pwd">Change Password</h2>
            <div class="card shadow border-0 p-4 bg-light custom-styling">
                <div class="login-form">
                    <form action="{{ route('change.password.post') }}" id="changePasswordForm" method="POST" class="myForm">
                        <label for="password">Enter Old Password <span class="star">*</span></label>
                        <div class="formicon-parent">
                            <input type="password" id="oldPassword" class="form-control frm-input-1" placeholder="Enter Old Password" name="oldPassword" maxlength="15" required>
                            <span>
                                <i class="far fa-eye-slash input-icon-right aw" onclick="return visibility('oldPassword',this);"></i>
                            </span>
                            @error('password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror 
                        </div>
                        <br>
                        <label for="password">Enter New Password <span class="star">*</span></label>
                        <div class="formicon-parent">
                            <input type="password" id="login_password1" class="form-control frm-input-1  @error('password') is-invalid @enderror" placeholder="Enter New Password" name="password" onkeyup="removeerror()" maxlength="15" data-toggle="popover" data-trigger="focus" title="Password Hint" data-content="At least one capital letter, <br>At least one number, <br> At least one special character from<br>(@, #, $, %, &)" required>
                            <span>
                                <i class="far fa-eye-slash input-icon-right aw" onclick="return visibility('login_password1',this);"></i>
                            </span>
                            @error('password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror 
                        </div>
                        <br>
                        <div class="form-group margin-1">
                            <label for="login_password2">Confirm New Password <span class="star">*</span></label>
                            <div class="formicon-parent">
                                <input id="login_password2" type="password" class="form-control frm-input-1 @error('password') is-invalid @enderror" placeholder="Confirm New Password" name="password_confirmation" required > 
                                <span>
                                    <i class="far fa-eye-slash input-icon-right aw" onclick="return visibility('login_password2',this);"></i>
                                </span>
                            </div>
                        </div>
                        <div class="form-group mb-1">
                            <div class="formicon-parent text-center">
                                <button type="button" onclick="window.history.back();" class="lft-arrow" >Cancel</button>
                                <button type="submit" class="rgt-arrow">Change</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>

    $(function() {

        
        $('#login_password1').popover({
            container: 'body',
            html:true,
            placement:'right'
        });

        jQuery.validator.addMethod("strong_password", function (value, element) {
            let password = value;
            if (!(/^(?=.*[A-Z])(?=.*[0-9])(?=.*[@#$%&])(.{8,15}$)/.test(password))) {
                return false;
            }
            return true;
        }, function (value, element) {

            let password = $(element).val();

            if (!(/^(.{8,15}$)/.test(password))) {
                return 'Password must be between 8 to 15 characters.';
            }
            else if (!(/^(?=.*[A-Z])/.test(password))) {
                return 'Password must contain at least one Capital Letter.';
            }
            else if (!(/^(?=.*[0-9])/.test(password))) {
                return 'Password must contain at least one number.';
            }
            else if (!(/^(?=.*[@#$%&])/.test(password))) {
                return "Password must contain at least one special character from @#$%&.";
            }
            return false;
        });


        $("#changePasswordForm").validate({

            rules: {
                password: {
                    required:true,
                    strong_password:true
                },
                password_confirmation:{
                    required:true,
                    equalTo:'#login_password1'
                },
                oldPassword: {
                    required:true,
                }

            },
            messages: {
                password: {
                    required:"Password is required",
                },
                password_confirmation:{
                    required:"Confirm Password is required",
                    equalTo:'Confirm Password does not match'
                },
                oldPassword: {
                    required:"Old Password is required",
                },

            },

            errorPlacement: function(label, element) {

                label.addClass('mt-2 text-danger');

                label.insertAfter(element);

            },

            highlight: function(element, errorClass) {

                $(element).parent().addClass('has-danger');

                $(element).addClass('form-control-danger');

            },

            unhighlight: function(element, errorClass, validClass) {

                $(element).parents().removeClass('has-danger');

                    $(element).removeClass('form-control-danger');

                $(element).parents('.form-group').addClass('has-success');

            }

            });
        });

        $('#changePasswordForm').on('submit',function(e) {
            
            e.preventDefault();

            if (!$("#changePasswordForm").valid()) {
                return;
            }

            $.ajax({
                url: "{{ route('change.password.post') }}",
                type: "post",
                data: $(this).serialize() +'&_token='+"{{ csrf_token() }}",
                beforeSend:function() {
                    swal({
                        icon: "{{ url('/assets/images/loader.gif') }}",
                        text: 'Please Wait!',
                        buttons: false,
                        closeOnClickOutside:false
                    
                    });
                },
                success:function(data) {
                  
                    swal.close();
                    if(data.status) {

                        swal({
                            title: "Great!",
                            text: data.msg,
                            icon: "success",
                            closeOnClickOutside:false
                        }).then(function(event) {
                            if(event) {       
                                $("#changePasswordForm")[0].reset();
                            }
                        });

                    } else {
                        swal({
                            title: "Oops!",
                            text: data.msg,
                            icon: "error",
                        });
                    }
                },
                error:function (jqXHR, textStatus, errorThrown) {
                    if (jqXHR.status == 500) {
                        
                        console.log('500 status');
                    } else {
                        console.log('something went wrong!');
                    }
                },
            });
                 
            // return $(this).submitForm();
            
        });
        

    function visibility(id,event) {
            
            var x = document.getElementById(id);
            if (x.type === 'password') {
                    x.type = "text";
                    $(event).removeClass('fa-eye-slash');
                    $(event).addClass('fa-eye');
            } else {
                    x.type = "password";
                    $(event).removeClass('fa-eye');
                    $(event).addClass('fa-eye-slash');
            }
        }

        function removeerror() {

            let resetpass = $('#login_password1').val();
            let confirm_resetpass = $('#login_password2').val();
            if(resetpass == '') {
                return;
            }
           
            if(resetpass == confirm_resetpass) {
                $('.invalid-feedback').remove();
                $('#login_password2,#login_password1').removeClass('is-invalid');
                
            }
        
        }

</script>
@endsection