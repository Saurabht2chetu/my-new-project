<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ClinicTypesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('clinic_types')->insert([
            ['name' => 'Psych Clinic'],
            ['name' => 'Medical Clinic'],
            ['name' => 'X-Ray Clinic']
        ]);
    }
}
