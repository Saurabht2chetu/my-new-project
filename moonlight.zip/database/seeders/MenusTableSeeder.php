<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MenusTableSeeder extends Seeder
{
    
    /**
    * Run the database seeds.
    *
    * @return void
    */
    public function run()
    {   
        DB::table('menus')->truncate();

        DB::table('menus')->insert([
            ['name' => 'Headquarter Management','slug'=>'headquarter-management','icon'=>'user-cog','seq_no'=>'1','active'=>'1','created_at'=>date("Y-m-d H:i:s")],
            ['name' => 'Users','slug'=>'users','icon'=>'user','seq_no'=>'2','active'=>'1','created_at'=>date("Y-m-d H:i:s")],
            ['name' => 'Locations','slug'=>'locations','icon'=>'map-marker-alt','seq_no'=>'3','active'=>'1','created_at'=>date("Y-m-d H:i:s")]
        ]);
    }

}
