<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStatesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('states', function (Blueprint $table) {
            $table->id();
            $table->string('name', 250);
            $table->string('standard', 250)->nullable();
            $table->string('code', 10)->nullable();
            $table->string('invoice_extraction', 100)->nullable();
            $table->tinyInteger('active')->default('1');
            $table->string('user_name', 255)->nullable();
            $table->string('user_password', 255)->nullable();
            $table->timestamps();
        });
    }

    /**
    * Reverse the migrations.
    *
    * @return void
    */
    public function down() {
        
        Schema::dropIfExists('states');
    }
}
