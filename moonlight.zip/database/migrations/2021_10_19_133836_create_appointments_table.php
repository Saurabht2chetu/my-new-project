<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppointmentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('appointments', function (Blueprint $table) {
            $table->id();
            $table->date('service_date');
            $table->string('service_time',250)->nullable();
            $table->unsignedBigInteger('patient_id');
            $table->unsignedBigInteger('user_id');
            $table->unsignedBigInteger('location_id');
            $table->foreign('location_id')->references('id')->on('locations')->onDelete('cascade');
            $table->text('invoice_url')->nullable();
            $table->text('cepacket_url')->nullable();
            $table->text('combined_url')->nullable();
            $table->text('type_of_exam')->nullable();
            $table->text('request_status')->nullable();
            $table->text('special_instruction')->nullable();
            $table->string('case_id',250)->nullable();
            $table->tinyInteger('status')->default('0');
            $table->longText('status_text')->nullable();
            $table->tinyInteger('active')->default('1');
            $table->tinyInteger('deleted')->default('0');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('appointments');
    }
}
