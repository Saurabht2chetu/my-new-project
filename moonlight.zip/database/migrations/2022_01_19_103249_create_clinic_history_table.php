<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateClinicHistoryTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('clinic_history', function (Blueprint $table) {
            $table->id();
            $table->date('service_date');
            $table->string('service_time',255);
            $table->unsignedBigInteger('location_id');
            $table->unsignedBigInteger('appointment_id');
            $table->unsignedBigInteger('patient_id');
            $table->unsignedBigInteger('user_id');
            $table->foreign('location_id')->references('id')->on('locations')->onDelete('cascade');
            $table->text('invoice_url')->nullable();
            $table->text('cepacket_url')->nullable();
            $table->text('combined_url')->nullable();
            $table->text('type_of_exam')->nullable();
            $table->text('special_instruction')->nullable();
            $table->string('case_id',250)->nullable();
            $table->tinyInteger('status')->default('0');
            $table->tinyInteger('active')->default('1');
            $table->tinyInteger('deleted')->default('0');
            $table->text('examiner_id')->nullable();
            $table->text('assistant_id')->nullable();
            $table->unsignedBigInteger('updated_by');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('clinic_history');
    }
}
