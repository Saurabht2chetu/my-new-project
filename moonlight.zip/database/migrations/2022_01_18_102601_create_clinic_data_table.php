<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateClinicDataTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('clinic_data', function (Blueprint $table) {
            $table->id();
            $table->date('service_date');
            $table->bigInteger('location_id');
            $table->text('team_member')->nullable();
            $table->text('contact_type')->nullable();
            $table->text('chart_type')->nullable();
            $table->text('x_ray_vendor')->nullable();
            $table->string('from_time',250)->nullable();
            $table->string('to_time',250)->nullable();
            $table->longText('admin_write_in')->nullable();
            $table->longText('assistant_write_in')->nullable();
            $table->longText('assistant_write_in')->nullable();
            $table->tinyInteger('training')->default('0');
            $table->tinyInteger('email')->default('0');
            $table->tinyInteger('invite')->default('0');
            $table->bigInteger('updated_by')->default('0');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('clinic_data');
    }
}
