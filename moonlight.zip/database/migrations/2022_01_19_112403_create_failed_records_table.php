<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFailedRecordsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('failed_records', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('state_id');
            $table->unsignedInteger('location_id');
            $table->unsignedInteger('patient_id');
            $table->longText('error_msg');
            $table->enum('error_status',['State Not Found','Patient Not Found','Provider Not Found','Appointment Not Found','Other Exception']);
            $table->timestamp('start_time');
            $table->timestamp('end_time');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('failed_records');
    }
}
