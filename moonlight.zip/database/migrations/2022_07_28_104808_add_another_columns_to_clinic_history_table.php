<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddAnotherColumnsToClinicHistoryTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('clinic_history', function (Blueprint $table) {
            $table->enum('invoice_update', ['0', '1'])->default('0');
            $table->enum('record_update', ['0', '1'])->default('0');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('clinic_history', function (Blueprint $table) {
            $table->dropColumn('invoice_update');
            $table->dropColumn('record_update');
        });
    }
}
